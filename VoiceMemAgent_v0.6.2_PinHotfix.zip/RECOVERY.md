# VoiceMemAgent v0.6.2 — installer step-12 pin-read hotfix

## Mi történt a mezőn (field report)

A START.bat kimenete (F:\Voicemem\VoiceMemAgent):

    ---- [12/22] VoiceMem telepitese (vendor\voicemem + pip install -e)
        Vezelt VoiceMem forras: vendor\voicemem (pin: e8384e087...).
    INSTALLATION FAILED
    Failed step : 12
    Error       : A VOICEMEM_PIN.json hianyzik vagy nem a vart upstream
                  commit-et rogziti (vart: e8384e08...).

## Gyökérok (valódi PowerShell futtatással bizonyítva)

A telepítő 12. lépése a pin-commitot a JSON **gyökerén** kereste:

    $PinJson.upstream_commit            # <- MINDIG $null

de a VOICEMEM_PIN.json-ben a commit a `provenance` blokkon BELÜL van:

    provenance.upstream_commit          # <- e8384e087bd2...

A PowerShell `ConvertFrom-Json` gyökérszintű olvasása tehát **mindig nullt**
adott -> a 12. lépés **tökéletes pin-fájl mellett determinisztikusan elhalt**,
valamint minden gépen, ahol a telepítő ténylegesen lefutott.

## Miért nem vette észre a sandbox?

1. A Linuxos sandbox **sosem futtatja** a `.ps1` telepítőt — a kapuk
   tartalom-ellenőrzéssel (content-pin) pinelik a scripteket, a Python
   verifier (`verify_voicemem_pin.py`) pedig HELYESEN olvasta a
   `provenance.upstream_commit`-ot.
2. A mezőn az idempotens bootstrap v0.6.1-ig **sosem futtatta le a 12.
   lépést**: a v0.6.0 "model set complete: asr" false-positive mindig
   átugrotta a telepítőt. A v0.6.1 őszinte modell-ellenőrzése (hiányzó
   parakeet) FUTTATTA LE ELŐSZÖR a 22 lépést — és a 12. lépés azonnal
   elhalt ezen a sosem-tesztelt kódon.

## A javítás (v0.6.2)

1. `scripts/install_m1.ps1` 12. lépés: a commit olvasása
   `$PinJson.provenance.upstream_commit` (null-biztos lánc), és a hibaüzenet
   most **kiírja a ténylegesen olvasott értéket** is (`olvasott: ...`) —
   jövőbeli mező-jelentésekhez precíz diagnosztika.
2. `scripts/bootstrap.ps1` (Write-FinalSummary) és `scripts/install_m1.ps1`
   (záró riport): az elavult `ASR: Qwen3 ASR 0.6B` banner →
   `NVIDIA Parakeet TDT 0.6B v3` — ez volt a "start.bat még mindig asr:
   qwent ír" megfigyelés **maradék forrása** is.
3. Új regressziós tesztek
   (`tests/unit/test_voicemem_controlled.py::InstallerPinReadRegressionTests`):
   tartalom-pinek ÉS — ahol pwsh elérhető — **valódi futtatás** a
   kiszállított kódblokkon az igazi pin-fájllal (érvényes → PASS,
   mutált commit → hangos FAIL a kiolvasott értékkel).

Érintetlen maradt: az app-architektúra, a motor-szerződés, a
NO-FALLBACK szabály, a `vendor/` fa és a memóriabiztonsági fagyasztás.

## Frissítés a mezőn (user)

1. `VoiceMemAgent_v0.6.2.zip` felülíró kicsomagolása az install fölé
   (F:\Voicemem\VoiceMemAgent).
2. `START.bat` dupla kattintás.
3. A bootstrap immár átmegy a 12. lépésen → a 17. lépés letölti a
   parakeet-et (~2,4 GB, 6 fájl) → a 19. lépés smoke-tesztjei →
   INSTALLATION SUCCESS → az agent elindul, az ASR-lánc zöld.

## Visszaállítás (rollback)

A v0.6.1 ZIP visszacsomagolása + START.bat — de NINCS értelme: a v0.6.2
kizárólag a telepítő pin-olvasását és két banner-szöveget javítja,
viselkedésbeli változás nincs (a 12. lépés v0.6.1-ben sosem ment át,
v0.6.2-ben átmegy).
