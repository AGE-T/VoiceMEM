# HOTFIX REPORT — v0.6.2 (installer step-12 pin-read)

**Jelzés (mező):** START.bat → `INSTALLATION FAILED / Failed step: 12 /
A VOICEMEM_PIN.json hianyzik vagy nem a vart upstream commit-et rogziti`
— **tökéletes pin-fájl mellett.**

**Gyökérok:** a telepítő `$PinJson.upstream_commit`-ot olvasott (JSON
gyökér), miközben a commit `provenance.upstream_commit` alatt él → a
`ConvertFrom-Json` gyökérszintű olvasása mindig `$null` → a 12. lépés
determinisztikusan elhalt minden valós futtatáskor.

**Bizonyíték (valódi pwsh 7.4.6):**
- v0.6.1 szállított blokkja + v0.6.1 szállított pin-fájl → **FAIL**
  (`evidence/step12_bug_reproduction.txt`) — a mező-jelentés bájtra
  pontosan reprodukálva.
- v0.6.2 szállított blokkja (a ZIPBŐL kicsomagolva) + a ZIP saját
  pin-fájlja → **PASS** (`evidence/step12_fix_verification.txt`).

**Miért rejtve maradt minden kapu előtt:** a sandbox Linuxon sosem futtat
`.ps1`-t; a mezőn a v0.6.1-es bootstrapig **sosem futott le a 12. lépés**
(a v0.6.0-s false-positive "model set complete: asr" mindig átugrotta a
telepítőt) — a v0.6.1 őszinte modell-ellenőrzése futtatta le először a
22 lépést, és a sosem-tesztelt kód azonnal elhalt.

**Javítás:**
1. `$PinJson.provenance.upstream_commit` (null-biztos lánc) + a
   hibaüzenetben a ténylegesen olvasott commit (`olvasott: ...`).
2. Elavult `ASR: Qwen3 ASR 0.6B` bannerek (bootstrap záró összefoglaló +
   telepítő záró riport) → `NVIDIA Parakeet TDT 0.6B v3` — a mező
   "start.bat még qwent ír" megfigyelésének maradék forrása.
3. Új `InstallerPinReadRegressionTests`: content-pinek + **valódi pwsh
   futtatás** a kiszállított blokkon (érvényes pin → PASS; mutált commit
   → FAIL, a kiolvasott érték a kimeneten).

**Kapu:** 974 / 0 / 25 (635 unit — köztük a 4 új teszt valódi futtatással;
75 integráció — a fagyasztott memóriabiztonsági akkumulátor a VALÓDI
vendoron zöld; 264 validáció). A build után a szállított ZIP-ből
kicsomagolt kódon újra lefuttatva a step-12 harness: PASS.

**Nem változott:** app-architektúra, motor-szerződés, NO-FALLBACK,
`vendor/`, memóriabiztonsági fagyasztás.

**Mezőn ellenőrizendő (user):** v0.6.2 ZIP felülcsomagolása + START.bat →
a telepítő végigmegy a 12. lépésen, letölti a parakeet-et (~2,4 GB), majd
INSTALLATION SUCCESS és a zöld ASR-lánc.
