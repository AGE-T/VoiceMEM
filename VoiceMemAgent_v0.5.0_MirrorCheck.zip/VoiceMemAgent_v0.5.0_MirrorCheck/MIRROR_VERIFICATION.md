# GitHub Mirror Verification — VoiceMemAgent v0.5.0

**Date:** 2026-09-10 (session `web-7b05b5bc-1460-41f0-9ee3-aeaffd50714f`)
**Task:** The user uploaded both v0.5.0 packages to
<https://github.com/AGE-T/VoiceMEM> and asked whether the mirror is
accessible and trustworthy.

**Result: PASS** — the mirror is public, reachable over both HTTPS and the
git protocol, and both ZIPs are **byte-identical** to the locally produced
artifacts.

## 1. Access

| Check | Result |
| --- | --- |
| `git ls-remote https://github.com/AGE-T/VoiceMEM.git` | OK — `HEAD` and `refs/heads/main` both at `5f4a075327072b8da9e79ccc8e810f73bdb19c73` |
| `git clone` (full) | OK — exit 0 |
| Repository state | Single commit `5f4a075` "Mem ovnership", author `AGE-T`, date 2026-09-10 12:56:04 +0200 |
| Contents | Exactly 2 files, 1.9 MB (excluding `.git`): `VoiceMemAgent_v0.5.0.zip`, `VoiceMemAgent_v0.5.0_Verification.zip` |

## 2. Integrity (byte-level)

SHA-256 comparison between the GitHub clone and the local production
artifacts:

| File | GitHub mirror | Local (`public/` + `releases/`) | Match |
| --- | --- | --- | --- |
| `VoiceMemAgent_v0.5.0.zip` | `45c1feba29dc61492aa148b167c31e60509b7eeeede003f33348f430254ceb40` | `45c1feba29dc61492aa148b167c31e60509b7eeeede003f33348f430254ceb40` | ✅ |
| `VoiceMemAgent_v0.5.0_Verification.zip` | `aa880796031a5ada388a75cdae26befc723d6e37988589d4a0bf6b91331db631` | `aa880796031a5ada388a75cdae26befc723d6e37988589d4a0bf6b91331db631` | ✅ |

The verification ZIP hash is the same one recorded in
`docs/VERIFICATION_REPORT_v0.5.0.md` and in its `.sha256` sidecar at
build time — the upload did not alter either package.

## 3. Verification ZIP content spot-check

`unzip -l` on the GitHub copy lists the expected 13 entries / 79,787
uncompressed bytes, including:

- `RECOVERY.md`, `identity.json`
- `docs/VERIFICATION_REPORT_v0.5.0.md` (A–Q report + ten decisions)
- `docs/verification_evidence/` — pin verification, gate summary
  (921/24), clean-install manifest, trait assessment, A/B retrieval
  baseline
- `recovery/verification_session.patch` (session patch against `dc6f83b`)

## 4. Evidence files

All raw outputs are in `evidence/`:

- `git_ls_remote.txt` — protocol-level reachability
- `clone_log.txt` — commit metadata of the clone
- `file_listing.txt` — full file tree, count, size
- `sha256_github_clone.txt` / `sha256_local.txt` — the two hash tables
- `verification_zip_listing.txt` / `product_zip_top_listing.txt` — ZIP
  content listings

## 5. Notes

- The mirror is a **distribution copy only** (2 release ZIPs). The
  canonical source of truth remains the agent repository
  (`voicemem-agent/`, HEAD lineage `dc6f83b` → `3065701` → `c6d6da1` →
  `8e02ffd`) and the vendor pin `e8384e087bd2f44eb05fc7ae1a3c525ea8244179`.
- The sandbox-side download page now also links to this mirror, so both
  the in-app download and the external GitHub copy are reachable from one
  place.
- If the user later pushes the full agent source to GitHub (not just the
  ZIPs), the identity anchors to re-verify would be: repo HEAD, vendor
  pin `e8384e0…`, and the release ZIP hashes above.
