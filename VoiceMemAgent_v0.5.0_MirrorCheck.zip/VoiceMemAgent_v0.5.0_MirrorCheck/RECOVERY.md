# RECOVERY — VoiceMemAgent_v0.5.0_MirrorCheck

**Artifact type:** GOLDEN RULE deliverable (verification record)
**Created:** 2026-09-10, session `web-7b05b5bc-1460-41f0-9ee3-aeaffd50714f`
**Size class:** small (~10 KB), no runtime state inside.

## What this is

A one-shot verification record proving that the user's GitHub mirror at
<https://github.com/AGE-T/VoiceMEM> (commit `5f4a075`, "Mem ovnership")
is public, reachable, and contains both v0.5.0 packages **byte-identical**
to the locally produced artifacts:

- `VoiceMemAgent_v0.5.0.zip` — SHA-256
  `45c1feba29dc61492aa148b167c31e60509b7eeeede003f33348f430254ceb40`
- `VoiceMemAgent_v0.5.0_Verification.zip` — SHA-256
  `aa880796031a5ada388a75cdae26befc723d6e37988589d4a0bf6b91331db631`

It is **not** a product release and must never enter the release index.

## Contents

```
VoiceMemAgent_v0.5.0_MirrorCheck/
├── RECOVERY.md                 ← this file
├── MIRROR_VERIFICATION.md      ← the human-readable report
├── identity.json               ← machine-readable identity + verdict
└── evidence/
    ├── git_ls_remote.txt       ← protocol reachability proof
    ├── clone_log.txt           ← clone commit metadata
    ├── file_listing.txt        ← repo file tree / count / size
    ├── sha256_github_clone.txt ← hashes measured on the clone
    ├── sha256_local.txt        ← hashes measured locally
    ├── verification_zip_listing.txt
    └── product_zip_top_listing.txt
```

## How to re-verify offline (any machine)

```bash
git clone https://github.com/AGE-T/VoiceMEM.git mirror
cd mirror
sha256sum VoiceMemAgent_v0.5.0.zip VoiceMemAgent_v0.5.0_Verification.zip
# expected:
#   45c1feba29dc61492aa148b167c31e60509b7eeeede003f33348f430254ceb40  VoiceMemAgent_v0.5.0.zip
#   aa880796031a5ada388a75cdae26befc723d6e37988589d4a0bf6b91331db631  VoiceMemAgent_v0.5.0_Verification.zip
```

## Recovery anchors (if everything else is lost)

- **Mirror:** https://github.com/AGE-T/VoiceMEM (commit `5f4a075`)
- **Canonical lineage:** agent repo commits `dc6f83b` (verification) →
  `3065701` (verification package) → `c6d6da1` (page visibility fix) →
  `8e02ffd` (worklog)
- **Vendor identity:** pin `e8384e087bd2f44eb05fc7ae1a3c525ea8244179`
  (= upstream tag v0.0.1; package version 0.2.3 is NOT the identity)
- **Full verification story:** `VoiceMemAgent_v0.5.0_Verification.zip`
  (RECOVERY.md + A–Q report + evidence + session patch)
