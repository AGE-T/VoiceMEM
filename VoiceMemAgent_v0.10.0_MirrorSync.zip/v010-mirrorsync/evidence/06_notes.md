PHASE 14 — execution notes & known states (2026-09-15)
======================================================

1. Sidecar format fix (pre-sync, sandbox commit 605967b)
   `VoiceMem_temporal_v010_recovery.zip.sha256` was written by the v0.10.0
   release session as a BARE hash (no filename), so `sha256sum -c` rejected it
   ("no properly formatted checksum lines found"). Standardised to the
   `<hash>  <filename>` format used by every other sidecar. The ZIP itself was
   NEVER touched (e5ac3e54… on both sides of the fix).

2. v0.9.1 product ZIP is not on the mirror — BY POLICY, not by loss
   The standing sync rule is "product = ONLY the latest stable release ZIP
   per sync run". v0.9.1 was released and superseded by v0.9.2 between two
   sync runs (mirror git history: commit 9d21191 synced v0.9.2 + the
   VoiceMem_vadfix_v091_recovery.zip package, but no sync ran while v0.9.1
   was latest). The v0.9.1 ZIP is preserved locally in the sandbox
   (public/ + releases/, SHA-verified) and its recovery package IS mirrored.

3. First push attempt: tooling timeout, zero partial state
   The first execution was terminated by the session tool timeout (580s)
   during `git push`. Git pushes are atomic — the GitHub API confirmed the
   mirror HEAD was still 6775208 afterwards. The second (background)
   execution completed: 6775208..ffbf6be main -> main.

4. Task A retirement preserved
   The pre-v0.8 archive removal (operator order 2026-09-15, commit 26a4431)
   remains intact after this sync: no v0.5.x/v0.6.x/v0.7.x packages on the
   mirror; local archive retained in the sandbox releases/ folder.

5. Token hygiene
   The PAT never entered any repository, public/ staging, evidence file or
   log (the sync script redacts github_pat_… patterns from its output).
   Storage: /home/z/.github_sync/AGE-T_VoiceMEM.token, chmod 600.
