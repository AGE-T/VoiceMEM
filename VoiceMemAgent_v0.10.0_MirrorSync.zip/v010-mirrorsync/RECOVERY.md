# VoiceMEM v0.10.0 — Mirror Sync evidencia csomag (PHASE 14)

**Mit tartalmaz:** a v0.10.0 kiadás GitHub-tükörre szinkronizálásának (PHASE 14)
bizonyítékai — a tulajdonosi állandó szabályzat ("minden frissítés felkerül a
tükörre") e kiadás szerinti teljesítése.

Ez NEM termékkiadás és NEM kódváltás: a tükör állapota a szinkron ELŐTT
`6775208` (a Task A utáni karbantartott állapot), UTÁNA `ffbf6be`.

## Mi került a tükörre

| Elem | Tartalom |
| --- | --- |
| `VoiceMemAgent_v0.10.0.zip` + `.sha256` | a legfrissebb stabil termékkiadás (SHA `472FB043…`, 2653.4 KB, 357 fájl) |
| `VoiceMem_temporal_v010_recovery.zip` + `.sha256` | a v0.10.0 helyreállítási csomag (SHA `E5AC3E54…`) |
| `README.md` | újragenerálva: "Latest stable release: v0.10.0" + verify szekció |
| `source/` | a teljes first-party forrásfa a v0.10.0 kóddal (rsync-paritás, üres diff) |

## Hogyan ellenőrizhető (audit-út)

1. `git clone https://github.com/AGE-T/VoiceMEM.git` (névtelenül is működik).
2. `git log --oneline -1` → `ffbf6be sync: VoiceMemAgent_v0.10.0.zip, …`
3. `sha256sum VoiceMemAgent_v0.10.0.zip` → `472fb043…`; a recovery ZIP →
   `e5ac3e54…` (lásd `evidence/04_mirror_verification.txt`).
4. Additivitás: a v0.8.0–0.9.2 termék ZIP-ek és mind a 6 recovery csomag
   megvannak; a Task A nyugdíjazás (pre-v0.8) sértetlen.
5. `source/` paritás: a tükör fájában `VERSION` = `0.10.0`, a temporális
   kód (`vendor/voicemem/voicemem/leftbrain/temporal.py`), a
   `docs/MEMORY_SEMANTICS.md` és mindkét temporális tesztcsomag jelen van.

## Hogyan ismételhető meg a szinkron (idempotens)

```
scripts/sync_github_mirror.sh --check   # dry-run: mit tenne
scripts/sync_github_mirror.sh           # szinkron + push (PAT kell)
```
A token helye: `/home/z/.github_sync/AGE-T_VoiceMEM.token` (chmod 600; a
sandbox állapotvesztés után a tulajdonosnak újracsatolnia kell — ez a
dokumentált osztály, lásd a fő jelentés OPEN pontját).

## Tartalomjegyzék

- `identity.json` — a szinkron identitása (HEAD-ek, SHA-k, commitok)
- `evidence/01_token_permission_check.txt` — PAT jogosultsági ellenőrzés (redacted)
- `evidence/02_dryrun.txt` — a szinkronkészlet és a várt változások (--check)
- `evidence/03_sync_push_log.txt` — a tényleges futás logja (push kimenettel)
- `evidence/04_mirror_verification.txt` — friss klónos utóellenőrzés (hash-tábla
  mindkét oldalról, README, source-paritás) — **VERDICT: PASS**
- `evidence/05_mirror_git_log.txt` — a tükör git története a szinkron után
- `evidence/06_notes.md` — végrehajtási jegyzetek (sidecar-javítás, v0.9.1
  szabályzati hiány, első push timeout, Task A megőrzés, token-higiénia)

## Ismert határok

- A v0.9.1 termék ZIP NEM került a tükörre — ez a "csak a legfrissebb termék
  ZIP" szabályzat következménye (a v0.9.1 két szinkron között jelent meg és
  élte túl a v0.9.2 leváltotta); a ZIP a sandbox archívumban megvan, a
  recovery csomaga tükrözve van. Részletek: `evidence/06_notes.md`.
- A first push a szerszámi timeouton megszakadt; a git push atomi — nem
  keletkezett részleges állapot (API-ellenőrizve), a második futás
  lezárta a szinkront.
