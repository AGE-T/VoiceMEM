#!/usr/bin/env python
"""S8 correlation analysis: llama-server task timing x VoiceMEM turns.

Joins three sources from the 2026-09-18 forensic capture:
  1. logs/llama-server.out.log   — server task timings (2 epochs, elapsed clock)
  2. logs/web-server.log         — product [chain] turns (wall clock), parsed
                                    with the product's own llm_slot_forensic
                                    S8 parser (identical semantics)
  3. .zscripts/s8_session_record.jsonl — driver turn labels (T1..C3)

Produces s8_correlation.json + s8_correlation_table.md with, per turn:
task id, prompt tokens (re-evaluated), prompt tok/s, generation tok/s,
total server time, VoiceMEM llm_wait, the slot-cache decision for the task,
the contention interval (background gate window overlapping the turn) and a
per-turn conclusion. Read-only; no product/server state is touched.
"""
from __future__ import annotations

import json
import re
import statistics
import sys
from datetime import datetime
from pathlib import Path

REPO = Path("/home/z/my-project/voicemem-agent")
sys.path.insert(0, str(REPO / "scripts"))

# reuse the product's own S8 parsing (identical log semantics)
import llm_slot_forensic as lsf  # noqa: E402

SERVER_LOG = REPO / "logs/llama-server.out.log"
PRODUCT_LOG = REPO / "logs/web-server.log"
RECORD = Path("/home/z/my-project/.zscripts/s8_session_record.jsonl")
SINCE = "2026-09-18 12:05:00"
OUT_DIR = Path("/home/z/my-project/.zscripts")

TS_RE = re.compile(r"^(\d+)\.(\d{2})\.(\d{3})\.(\d{3})\s+([IWD])\s+")
TASK_RE = re.compile(r"task (\d+)")
ADD_RE = re.compile(r"add task (\d+) to waiting list")
PROMPT_EVAL_RE = re.compile(
    r"prompt eval time =\s*([\d.]+) ms /\s*(\d+) tokens \(\s*([\d.]+) ms per token,\s*([\d.]+) tokens per second\)")
EVAL_RE = re.compile(
    r"\beval time =\s*([\d.]+) ms /\s*(\d+) (?:tokens|runs)\s*\(\s*([\d.]+) ms per token,\s*([\d.]+) tokens per second\)")
TOTAL_RE = re.compile(r"total time =\s*([\d.]+) ms /\s*(\d+) tokens")
CACHED_RE = re.compile(r"cached n_tokens = (\d+)")
NEWTOK_RE = re.compile(r"new prompt, n_ctx_slot = \d+, n_keep = \d+, task\.n_tokens = (\d+)")
SIM_RE = re.compile(r"- checking sim = ([\d.]+) \((\d+)/(\d+)\)")
LCP_RE = re.compile(r"selected slot by LCP similarity, f_sim_best = ([\d.]+)")
LRU_RE = re.compile(r"selected slot by LRU")


def elapsed_seconds(line: str) -> float:
    m = TS_RE.match(line)
    if not m:
        return -1.0
    minutes, secs, ms, us = (int(m.group(1)), int(m.group(2)),
                             int(m.group(3)), int(m.group(4)))
    return minutes * 60.0 + secs + ms / 1000.0 + us / 1e6


def parse_server_log() -> list[dict]:
    """-> [{epoch, wall0_estimate, tasks: {id: {...}}, cache_decisions: []}]"""
    epochs: list[dict] = []
    cur_epoch = None
    for raw in SERVER_LOG.open(encoding="utf-8", errors="replace"):
        line = raw.rstrip("\n")
        if "common_params_print_info: build 10717" in line:
            cur_epoch = {"idx": len(epochs), "start_elapsed": elapsed_seconds(line),
                         "tasks": {}, "decisions": [], "task_order": []}
            epochs.append(cur_epoch)
            continue
        if cur_epoch is None:
            continue
        el = elapsed_seconds(line)
        am = ADD_RE.search(line)
        if am:
            cur_epoch.setdefault("adds", {})[int(am.group(1))] = el
        tm = TASK_RE.search(line)
        task_id = int(tm.group(1)) if tm else None
        # slot-selection decisions precede a task launch; keep them per epoch
        if "get_availabl" in line and task_id is None:
            d: dict = {"elapsed": el}
            s = SIM_RE.search(line)
            if s:
                d["sim"] = float(s.group(1))
                d["sim_keep"] = int(s.group(2))
                d["sim_total"] = int(s.group(3))
            l = LCP_RE.search(line)
            if l:
                d["lcp"] = float(l.group(1))
            if LRU_RE.search(line):
                d["lru"] = True
            cur_epoch["decisions"].append(d)
            continue
        if task_id is None:
            continue
        t = cur_epoch["tasks"].setdefault(task_id, {"id": task_id})
        if "launch_slot_" in line and "processing task" in line:
            t["launch_elapsed"] = el
            if task_id not in cur_epoch["task_order"]:
                cur_epoch["task_order"].append(task_id)
        elif "new prompt" in line:
            n = NEWTOK_RE.search(line)
            if n:
                t["prompt_tokens"] = int(n.group(1))
        elif "cached n_tokens" in line:
            c = CACHED_RE.search(line)
            if c:
                t["cached_tokens"] = int(c.group(1))
        elif "prompt eval time" in line:
            m = PROMPT_EVAL_RE.search(line)
            if m:
                t["pe_ms"], t["pe_tokens"], t["pe_ms_per_tok"], t["pe_tps"] = (
                    float(m.group(1)), int(m.group(2)),
                    float(m.group(3)), float(m.group(4)))
        elif "eval time" in line and "eval time =" in line:
            m = EVAL_RE.search(line)
            if m:
                t["ge_ms"], t["ge_tokens"], t["ge_ms_per_tok"], t["ge_tps"] = (
                    float(m.group(1)), int(m.group(2)),
                    float(m.group(3)), float(m.group(4)))
        elif "total time" in line:
            m = TOTAL_RE.search(line)
            if m:
                t["total_ms"], t["total_tokens"] = float(m.group(1)), int(m.group(2))
        elif "release" in line and "stop processing" in line:
            t["release_elapsed"] = el
            n = re.search(r"n_tokens = (\d+)", line)
            if n:
                t["release_n_tokens"] = int(n.group(1))
        elif "process_toke" in line and "n_gen = 1," in line:
            if "first_gen_elapsed" not in t:
                t["first_gen_elapsed"] = el
    # attach the cache decision immediately preceding each task launch
    for ep in epochs:
        for tid in ep["task_order"]:
            t = ep["tasks"][tid]
            la = t.get("launch_elapsed")
            if la is None:
                continue
            best = None
            for d in ep["decisions"]:
                if d["elapsed"] <= la and (best is None or d["elapsed"] > best["elapsed"]):
                    best = d
            t["slot_decision"] = best
            t["add_elapsed"] = ep.get("adds", {}).get(tid)
    return epochs


def parse_driver_labels() -> list[dict]:
    labels = []
    if RECORD.is_file():
        for line in RECORD.open(encoding="utf-8"):
            rec = json.loads(line)
            if rec.get("kind") == "turn":
                labels.append(rec)
    return labels


def main() -> int:
    # ---- product turns via the product's own S8 parser ---------------------
    since = datetime.strptime(SINCE, "%Y-%m-%d %H:%M:%S").timestamp()
    events = lsf.load_product_events(lsf.collect_product_log_files("logs/web-server.log"),
                                     since_epoch=since)
    session = lsf.rebuild_turns(events, keep_turns=0)
    turns = session["turns_detail"]

    # ---- server epochs ------------------------------------------------------
    epochs = parse_server_log()
    anchors = {}
    for line in Path("/home/z/my-project/.zscripts/s8_epoch_anchors.txt").open():
        m = re.match(r"EPOCH_([AB])_START=(\d+)", line.strip())
        if m:
            anchors[m.group(1)] = float(m.group(2))

    # driver labels in order
    driver = parse_driver_labels()

    # map each product turn's llm_start (wall) to a server task
    # first-guess wall0 per epoch from the anchors; then refine by the
    # median (llm_start_wall - launch_elapsed) over matched pairs.
    def epoch_of(ts: float) -> int | None:
        # epoch windows: A = [anchorA, anchorB), B = [anchorB, inf)
        a, b = anchors.get("A"), anchors.get("B")
        if a is None:
            return None
        if b is not None and ts >= b:
            return 1
        return 0

    def tasks_sorted(ep: dict) -> list[dict]:
        out = []
        for tid in ep["task_order"]:
            t = ep["tasks"][tid]
            if "launch_elapsed" in t:
                out.append(t)
        out.sort(key=lambda t: t["launch_elapsed"])
        return out

    # candidate tasks = tasks with timing info (print_timing seen)
    for t in turns:
        stages = t.get("stages") or {}
        ll = stages.get("llm_start")
        t["_epoch"] = None
        t["_task"] = None
        if not ll:
            continue
        ll_wall = datetime.strptime(ll, "%Y-%m-%d %H:%M:%S,%f").timestamp()
        ep_i = epoch_of(ll_wall)
        t["_epoch"] = ep_i
        if ep_i is None or ep_i >= len(epochs):
            continue
        ep = epochs[ep_i]
        # initial wall0 guess
        w0 = anchors.get("A" if ep_i == 0 else "B", ll_wall - 60)
        best, best_dt = None, 12.0
        for task in tasks_sorted(ep):
            if "pe_tokens" not in task:
                continue
            dt = ll_wall - (w0 + task["launch_elapsed"])
            if abs(dt) < abs(best_dt):
                best, best_dt = task, dt
        t["_task"] = best

    # refine anchors using matched pairs per epoch (median offset)
    for ep_i, ep in enumerate(epochs):
        pairs = []
        for t in turns:
            if t.get("_epoch") == ep_i and t.get("_task") and t["stages"].get("llm_start"):
                ll_wall = datetime.strptime(t["stages"]["llm_start"],
                                            "%Y-%m-%d %H:%M:%S,%f").timestamp()
                pairs.append(ll_wall - t["_task"]["launch_elapsed"])
        if pairs:
            ep["wall0"] = statistics.median(pairs)
        else:
            ep["wall0"] = anchors.get("A" if ep_i == 0 else "B", 0)

    # re-match with refined wall0: a turn's request ADD must land in
    # [llm_start - 0.5s, llm_done]; among candidates pick the one whose
    # FIRST DECODED TOKEN aligns with the product's llm_first_token at the
    # epoch's consensus offset (unique even through queue waits).
    for t in turns:
        stages = t.get("stages") or {}
        ll = stages.get("llm_start")
        if not ll or t.get("_epoch") is None or t["_epoch"] >= len(epochs):
            continue
        ep = epochs[t["_epoch"]]
        ll_wall = datetime.strptime(ll, "%Y-%m-%d %H:%M:%S,%f").timestamp()
        ft = stages.get("llm_first_token")
        ft_wall = (datetime.strptime(ft, "%Y-%m-%d %H:%M:%S,%f").timestamp()
                   if ft else None)
        ld = stages.get("llm_done")
        ld_wall = (datetime.strptime(ld, "%Y-%m-%d %H:%M:%S,%f").timestamp()
                   if ld else ll_wall + 600)
        cands = []
        for task in tasks_sorted(ep):
            if "pe_tokens" not in task:
                continue
            add_el = task.get("add_elapsed")
            if add_el is None:
                add_el = task["launch_elapsed"]
            add_wall = ep["wall0"] + add_el
            if not (ll_wall - 0.6 <= add_wall <= ld_wall + 0.6):
                continue
            if ft_wall is not None and "first_gen_elapsed" in task:
                off = ft_wall - task["first_gen_elapsed"]
            else:
                off = ll_wall - add_el
            cands.append((abs(off - ep["wall0"]), off, task))
        if cands:
            cands.sort(key=lambda c: c[0])
            t["_task"] = cands[0][2]

    # background tasks: server tasks NOT matched to any product turn
    matched_ids = {(t["_epoch"], t["_task"]["id"]) for t in turns if t.get("_task")}
    background_tasks = []
    for ep_i, ep in enumerate(epochs):
        for task in tasks_sorted(ep):
            if (ep_i, task["id"]) not in matched_ids and "pe_tokens" in task:
                bg = dict(task)
                bg["epoch"] = ep_i
                bg["wall"] = ep["wall0"] + task["launch_elapsed"]
                background_tasks.append(bg)

    # contention intervals: gate events around turns
    gate_events = session.get("gate_events") or []
    gate_by_wall = []
    for g in gate_events:
        try:
            gate_by_wall.append((datetime.strptime(g["ts"], "%Y-%m-%d %H:%M:%S,%f").timestamp(), g))
        except ValueError:
            pass
    gate_by_wall.sort(key=lambda x: x[0])

    def gate_window(turn: dict) -> dict | None:
        ts = turn.get("ts")
        if not ts:
            return None
        t0 = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S,%f").timestamp()
        ft = (turn.get("stages") or {}).get("llm_first_token")
        t1 = datetime.strptime(ft, "%Y-%m-%d %H:%M:%S,%f").timestamp() if ft else t0 + 60
        inside = [g for w, g in gate_by_wall if t0 - 90 <= w <= t1]
        return {"n": len(inside),
                "kinds": sorted({g["kind"] for g in inside}),
                "events": [{"ts": g["ts"], "kind": g["kind"], "msg": g["msg"][:100]}
                           for g in inside]} if inside else None

    # ---- build the correlation rows ----------------------------------------
    rows = []
    for i, t in enumerate(turns):
        task = t.get("_task")
        driver_rec = driver[i] if i < len(driver) else None
        g = {
            "idx": t["idx"],
            "label": (driver_rec or {}).get("label", f"turn{t['idx']}"),
            "ts": t["ts"],
            "source": t.get("source"),
            "gaps_ms": t.get("gaps_ms"),
            "verdict_s8": t.get("verdict"),
            "bg_during": t.get("bg_during"),
            "bg_before": t.get("bg_before"),
            "task_id": task["id"] if task else None,
            "epoch": t.get("_epoch"),
        }
        if task:
            q_wait = None
            if task.get("add_elapsed") is not None and "launch_elapsed" in task:
                q_wait = round((task["launch_elapsed"] - task["add_elapsed"]) * 1000.0, 0)
            g.update({
                "prompt_tokens_new": task.get("pe_tokens"),
                "prompt_tokens_total": task.get("prompt_tokens"),
                "cached_prefix_tokens": task.get("cached_tokens"),
                "prompt_eval_ms": task.get("pe_ms"),
                "prompt_eval_tps": task.get("pe_tps"),
                "gen_tokens": task.get("ge_tokens"),
                "gen_ms": task.get("ge_ms"),
                "gen_tps": task.get("ge_tps"),
                "server_total_ms": task.get("total_ms"),
                "server_queue_wait_ms": q_wait,
                "slot_decision": ({k: v for k, v in (task.get("slot_decision") or {}).items()
                                   if k != "elapsed"}),
            })
        gw = gate_window(t)
        if gw:
            g["gate_window"] = gw
        rows.append(g)

    out = {
        "generated": datetime.now().isoformat(timespec="seconds"),
        "session": {"turns_total": session["turns_total"],
                    "outliers": session["outliers"],
                    "distributions_ms": session["distributions_ms"],
                    "gate_deferred_total": session["gate_deferred_total"],
                    "gate_requeue_total": session["gate_requeue_total"]},
        "epochs": [{"idx": e["idx"], "wall0": e["wall0"],
                     "tasks": len(e["tasks"]),
                     "first_task_wall": (datetime.fromtimestamp(
                         e["wall0"] + e["task_order"][0] * 0 + 0).isoformat()
                         if e["task_order"] else None)}
                    for e in epochs],
        "background_tasks": [{
            "epoch": b["epoch"], "task_id": b["id"],
            "wall": datetime.fromtimestamp(b["wall"]).strftime("%H:%M:%S,%f")[:-3],
            "prompt_tokens_new": b.get("pe_tokens"),
            "prompt_tokens_total": b.get("prompt_tokens"),
            "prompt_eval_tps": b.get("pe_tps"),
            "gen_tokens": b.get("ge_tokens"),
            "gen_tps": b.get("ge_tps"),
            "total_ms": b.get("total_ms"),
            "slot_decision": ({k: v for k, v in (b.get("slot_decision") or {}).items()
                               if k != "elapsed"}),
        } for b in background_tasks],
        "turns": rows,
    }
    (OUT_DIR / "s8_correlation.json").write_text(
        json.dumps(out, indent=1, ensure_ascii=False), encoding="utf-8")

    # ---- markdown table -----------------------------------------------------
    lines = []
    hdr = ("| turn | label | wall | task | epoch | p_new/p_total | prompt t/s | "
           "gen tok | gen t/s | server total | llm_wait | verdict | conclusion |")
    lines.append(hdr)
    lines.append("|" + "---|" * 13)
    for r in rows:
        g = r["gaps_ms"] or {}
        task = r.get("task_id")
        pn = r.get("prompt_tokens_new")
        pt = r.get("prompt_tokens_total")
        ptps = r.get("prompt_eval_tps")
        gn = r.get("gen_tokens")
        gtps = r.get("gen_tps")
        st = r.get("server_total_ms")
        lw = g.get("llm_wait_ms")
        lines.append(
            f"| {r['idx']} | {r['label']} | {r['ts'][11:23]} | {task if task is not None else '-'} "
            f"| {r.get('epoch', '-')} | {pn if pn is not None else '-'}/{pt if pt is not None else '-'} "
            f"| {round(ptps,1) if ptps else '-'} | {gn if gn is not None else '-'} "
            f"| {round(gtps,2) if gtps else '-'} | {round(st/1000,1) if st else '-'}s "
            f"| {round(lw/1000,1) if lw else '-'}s | {r.get('verdict_s8')} | |")
    (OUT_DIR / "s8_correlation_table.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"turns: {len(rows)}; epochs: {len(epochs)}; "
          f"background tasks: {len(background_tasks)}")
    for r in rows:
        print(r["label"], "task", r.get("task_id"), "gen_tps", r.get("gen_tps"),
              "llm_wait", (r.get("gaps_ms") or {}).get("llm_wait_ms"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
