| turn | label | wall | task | epoch | p_new/p_total | prompt t/s | gen tok | gen t/s | server total | llm_wait | verdict | conclusion |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | T1_cold | 12:06:05,927 | 4 | 0 | 253/254 | 79.7 | 13 | 9.35 | 4.5s | 3.2s | REAL_LLM_LATENCY | |
| 2 | T2_warm | 12:06:15,772 | 18 | 0 | 40/290 | 44.7 | 26 | 9.35 | 3.6s | 0.9s | normal | |
| 3 | T3_warm | 12:06:21,943 | 45 | 0 | 48/334 | 54.8 | 27 | 7.23 | 4.5s | 0.9s | normal | |
| 4 | T4_warm | 12:06:28,992 | 73 | 0 | 55/385 | 52.2 | 62 | 7.21 | 9.5s | 1.1s | normal | |
| 5 | T5_contention | 12:07:01,642 | 204 | 0 | 88/469 | 49.7 | 28 | 7.2 | 5.5s | 11.9s | CONTENTION_CONFIRMED | |
| 6 | T6_evicted | 12:07:19,888 | 308 | 0 | 322/492 | 61.9 | 17 | 7.46 | 7.3s | 12.7s | CONTENTION_SUSPECT_OR_CACHE_EVICTED | |
| 7 | T7_warm | 12:09:47,104 | 4 | 1 | 253/254 | 77.9 | 9 | 7.91 | 4.3s | 3.3s | REAL_LLM_LATENCY | |
| 8 | T8_slowcompute | 12:09:55,977 | 14 | 1 | 40/290 | 9.5 | 98 | 0.38 | 259.6s | 4.2s | normal | |
| 9 | T9_slowcompute | 12:14:18,302 | 113 | 1 | 131/417 | 18.7 | 51 | 1.61 | 38.1s | 7.0s | REAL_LLM_LATENCY | |
| 10 | T10_recovery | 12:14:59,244 | 165 | 1 | 326/496 | 63.5 | 19 | 7.02 | 7.7s | 5.2s | REAL_LLM_LATENCY | |
| 11 | C1_baseline | 12:21:25,845 | 514 | 1 | 22/259 | 44.7 | 14 | 9.26 | 1.9s | 0.5s | normal | |
| 12 | C2_mildload | 12:21:32,287 | 529 | 1 | 45/300 | 30.0 | 153 | 5.63 | 28.5s | 1.5s | normal | |
| 13 | C3_recovery | 12:22:03,473 | 683 | 1 | 237/478 | 61.8 | 26 | 8.19 | 6.9s | 3.9s | normal | |