#!/usr/bin/env python
"""S8 forensic session driver v3 (sandbox, 2026-09-18, two-phase).

Phase A (contention + eviction, ONE llama-server epoch):
  T1 cold full-prefill turn          -> REAL_LLM_LATENCY class (prefill cost)
  T2-T4 consecutive warm turns       -> normal, cache hits
  T5 turn DURING background ingest   -> CONTENTION_CONFIRMED (cooperative
                                        cancel mid-chain, slot yield)
  T6 immediate follow-up             -> re-prefill after the cancelled
                                        chain displaced the slot cache

Phase B (slow-compute, fresh llama-server epoch, fresh product session;
2 s gaps so the background gate never opens mid-phase):
  T7 warm baseline turn              -> normal (fresh epoch, cold prefill)
  T8 turn under 1 CPU load           -> REAL_LLM_LATENCY with reduced
                                        server-side prompt-eval AND eval t/s
  T9 turn under 2 CPU loads          -> generation in the ~5-6 t/s class
                                        (baseline ~8 t/s — the sandbox analog
                                        of the target's 12-15 -> 5-6 drop)
  T10 recovery turn                   -> throughput back at baseline

Sends ONLY {"type": "user_text"} frames over the product's own WS API —
no product code or configuration is touched. Usage:
    s8_session_driver.py a|b
"""
import asyncio
import json
import subprocess
import sys
import time
from pathlib import Path

import httpx
import websockets

WS_URL = "ws://127.0.0.1:8788/ws"
PRODUCT_LOG = Path("/home/z/my-project/voicemem-agent/logs/web-server.log")
RECORD = Path("/home/z/my-project/.zscripts/s8_session_record.jsonl")
HTTP = httpx.Client(base_url="http://127.0.0.1:8788", timeout=30)

TURNS_A = [
    ("T1_cold", "Szia! Hogy vagy ma?", None, 3.0),
    ("T2_warm", "Mi a kedvenc ételem, emlékszel?", None, 2.0),
    ("T3_warm", "És a kutyám neve?", None, 2.0),
    ("T4_warm", "Mesélj valamit a hétvégéről!", None, None),  # -> contention
    ("T5_contention", "És most mesélj valamit magadról!", "wait_ingest", 2.0),
    ("T6_evicted", "Rendben, köszi, értem!", None, 0.0),
]

TURNS_B = [
    ("T7_warm", "Szia, itt vagy még?", None, 2.0),
    ("T8_slowcompute", "Meséld el még egyszer, mi a kedvenc ételem!", "stress1", 2.0),
    ("T9_slowcompute", "És mit szoktunk csinálni nyáron a Balatonnál?", "stress2", 2.0),
    ("T10_recovery", "Köszönöm szépen a beszélgetést!", None, 0.0),
]

#: calibrated 2026-09-18 against the live server: 2x duty-50% loops
#: (~1.0 core of demand against llama's 2 threads) drops generation
#: 8.4 -> ~4.7 t/s — the sandbox analog of the target's 12-15 -> 5-6
#: t/s foreground-generation drop, WITHOUT thrashing the page cache.
TURNS_C = [
    ("C1_baseline", "Szervusz, miben segíthetek ma?", None, 2.0),
    ("C2_mildload", "Mesélj részletesen a nyári terveinkről!", "duty2x50", 2.0),
    ("C3_recovery", "Köszönöm, ez minden volt mára!", None, 0.0),
]

STRESS = []


def log(msg: str) -> None:
    print(f"[driver {time.strftime('%H:%M:%S')}] {msg}", flush=True)


def emit(kind: str, data: dict) -> None:
    data = {"kind": kind, "wall": time.time(),
            "wall_iso": time.strftime("%Y-%m-%d %H:%M:%S"), **data}
    with RECORD.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(data, ensure_ascii=False) + "\n")


def memories_count() -> int:
    try:
        snap = HTTP.get("/api/memories").json()
        return len(snap.get("left") or []) + len(snap.get("right") or [])
    except Exception as exc:  # noqa: BLE001
        log(f"memories poll failed: {exc}")
        return -1


def _free_mb() -> int:
    try:
        with open("/proc/meminfo") as fh:
            for line in fh:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) // 1024
    except OSError:
        return -1
    return -1


async def wait_log_marker(substr: str, timeout: float, poll: float = 0.5) -> str:
    """Poll the product log until a NEW line containing `substr` appears."""
    deadline = time.monotonic() + timeout
    pos = PRODUCT_LOG.stat().st_size
    while time.monotonic() < deadline:
        await asyncio.sleep(poll)
        size = PRODUCT_LOG.stat().st_size
        if size < pos:
            pos = 0  # rotation
        if size > pos:
            with PRODUCT_LOG.open(encoding="utf-8", errors="replace") as fh:
                fh.seek(pos)
                new = fh.read()
                pos = fh.tell()
            for line in new.splitlines():
                if substr in line:
                    return line
    raise TimeoutError(f"marker {substr!r} not seen in {timeout:.0f}s")


async def turn(ws, label: str, text: str, retries: int = 2) -> dict:
    t0 = time.time()
    await ws.send(json.dumps({"type": "user_text", "text": text}))
    timings = None
    reply_len = 0
    error = None
    while True:
        raw = await asyncio.wait_for(ws.recv(), timeout=300)
        msg = json.loads(raw)
        mtype = msg.get("type")
        if mtype == "answer_done":
            timings = msg.get("timings") or {}
            reply_len = msg.get("reply_len") or 0
            error = msg.get("error") or None
            break
        if mtype == "error":
            error = msg.get("message")
            break
        if mtype == "pipeline_status":
            continue
    if error and retries > 0 and ("503" in str(error) or "peer closed" in str(error)):
        log(f"{label}: transient server restart ({str(error)[:60]}) — retry in 8s")
        await asyncio.sleep(8)
        return await turn(ws, label, text, retries - 1)
    rec = {"label": label, "text": text, "sent_at": t0,
           "done_at": time.time(), "timings": timings,
           "reply_len": reply_len, "error": error,
           "free_mb": _free_mb()}
    emit("turn", rec)
    log(f"{label}: done in {rec['done_at']-t0:.1f}s (error={error}) "
        f"free={rec['free_mb']}MB timings={json.dumps(timings)}")
    return rec


def start_stress(n: int) -> None:
    for _ in range(n):
        p = subprocess.Popen(
            ["/home/z/.venv/bin/python", "-c", "while True: pass"])
        STRESS.append(p)
    log(f"stress ON ({n} busy loop processes)")


def start_duty(n: int, on: float, off: float) -> None:
    for _ in range(n):
        p = subprocess.Popen([
            "/home/z/.venv/bin/python", "-c",
            f"import time\nwhile True:\n"
            f"    t=time.perf_counter()\n"
            f"    while time.perf_counter()-t < {on}: pass\n"
            f"    time.sleep({off})\n",
        ])
        STRESS.append(p)
    log(f"stress ON ({n} duty-{on}/{off} loops)")


def stop_stress() -> None:
    for p in STRESS:
        p.kill()
    STRESS.clear()
    time.sleep(0.5)
    log("stress OFF")


async def run_phase(tURNS: list, phase: str) -> None:
    async with websockets.connect(WS_URL, max_size=2**22) as ws:
        ready = json.loads(await ws.recv())
        log(f"session ready ({phase}): {ready}")
        emit(f"{phase}_start", {"turns": len(tURNS),
                               "memories": memories_count(),
                               "free_mb": _free_mb()})
        for label, text, action, wait_s in tURNS:
            if action == "wait_ingest":
                log(f"[{label}] waiting for gate open + ingest start ...")
                await wait_log_marker("background memory gate open", 90)
                line = await wait_log_marker(
                    "background memory ingest started", 180)
                log(f"[{label}] ingest started: {line[-90:]}")
                await asyncio.sleep(4.0)  # extraction LLM leg mid-flight
            elif action == "stress1":
                start_stress(1)
            elif action == "stress2":
                start_stress(2)
            elif action == "duty2x50":
                start_duty(2, 0.5, 0.5)
            await turn(ws, label, text)
            stop_stress()
            if wait_s is not None:
                log(f"[{label}] idle {wait_s}s")
                await asyncio.sleep(wait_s)
        emit(f"{phase}_end", {"memories": memories_count(),
                              "free_mb": _free_mb()})


async def main() -> int:
    phase = (sys.argv[1] if len(sys.argv) > 1 else "a").lower()
    if phase == "a":
        RECORD.write_text("")  # fresh record per capture
        await run_phase(TURNS_A, "phaseA")
    elif phase == "b":
        await run_phase(TURNS_B, "phaseB")
    else:
        await run_phase(TURNS_C, "phaseC")
    log(f"PHASE {phase.upper()} COMPLETE")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
