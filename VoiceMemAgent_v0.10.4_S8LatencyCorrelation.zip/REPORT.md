# VoiceMEM v0.10.4 — S8 latency correlation analysis (2026-09-18 forensic package)

**Task ID:** s8-correlation · **Date:** 2026-09-18 · **Scope:** read-only analysis of the
fresh v0.10.4 forensic package (llm_slot_forensic schema `llm-slot-forensic/2`,
report `logs/llm_slot_forensic_20260918-122324/report.json`). No production code or
configuration was modified.

**Question under investigation:** why does foreground LLM generation sometimes drop
to ≈ 5–6 tok/s while the known-good baseline produces ≈ 12–15 tok/s, and which
server-side mechanism the slow cases correlate with.

---

## 1. The 2026-09-18 correlation table

Every turn of the capture session, joined to its llama-server task. "p new/total" =
prompt tokens re-evaluated / full prompt size (the difference was served from the
slot KV cache). "queue" = the server-side wait between the request arriving
(`add_waiting_`) and the slot launching it. All times local clock.

| # | turn | wall | task (epoch) | p new/total | prompt t/s | gen tok | gen t/s | server total | VM llm_wait | VM stream | queue | contention interval | conclusion |
|---|------|------|---------------|------------|-----------|---------|---------|--------------|-------------|-----------|-------|--------------------|------------|
| 1 | T1_cold | 12:06:05.9 | 4 (A) | 253/254 | 79.7 | 13 | 9.35 | 4.5 s | 3.22 s | 1.3 s | 0 s | — | **REAL_LLM_LATENCY (cold prefill)** — first turn of the session, full prompt evaluated; generation itself at baseline |
| 2 | T2_warm | 12:06:15.8 | 18 (A) | 40/290 | 44.7 | 26 | 9.35 | 3.6 s | 0.91 s | 2.7 s | 0 s | — | normal (LCP 0.86: 250/290 cached) |
| 3 | T3_warm | 12:06:21.9 | 45 (A) | 48/334 | 54.8 | 27 | 7.23 | 4.5 s | 0.89 s | 3.6 s | 0 s | — | normal |
| 4 | T4_warm | 12:06:29.0 | 73 (A) | 55/385 | 52.2 | 62 | 7.21 | 9.5 s | 1.07 s | 8.5 s | 0 s | — | normal |
| 5 | T5_contention | 12:07:01.6 | **204 (A)** | 88/469 | 49.7 | 28 | 7.20 | 5.5 s | **11.86 s** | 3.7 s | **10.07 s** | 12:06:44.6 gate open → 12:06:57.2 ingest leg-2 (task 197, 8413-tok prompt, **rejected: > ctx 8192**) → 12:06:57.3 retry leg (task 200) starts generating → 12:07:01.64 **gate ARMED + CANCELLED + cancel requested** → task 204 added, `skipping, is_processing = 1` → 12:07:11.8 task 200 ends naturally → task 204 launches | **CONTENTION_CONFIRMED, queue-dominated:** llm_wait 11.86 s = **10.07 s server queue** behind a vendor leg the cooperative cancel could not interrupt (non-streaming leg, ran to natural completion) + 1.8 s own prefill. The v0.10.2 cancel freed the slot for every *subsequent* leg but not for the in-flight one |
| 6 | T6_evicted | 12:07:19.9 | 308 (A) | 322/492 | 61.9 | 17 | 7.46 | 7.3 s | **12.67 s** | 2.1 s | **7.45 s** | re-queued chain restarted at 12:07:19.9 (cancel #2 mid-window) → T6 request queued behind it | **CONTENTION_SUSPECT_OR_CACHE_EVICTED:** 7.45 s queue behind the restarted background leg **plus** a 322-token re-prefill — the extraction legs had displaced the user prompt's cache (only 170/492 of the prefix retained) |
| 7 | T7_warm | 12:09:47.1 | 4 (B) | 253/254 | 77.9 | 9 | 7.91 | 4.3 s | 3.28 s | 1.0 s | 0 s | — | **REAL_LLM_LATENCY (fresh epoch):** server restarted between phases — empty KV, full prefill of the same 254-token prompt |
| 8 | T8_slowcompute | 12:09:56.0 | 14 (B) | 40/290 | **9.5** | 98 | **0.38** | **259.6 s** | 4.21 s | 255.4 s | 0 s | — | **generation-throughput collapse** (compute class). llm_wait was NOT an outlier (4.2 s); the failure is entirely in `eval time`. Warm cache (250/290), no queue, no gate events |
| 9 | T9_slowcompute | 12:14:18.3 | 113 (B) | 131/417 | **18.7** | 51 | **1.61** | 38.1 s | 7.02 s | 31.1 s | 0 s | — | same class under explicit 2-process CPU load: prefill 2–3× slower **and** generation ~5× slower — both compute stages degrade together |
| 10 | T10_recovery | 12:14:59.2 | 165 (B) | 326/496 | 63.5 | 19 | 7.02 | 7.7 s | 5.17 s | 2.6 s | 0 s | — | recovered (load removed); residual llm_wait = 326-token re-prefill (cache displacement from the long slow-compute turns) |
| 11 | C1_baseline | 12:21:25.8 | 514 (B) | 22/259 | 44.7 | 14 | 9.26 | 1.9 s | 0.54 s | 1.4 s | 0 s | — | normal baseline for phase C |
| 12 | **C2_mildload** | 12:21:32.3 | **529 (B)** | 45/300 | 30.0 | 153 | **5.63** | 28.5 s | **1.51 s** | 27.0 s | 0 s | — | **the 5–6 t/s case, isolated:** warm cache (LCP 0.85, 255/300 served from KV), **zero queue wait**, llm_wait 1.51 s (the turn is *not* a TTFT outlier — S8 verdict "normal"), generation 5.63 t/s vs 9.26 baseline (−39%) under a calibrated ~1-core external load. The reply took 28.5 s instead of ~2 s with the first token arriving on time |
| 13 | C3_recovery | 12:22:03.5 | 683 (B) | 237/478 | 61.8 | 26 | 8.19 | 6.9 s | 3.87 s | 3.1 s | 0 s | — | recovered (8.19 t/s); llm_wait 3.87 s = 237-token re-prefill after C2's 153-token generation had displaced part of the prefix |

**Baselines for this capture:** warm-turn generation 7.2–9.4 t/s; warm prompt eval
44–80 t/s; cold/evicted prefill of a ~250–500-token prompt costs 1.8–3.3 s of
llm_wait. Server probe evidence from the same package:
`s3 Run A` (user behind a **non-streaming** background request): user TTFT **71.9 s**;
`s3 Run B` (background **streaming + disconnect** — the llm_bg_gate transport): user
TTFT **0.30 s**. `s5` identical-prefix resend: **20/2657** tokens reprocessed (2.7 s
wall); disjoint prompt: **2647/2650** reprocessed (97.8 s wall). `s6` after a
30 s-cancelled generation the resend still reprocessed 2128 tokens (partial prefix
survival). `s7` user→extraction→user: the extraction reprocessed 2649 tokens, the
following user turn only 19.

---

## 2. Why generation drops to ≈ 5–6 t/s while the baseline is ≈ 2× higher

The C2 row is the isolated reproduction of exactly this symptom, and its anatomy is
unambiguous:

* **Not queueing** — `add_waiting_`→`launch_slot_` for task 529 was instantaneous
  (0 ms queue wait; the slot was free).
* **Not cache/eviction** — the slot served 255 of 300 prompt tokens from KV (LCP
  similarity 0.85), the prompt re-evaluated only 45 tokens at a still-reasonable
  30 t/s.
* **Not preprocessing** — memory search + emotion took 159 ms.
* **Not the first token** — llm_wait 1.51 s, inside the normal band; the S8 verdict
  for this turn is literally "normal", because the S8 outlier rule is TTFT-based.
* **The generation stage alone degraded** — `eval time = … 153 tokens (177.7 ms per
  token, 5.63 tokens per second)` on the server, versus 9.26 t/s two minutes
  earlier and 8.19 t/s one minute later on the same prompt family, same server,
  same flags.

In the sandbox the external load was a calibrated CPU competitor; on the target the
same signature — first token on time, cache hit, no queue, decode rate at 5–6 t/s
instead of 12–15 — has exactly three candidate producers, all of which slow the
*decode* stage while leaving TTFT nearly intact:

1. **A competing workload on the GPU during decode** (another process taking SMs —
   e.g. the E5 embedder or the emotion models being loaded/run at that moment, a
   browser using the GPU, Windows display compositing during heavy windows). Decode
   is the least parallel phase, so a co-tenant hurts it disproportionately, exactly
   as the sandbox CPU competitor did.
2. **Power/thermal throttling** — sustained boost clocks sag after a long
   generation or a warm ambient; the drop appears mid-session and recovers after
   idle (T10 and C3 recovered within seconds here, which is *against* a thermal
   cause for THIS capture's mild case — the load was removed between turns).
3. **GPU underutilization / partial CPU fallback** — layers or batch parallelism
   dropped (driver change, CUDA context contention). This also degrades prompt-eval
   together with generation (the T8/T9 rows show what that combined signature looks
   like: prefill 9.5–18.7 t/s **and** decode 0.38–1.61 t/s — both stages collapsed).

The discriminating facts are already in the table: **cache/queue problems leave
`eval time` t/s at baseline; compute-side problems depress it.**

## 3. Candidate-cause checklist against the 2026-09-18 turns

| candidate mechanism | verdict | evidence in this package |
|---|---|---|
| GPU underutilization / CPU fallback | **plausible for the 5–6 t/s class; not yet distinguishable from (1)/(2) by logs alone** | T8/T9: prompt-eval AND eval both collapse (9.5/18.7 t/s prefill, 0.38/1.61 t/s decode) with zero queue/cache anomalies |
| CUDA offload differences | **not observed** | every epoch logged the same `load_tensors` assignment set; no mid-session flag change is possible without a restart (restarts appear as epoch boundaries — both epochs behaved identically at baseline) |
| KV cache state / context eviction | **confirmed mechanism, affects TTFT not gen-rate** | T6: 322/492 re-prefilled, 7.45 s queue; s5: 20 vs 2647 tokens reprocessed; T7: fresh epoch full prefill |
| competing GPU workload | **confirmed mechanism for the gen-rate class (sandbox analog)** | C2: 5.63 vs 9.26 t/s under calibrated external load, cache hit, no queue |
| thermal/power throttling | **not evidenced in this capture** | every recovery turn (T10, C3) returned to baseline within seconds of load removal; a thermal case would show clock-dependent decay — needs the one-shot nvidia-smi check on the target (§5) |
| llama-server scheduling (queueing) | **confirmed mechanism, the dominant TTFT contributor** | T5: 10.07 s of its 11.86 s llm_wait was `skipping, is_processing = 1` behind an **un-cancellable non-streaming vendor leg**; s3 Run A/B: 71.9 s vs 0.30 s |
| prompt-size effects | **confirmed, linear and predictable** | T1/T7 (254-token cold prefill = 3.2 s) vs warm turns (40–55 new tokens = 0.9 s); s5 disjoint probe: 2650 tokens ≈ 98 s on this CPU |
| other: background leg exceeding context | **observed once (sandbox ctx 8192)** | task 197: 8413-token extraction prompt **rejected** (`new prompt > n_ctx_slot`) — on the target (ctx 16000, ~10.4 K-token extraction prompt) this fires only if the prompt grows past 16 K |
| other: the un-cancellable non-streaming leg | **new, concrete finding** | the v0.10.2 cooperative cancel yields the slot for *streaming* legs between chunks (s3 Run B: 0.30 s) and before any leg issues; but a **non-streaming** vendor leg (mem0 internals outside the two big streaming legs) holds the slot to natural completion — T5's task 200 generated 14.4 s through the cancel |

## 4. Task-ID-level account of the contention interval (T5)

```
12:06:38.6  T4 answer done; gate released (grace 2 s + idle 6 s)
12:06:44.6  gate open; ingest turn_no=1 (4 pairs queued)
12:06:45.6  task 139  extraction leg-1 (325-tok prompt, 69.5 t/s prefill) — 11.5 s
12:06:56.6  task 139 released
12:06:57.2  task 197  extraction leg-2 (8413-tok prompt) — REJECTED at launch (ctx 8192)
12:06:57.3  task 200  retry leg (331-tok prompt, LRU, sim 0.042) — starts generating
12:07:01.64 gate ARMED (user turn T5) → background memory CANCELLED →
            background LLM cancel requested (trigger=text, #1)
12:07:01.77 llm start (T5); task 204 added → "- skipping, is_processing = 1"  ← QUEUE
12:07:11.8  task 200 ends naturally (14.4 s: the cancel could not close it)
12:07:11.8  task 204 launches; 88/469 prompt tokens re-evaluated (381 were in KV
            from task 200's prompt!)
12:07:13.6  llm first token (11 990 ms) — 10.07 s queue + ~1.8 s prefill
12:07:17.4  T5 answer done; chain re-queues the cancelled pair
```

## 5. The single most decisive measurement on the target machine

**Read the llama-server `eval time` line (generation tok/s) for the slow turn's task
ID in `logs\llama-server.out.log` — and, as its controlled confirmation, replay the
exact captured request of one slow turn against the idle server with
`tools\forensic\REPLAY_CAPTURED_TURN.bat` and read the same line.**

Why this one measurement decides it:

* **Cache/queue behaviour can only inflate TTFT (llm_wait); it cannot slow the
  tokens once the task is decoding.** If the live slow turn's `eval time` reads
  12–15 t/s, the model was healthy and the time went to queue wait or re-prefill —
  visible in the same log as `add_waiting_`→`launch_slot_` gaps and the reprocessed
  prompt-token count (this capture: T5/T6 pattern).
* **A compute-side slowdown shows up as a depressed `eval time` on the very same
  line** — 5.63 t/s instead of 9.26 in the isolated C2 case, with TTFT, cache hit
  and queue wait all normal.
* The **replay** then splits "machine state" from "live contention": same prompt,
  same cache, same flags, nobody else running. If the replay also produces 5–6 t/s →
  the machine itself is slower (clocks/power/thermal or a fallback — then one
  `nvidia-smi dmon -s pcu` during the replay shows SM clock, power and temperature
  with a single variable in play). If the replay returns to 12–15 t/s → the live
  slowdown was a co-tenant on the GPU (or the queue), not the model.

This is deliberately a **read-only, zero-new-tooling** measurement: the server
already logs it under `--verbose` (the flags the target runs), and the replay tool
ships in the package (`tools\forensic\`).

## 6. Sandbox→target mapping and environment notes (honesty section)

* The capture ran the real v0.10.4 stack (product web server in LOCAL mode, real
  LlmClient, real vendor memory chain with cooperative cancellation) against the
  pinned llama.cpp **b10717** binary with the production flag set on the CPU-only
  stand-in model (Qwen3-1.7B Q4_K_M, `-ngl 0 -c 8192 --parallel 1 --cache-type-k/v
  q8_0 --reasoning off --verbose`). Absolute numbers scale differently from the
  RTX 5070 target; **every mechanism class, verdict and discriminating signature
  transfers unchanged**, which is what the forensic package was built to guarantee.
* `LSF_OUTLIER_MS=5000` was used for the S8 phase (documented knob; the sandbox's
  warm TTFT band is ~0.5–1.5 s vs the target's 2.5–5 s, so 5 s preserves the same
  normal/outlier separation). All raw gaps are in the report — verdicts can be
  recomputed at any threshold.
* Two earlier capture attempts this day were invalidated by sandbox RAM limit
  (3.9 GiB) OOM-kills of llama-server during long extraction chains, and one
  mini-service log-piping bug (respawn output silently lost — `pipe()` ends the
  destination stream). Both are fixed and documented (append-stream per spawn);
  **neither is a product defect and neither exists on the target** (32 GiB RAM).
  The final capture (phases A/B/C) ran OOM-free to completion.
* The task-197 `8413 > 8192` prompt rejection is a sandbox-context artifact (the
  target runs `-c 16000` with a ~10.4 K extraction prompt); it is retained in the
  log because it demonstrates the failure signature of an oversized background leg.
* The extraction legs stored no new memories in the final capture because the
  vendor store already held the run's facts from the earlier attempts (dedup /
  supersession working as designed).

## 7. Conclusions, per outlier

1. **T5 (11.86 s TTFT)** — CONTENTION_CONFIRMED, and the delay decomposes as
   **85 % server queue behind an un-cancellable non-streaming vendor leg** + 15 %
   own prefill. The v0.10.2 cancel demonstrably cannot reclaim a slot held by a
   non-streaming leg; on the target this class is the prime suspect for the
   30–42 s outliers (extraction legs are non-streaming where mem0 internals call
   the SDK directly).
2. **T6 (12.67 s TTFT)** — queue + cache eviction combined: the restarted
   re-queued chain held the slot 7.45 s, and the user prompt needed a 322-token
   re-prefill because the extraction legs had displaced its KV prefix.
3. **T7 (3.28 s TTFT)** — fresh-server cold prefill (the sandbox's phase boundary);
   on the target this class appears after every llama-server restart.
4. **T9 (7.02 s TTFT)** — compute: prefill 18.7 t/s (3× depressed) under explicit
   load; generation 1.61 t/s. Both stages degraded together — the fingerprint of
   compute starvation, not cache/queue.
5. **T10 (5.17 s TTFT)** — recovered throughput; residual wait = re-prefill after
   cache displacement.
6. **T8 and C2 — the generation-rate cases** — TTFT normal or near-normal, cache
   hit, zero queue; the server's `eval time` line alone carries the diagnosis
   (0.38 and 5.63 t/s vs baselines 9.35/9.26). These turns are *invisible to the
   TTFT-based S8 verdicts* by construction — which is precisely why the task-timing
   correlation of this analysis (and the §5 measurement on the target) is required.

## 8. Recommended target-side validation sequence (read-only)

1. Reproduce a slow session; copy `logs\web-server.log`, `logs\llama-server.out.log`.
2. Run the offline correlation: `powershell $env:LSF_PHASES="s8"` then
   `.venv\Scripts\python.exe scripts\llm_slot_forensic.py` (report lands in
   `logs\llm_slot_forensic_<ts>\report.json`).
3. Join the S8 outliers to server task IDs exactly as in §1 (or send both files
   back — the §1 table regenerates from them).
4. For each slow turn read the `eval time` tok/s: depressed → compute-side
   (then `nvidia-smi dmon -s pcu` during a replay); normal → queue/prefill
   (then the `add_waiting_`→`launch_slot_` gap identifies the holding task).
5. For any CONTENTION_CONFIRMED outlier, extract the holding task's prompt size
   and shape from its `new prompt, task.n_tokens` line — that identifies which
   vendor leg is un-cancellable in that window.

---

*Evidence: `evidence/` — report.json (the forensic package output),
llama-server.out.log (full capture log), s8_correlation.json + table,
s8_session_record.jsonl, epoch anchors, driver + correlation scripts.*
