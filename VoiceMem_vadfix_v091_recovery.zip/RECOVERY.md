# VoiceMem v0.9.1 Recovery Package — Web VAD Speech Onset Fix

**Package:** `VoiceMem_vadfix_v091_recovery.zip`
**Fix:** Web path retains the SPEECH_START trigger frame (CLI parity)
**Baseline:** v0.9.0 (git `bb9e12a`, ZIP SHA256 `528020DE…F40DA`)
**Release:** v0.9.1 (git `25a44d5`, ZIP SHA256 `C4B5AB4B…B22776`)

---

## 1. What was broken

**Measured root cause (forensic, `/home/z/vmforensic`):**

1. The web `_on_vad_frame` speech_start branch ended with an early `return`,
   so the 32 ms frame that crossed the VAD threshold (the **trigger frame**)
   was never appended to the captured utterance.
2. The CLI path (`app/main.py`) retains it: `state.in_speech` is already
   `True` when `SPEECH_START` is returned, and the CLI append loop runs
   immediately after.
3. On sibilant onsets ("Szia") Silero needs **~86 ms** to cross the 0.25
   threshold; losing the trigger frame on top of that turned
   **"Szia" → "Fia"**. Ground truth: audio cut at the VAD start frame
   (trigger frame included) is recognised by Parakeet as
   **"Szia, hogyan vagy!"**; the old capture start (one frame later) is not.

## 2. The fix (minimum safe)

One production line: the early `return` in the speech_start branch of
`WebSession._on_vad_frame` is **removed** (plus an explanatory comment).
The trigger frame now falls through to the capture block and becomes the
FIRST frame of the utterance — exactly CLI semantics. Streaming engines
would also receive it via the feed (start → feed order preserved).

**Untouched:** `vad_threshold` (0.25), `vad_frame_ms` (32),
`vad_hangover_ms` (300), Parakeet engine + decoding, LLM, VoiceMem, TTS.

## 3. Evidence (see `evidence/`)

| Item | Meaning |
| --- | --- |
| `code.diff` | full v0.9.0 → v0.9.1 tracked diff (467 lines incl. tests/version/gate) |
| `gate_record.json` | GREEN gate on the released tree (1236 tests, 0 regressions, 10 pinned env-gap) |
| `forensic_{szia,bolt,gap}_prefix_v090.json` | pre-fix forensic runs (trigger frame dropped) |
| `forensic_{szia,bolt,gap}_postfix_v091.json` | post-fix runs (trigger frame retained) |
| `test_web_vad_trigger_frame.py` | the new regression test (3 tests) |
| `changed_files.txt` | release commit stat |

**Key post-fix measurements** (identical audio, same real Silero/parakeet):

| Case | VAD decision | Capture start | Turns | Onset |
| --- | --- | --- | --- | --- |
| szia | f3 @96 ms, prob 0.5135 — **byte-identical pre/post** | 128 → **96 ms** | 1 → 1 | 'Fia…' → **'Szia…'** |
| bolt | f3 @96 ms, prob 0.7931 — identical | 128 → **96 ms** | 1 → 1 | no loss before/after |
| gap 400 ms | 120-event trace **byte-identical pre/post** | both utterances now start at their trigger frames | 2 → 2 | — |

Post-fix `from_capture` ground-truth transcription **equals** the
`from_vad_start` transcription ("Szia, hogyan vagy!") — the exact target the
pre-fix forensic measurement established.

**Known, intentional, harmless asymmetry (pre-existing, documented):** the
web path still appends the `speech_end` frame (one extra 32 ms TAIL frame vs
CLI — trailing silence, no onset impact). Pinned by
`test_cli_collection_parity`.

## 4. Apply

- **Clean install:** extract `VoiceMemAgent_v0.9.1.zip`, run `START.bat`.
- **In-place upgrade (v0.9.0 → v0.9.1):** extract the ZIP over the existing
  install — single step, no migration (pure capture-semantics change).
- **Manual patch:** `git apply evidence/code.diff` on a v0.9.0 tree, then
  set `VERSION`, `pyproject.toml`, `config/voicemem_config.yaml` and the
  web `PAGE_VERSION` to `0.9.1` (or take them from the diff).

## 5. Verify after applying

1. `python -m unittest tests.unit.test_web_vad_trigger_frame -v` → 3 tests OK.
2. Speak "Szia, hogyan vagy?" — the transcript must start with "Szia"
   (not "Fia").
3. `speech_ms` in the session status now counts the trigger frame
   (+32 ms per utterance vs v0.9.0).
4. One continuous sentence still produces exactly one turn; a natural
   ≥ ~320 ms pause still splits.

## 6. Rollback

Restore `VoiceMemAgent_v0.9.0.zip` (SHA256 `528020DE…F40DA`).
No data, schema or vendor migration is involved.
