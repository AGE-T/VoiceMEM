# models/speaker — M3 beszélő-azonosító (SpeechBrain ECAPA)

**Az M3 mérföldkő modellje.** A beszélő-felismerést (milestones 9. fejezet)
a **speechbrain/spkrec-ecapa-voxceleb** ECAPA-TDNN modell (~23M paraméter,
192-dim embedding, FP32, CPU) adja, a speechbrain `SpeakerRecognition`
interfészén keresztül (Apache-2.0, nem gated — hivatalos SpeechBrain
szervezeti re-host, ~2M letöltés).

## Elvárt fájlok (a `scripts/download_models.ps1` a MODELS.lock.json
`speaker` bejegyzése alapján ide tölti)

| Fájl | Forrás (HF repo) | Elvárt méret |
|------|------------------|--------------|
| `embedding_model.ckpt` | speechbrain/spkrec-ecapa-voxceleb | ~79,5 MB (padló: 80 MB) |
| `hyperparams.yaml` | speechbrain/spkrec-ecapa-voxceleb | ~2 KB |
| `mean_var_norm_emb.ckpt` | speechbrain/spkrec-ecapa-voxceleb | ~2 KB |
| `classifier.ckpt` | speechbrain/spkrec-ecapa-voxceleb | ~5,3 MB |
| `label_encoder.txt` | speechbrain/spkrec-ecapa-voxceleb | ~126 KB |

A repó példahangjait (`example1.wav`, `example2.flac`) a letöltő
SZÁNDÉKOSAN nem tölti (nem futtatási fájl — a sandbox-bizonyíték
használta őket, lásd a worklogot).

**Fontos:** mind az 5 fájl kell — a `hyperparams.yaml` pretrainer blokkja a
betöltéskor mindet hivatkozza. A modell futásidőben a LOKÁLIS könyvtárból
töltődik (`from_hparams(source=<lokális útvonal>)`) — a letöltés után
**nincs hálózati hívás**.

## Konfiguráció / env

- `config.enable_speaker: true` — a modularitási zászló (9.5);
  `VOICEMEM_ENABLE_SPEAKER=0` env-rel kikapcsolható (M1/M2-azonos futás).
- `SPEAKER_MODEL_PATH` env — a modellkönyvtár felülírása.
- `VOICEMEM_SPEAKER_THRESHOLD` env — az azonosítási küszöb finomhangolása.
- Egyéb hangolhatók: `speaker_match_threshold` (0,50, spec 9.3.2),
  `speaker_window_s` (5,0), `speaker_registration_min_s` (10,0).
- Regisztrációs adatbázis: `data/speaker_registry.json`
  (JSON: `{speaker_id: 192-dim átlagolt referencia-embedding}`).

## Küszöb-megjegyzés (0,50)

A spec 9.3.2 a 0,50-es ECAPA-küszöbet pineli — ez KONZERVATÍV választás:
mért kereszthang-koszinusz ~0,13–0,18, azonos beszélő rövid szegmensei
0,37–0,75 (3–5 s ablakban + regisztrációs átlagolással magasabb).
Ismeretlen hang -> `user_id="voice_user"` fallback — a memóriák
SOHA nem keverednek (a kontamináció-elleni biztonság a FRR-t vállalja).
A SpeechBrain saját pár-piros verify-alapértelmezése 0,25 — hangolni a
`speaker_match_threshold`-dal lehet.

## Futás

- **CPU-n fut** (speechbrain, device=CPU) — VRAM-impakt 0 GB
  (hardverpolitika 4.6; a GPU büdzsé változatlan marad).
- Az embedding az utterance utolsó ~5 másodpercén fut, az M2
  proszódia-elemzéssel PÁRHUZAMOSAN; a memória-keresés csak a gyors
  (~30–50 ms célgépen) speaker-lépésre vár (milestones 9.3).
- A feloldott `speaker_id` a VoiceMem `user_id` paraméterébe kerül ->
  beszélőnkénti SQLite + Qdrant memóriatér (9.3.4).
- Regisztráció: `python -m app.main --register-speaker <név>`
  (~10 s tiszta beszéd, átlagolt embedding, idempotens felülírás).
- A hiányzó modell / speechbrain NEM blokkolja az indítást: graceful
  degradation, a pipeline M1/M2-módban fut tovább (`user_id="voice_user"`).

## Licenc

- **Modell** (`spkrec-ecapa-voxceleb`): Apache-2.0 (nem gated) —
  lásd LICENSES.md.
- **speechbrain pip csomag** (futtató): Apache-2.0.
