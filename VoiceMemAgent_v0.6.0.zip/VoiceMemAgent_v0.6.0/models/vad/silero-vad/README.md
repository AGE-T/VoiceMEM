# models/vad/silero-vad — VAD modell

A `silero_vad.onnx` — Silero VAD v6.2.1, CPU-n fut (onnxruntime).

A `scripts/download_models.ps1` tölti ide (HF repo: `snakers4/silero-vad`,
a v6.2.1-es ONNX fájl). A tartalom gitignore-olt.

Az elérés útja az appból: `AgentConfig.silero_vad_path`
(env-felülírás: `SILERO_VAD_PATH`).
