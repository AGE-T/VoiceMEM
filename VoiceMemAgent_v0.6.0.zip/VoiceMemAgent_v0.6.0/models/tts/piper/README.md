# models/tts/piper — Piper TTS hangok

A Piper hangfájlok helye (mind `.onnx` + `.onnx.json` párban):

- `hu_HU-anna-medium.onnx` + `hu_HU-anna-medium.onnx.json` (alap magyar hang)
- `hu_HU-berta-medium.onnx` + `hu_HU-berta-medium.onnx.json` (alternatíva)
- `hu_HU-imre-medium.onnx` + `hu_HU-imre-medium.onnx.json` (alternatíva)
- `en_US-lessac-medium.onnx` + `en_US-lessac-medium.onnx.json` (angol hang)

A `scripts/download_models.ps1` tölti ide (HF repo: `rhasspy/piper-voices`).
A tartalom gitignore-olt.

Az elérés útja az appból: `AgentConfig.voices_dir`
(env-felülírás: `PIPER_VOICES_PATH`).

A `piper.exe` maga NEM itt, hanem a `bin/` könyvtárban él (GPL-elválasztás).
