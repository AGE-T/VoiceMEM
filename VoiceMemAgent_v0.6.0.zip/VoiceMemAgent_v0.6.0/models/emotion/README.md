# models/emotion — M2 proszódia-elemző (emotion2vec+ base)

**Az M2 mérföldkő modellje.** Az érzelmi intelligencia (milestones 8. fejezet)
proszódia-oldalát az **emotion2vec_plus_base** (~90M paraméter, FP32, CPU)
modell adja, a funasr `AutoModel` futtatóján keresztül.

## Elvárt fájlok (a `scripts/download_models.ps1` a MODELS.lock.json
`emotion` bejegyzése alapján ide tölti)

| Fájl | Forrás (HF repo) | Elvárt méret |
|------|------------------|--------------|
| `model.pt` | emotion2vec/emotion2vec_plus_base | ~1,1 GB (padló: 1 GiB) |
| `config.yaml` | emotion2vec/emotion2vec_plus_base | ~3 KB |
| `tokens.txt` | emotion2vec/emotion2vec_plus_base | 9 kategória-címke |
| `configuration.json` | emotion2vec/emotion2vec_plus_base | ~0,3 KB |

A repó képeit (`logo.png`, `emotion2vec+radar.png`) és az `example/` mappát a
letöltő SZÁNDÉKOSAN nem tölti (nem futtatási fájl).

## Konfiguráció / env

- `config.enable_emotion: true` — a modularitási zászló (8.6);
  `VOICEMEM_ENABLE_EMOTION=0` env-rel kikapcsolható (M1-azonos futás).
- `EMOTION2VEC_MODEL_PATH` env — a modellkönyvtár felülírása.
- Egyéb hangolhatók: `emotion_window_s` (5,0), `emotion_fusion_prosody_weight`
  (0,6), `emotion_slow_length_scale` (1,1), `emotion_store_threshold` (0,5).

## Futás

- **CPU-n fut** (funasr AutoModel, device="cpu") — VRAM-impakt 0 GB
  (hardverpolitika 4.6; a GPU büdzsé változatlan marad).
- Az elemzés az utterance utolsó ~5 másodpercén fut, a VoiceMem
  memória-kereséssel PÁRHUZAMOSAN (milestones 8.3).
- A hiányzó modell NEM blokkolja az indítást: graceful degradation,
  a pipeline M1-módban fut tovább.

## Licenc (FONTOS)

Az emotion2vec+ súlyok a **FunASR Model Open Source License Agreement v1.1**
alatt állnak (Alibaba Group): ingyenes használat/copy/megosztáshoz
**attribution kötelező** — a forrás és a szerző megnevezendő, a modell neve
("emotion2vec_plus_base") megtartandó. A teljes szöveg:
https://github.com/alibaba-damo-academy/FunASR (MODEL_LICENSE). A projekt-oldali
attribution a `LICENSES.md` (17. sor) és a README M2-fejezete. A funasr
pip-csomag kódja MIT.
