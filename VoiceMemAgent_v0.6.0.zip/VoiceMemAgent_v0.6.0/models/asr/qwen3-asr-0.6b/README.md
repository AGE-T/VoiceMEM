# models/asr/qwen3-asr-0.6b — ASR modell

A **Qwen3-ASR-0.6B** modellkönyvtár (HF repo: `Qwen/Qwen3-ASR-0.6B`).

A `scripts/download_models.ps1` tölti ide a teljes modellkönyvtárat
(súlyok + `config.json` + tokenizer fájlok). A tartalom gitignore-olt —
a repóba csak ez a README és a `.gitkeep` kerül.

Az elérés útja az appból: `AgentConfig.asr_model_dir`
(env-felülírás: `QWEN3_ASR_MODEL_PATH`).

M1 szigor: a 0.6B modell fut (NEM az 1.7B — az csak későbbi swap-lehetőség).
