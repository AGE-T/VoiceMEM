# models/embedding/multilingual-e5-small — memória-embedding modell

A **intfloat/multilingual-e5-small** modellkönyvtár (384 dimenziós,
többnyelvű embedding) — a VoiceMem hosszú távú memória lokalitása
(Qdrant-be írt vektorok forrása).

A `scripts/download_models.ps1` tölti ide. A tartalom gitignore-olt.

Az elérés útja az appból: `AgentConfig.embedding_model_dir`
(env-felülírás: `EMBEDDING_MODEL_PATH`).
