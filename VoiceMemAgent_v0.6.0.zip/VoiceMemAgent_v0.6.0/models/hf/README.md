# models/hf — Hugging Face cache gyökér (izoláció)

Ez a mappa a HuggingFace cache **projekten belüli izolálására** szolgál —
így semmi nem kerül véletlenszerűen a felhasználói profil alatti
`~/.cache/huggingface`-be. A M0 elv: a repo-gyökér az EGYETLEN
működési egység, minden modell/cache a projekten belül él.

A `config/env.local.ps1` (illetve `env.local.sh`) állítja be:

| Környezeti változó | Érték (repo-gyökérhez képest) |
|---|---|
| `HF_HOME` | `<repo>/models/hf` |
| `HF_HUB_CACHE` | `<repo>/models/hf/hub` |
| `TRANSFORMERS_CACHE` | `<repo>/models/hf/transformers` |

A tartalom (letöltött snapshotok, blobok) gitignore-olt — a telepítés
után a runtime offline env-ek (`HF_HUB_OFFLINE=1`, `TRANSFORMERS_OFFLINE=1`)
miatt a cache csak olvasásra szolgál.
