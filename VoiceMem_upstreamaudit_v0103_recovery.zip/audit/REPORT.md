# VoiceMEM v0.10.3 — UPSTREAM DEEP AUDIT + SELECTIVE PORT + LATENCY FORENSICS

Operator order: P0 DEEP UPSTREAM AUDIT + SELECTIVE PORT (2026-09-16).
Audit target: https://github.com/xzf-thu/VoiceMem @ 6cacb3c1e7fca2679f3bf95451f6b480efd9a783
(HEAD, 2026-09-14, "Add files via upload" — a WeChat PNG asset; the last
CODE commit is a450911, 2026-09-05).
Our pin: e8384e087bd2f44eb05fc7ae1a3c525ea8244179 (tag v0.0.1, package 0.2.3) — 52 commits behind.

---

## FINAL REPORT (the operator's 24 points)

### A. Upstream HEAD
`6cacb3c1` — no code; assets only. Last meaningful: `a450911` "Track
interrupted context by playback timeline" (2026-09-05).

### B. Upstream package version
pyproject stays un-versioned upstream (their release vehicle is the GitHub
repo itself; tags v0.0.1/v0.0.2 exist; v0.0.2 = `1b7cc9a0`, 2026-09-01).
Identity remains the COMMIT, not the version — our pin policy unchanged.

### C. Current vendor pin
`e8384e08` (controlled fork, `vendor/voicemem`, installed `pip install -e
vendor\voicemem`). 24 content-diverged files vs pin (21 modified + 3 added),
all ledgered in VOICEMEM_PIN.json — now 22 entries (VM-LOCAL-001..021,
including the v0.10.2 backfill that closed the OPEN ledger item).

### D. Upstream changes since pin (52 commits, ALL diffs read)
Categorised: ~15 README/assets/docs; ~8 right-brain web-display cosmetics
(zh demo-specific); 4 already ported by us earlier (961efe8, 91d2e42,
f535f9d, e3cc965); ~25 functional. The functional set maps to 6 areas:
LLM-prompt/session-context, streaming TTS+playback, barge-in/cancellation,
retrieval quality, memory language, config/logging infra.
Full list: evidence/upstream_history_since_pin.txt.

### E. Latency-relevant changes (the P0 focus)
1. `7f842a8` Reply prompt rewrite (1147→~660 chars) + prosody OUT of the
   text prompt (into TTS instruction param) + short-term history block.
2. `6c085d4` SessionBuffer (web/session_context.py): uncommitted-turn
   context, removed only after `persistent_memory_created`.
3. `7f842a8`/`9193c78` Two-level TTS synthesis (per-segment concurrent
   synth, ordered playback) + first-segment-first-frame chunking.
4. `f99569e` AudioWorklet PCM player: continuous playback, adaptive jitter
   buffer (80→320ms), drain/clear semantics, underrun telemetry.
5. `7581656` hearing(): barge window extends over the browser playback
   TAIL (sent-audio ledger); grace from FIRST audio, not task creation.
   **We had this bug class exactly** — see M below.
6. `6c085d4` Reversible barge-in candidates (VAD-onset pause, ASR confirm,
   silence/timeout reject, discarded noise turns).
7. `a450911` AudioTimeline heard_text(): playback-position→text mapping for
   interrupted-context (provider alignment > segment ratio > rate EWMA).
8. Background memory writes serialised off the turn path
   (queue_remember_turn + _REMEMBER_LOCK + on_complete callback).
9. fa537a9/333dbcb fewer/no response_experience writes (less background
   churn), heartnote slot cap (less prompt noise).

### F. Prompt/context differences
Upstream reply prompt: ONE system (persona+memory+session-buffer+language
notes, ~660 chars) + ONE user message; history as RENDERED TEXT inside the
system block (SessionBuffer, 200 chars/turn, ~6 turns).
Ours: system (persona ~800 chars + memory 1200-char cap + emotion block) +
native chat history (8 entries, 14000-char budget, oldest dropped, append-
only = maximal llama-server LCP prefix-cache reuse — measured 99.2% reuse
at v0.10.2). DECISION: KEEP OURS (native messages cache better; the upstream
SessionBuffer exists to compensate their stateless single-message reply
API, which we do not have).

### G. SessionBuffer differences
Upstream: per (session, space) in-memory store of uncommitted turns;
`mark_complete(turn_id, committed)` removes a turn ONLY when the ingest
`on_complete` reports `persistent_memory_created` (wired via the new
orchestrator callback, 6c085d4); `interrupted` flag rendered per turn.
Ours: full native history; turns NEVER removed on ingest (bounded window
instead) — deliberate: retrieval may or may not surface the fact, verbatim
recency matters for conversation flow. PORTED the missing semantic: the
INTERRUPTED turn now stays in history (sent text + `[interrupted]` marker)
instead of being dropped entirely (see M/ports).

### H. Retrieval/prefetch
Upstream stream.py (predates our pin, unused by our app path):
speculative retrieval kicked on partial-transcript change (≥6 chars,
200ms-silence gamble, 0-300ms window, cancel-on-resume, EWMA none).
NOT PORTED: our production parakeet engine is `streaming=False`
(capability-declared; partials do not exist mid-utterance) — the pattern
is unportable without touching ASR, which the operator's rules forbid
absent necessity. Documented as REMAINING (needs a streaming engine or a
parakeet streaming mode).

### I. Cancellation
Upstream: turn-task cancel + hearing() tail window + force-stop on
superseding turn + reversible candidate pause (playback side).
Ours (v0.10.2): cooperative cancel transport on the BACKGROUND legs
(llm_bg_gate; measured 3.2s vs 299.7s slot release) + gate v2 requeue.
These are COMPLEMENTARY: upstream cancels the FOREGROUND turn (ours also
does, via task.cancel + interrupt flow); ours additionally cancels
BACKGROUND LLM work — upstream has NO background-priority mechanism at
all (their queue_remember_turn only serialises). KEEP ours; PORT upstream's
tail-window + force-stop (this release); DEFER the reversible pause.

### J. Barge-in
Upstream rewritten to: ASR-confirmation (explicit interrupt prefixes,
stable-growth counter, strong-final check), filler/backchannel filtering,
LCS echo detection against SPOKEN text (not generated), reversible pause at
VAD onset, noise-turn discard. Ours: VAD-sustained-speech interrupt during
answering (mic suppressed from VSM while answering — echo impossible by
construction there). The GAP was the post-answer TAIL (see M). PORTED the
tail fix; DEFERRED the reversible pause + LCS echo (needs browser
pause/resume protocol; our mic-suppression design already prevents echo
during the answering window itself).

### K. TTS integration
Upstream: NO text normalisation at all (their cut_point splits on CJK/
European sentence ends only; nothing maps typographic quotes) — the
operator's „ (U+201E) Supertonic failure has NO upstream solution.
Their architecture: first-segment-first-frame chunking (FIRST_MIN=6/
FIRST_MAX=20, soft ends first segment only; measured 8字=615ms,
25字=902ms, 100字=1318ms first-frame), per-sample-boundary chunking,
backend instance reuse, prosody via instruction param.
Ours: SentenceStream (first_chunk_chars=24) + sequential per-chunk
synthesis. PORTED the two-level concurrent synthesis; WROTE our own
normalisation (normalize_for_speech — the only possible source of a fix);
first-chunk strategy already equivalent (KEEP).

### L. Dependencies
Upstream added: mem0-embedder acceptance (a8d5c76), re-embed tool
(089cb5e), httpx (Breeze client), llm_config roles (7c22ac7).
REJECTED: mem0-embedder acceptance (violates our E5-only embedding
invariant, VM-LOCAL-001 policy). N/A: re-embed tool. KEEP: our llm_config
(role-resolved for llama-server; theirs is OpenAI-centric), our logging
(proper logging vs stdout tee). No new runtime deps introduced by our ports
(pure stdlib + existing stack).

### M. What changed FOR US (the 6 ports shipped in v0.10.3)
1. **TTS text normalisation** (`normalize_for_speech`, app/text_utils.py;
   applied at `_synthesize_chunk`): „ ” ‘ ’ ‚ « » ′ ″ → ASCII quotes,
   – — ― − → hyphen, … → ..., NBSP-family → space, ZW*/BOM dropped, ¡ ¿ →
   ! ?. Letters/digits untouched; spoken content word-identical (tested).
   Fixes the field-reported Supertonic failure on U+201E.
2. **Hearing window** (`_playback_tail_active` + `_account_sent_audio`):
   the barge-in condition extends past turn-task completion by the SENT
   audio's remaining duration (24 kHz PCM16 ledger + 0.35s slack); grace
   now starts at FIRST AUDIO SENT (TTS first frame ~1s previously consumed
   the whole turn-start grace before any audio existed).
3. **Supersede force-stop** (`_start_turn`): a new turn that interrupts an
   answering one now stops TTS + resets the ledger + notifies the browser
   (answer_interrupt) — two replies can no longer interleave on the speaker.
4. **Concurrent TTS synthesis** (two-level pipeline, 2-slot semaphore):
   chunk N+1 synthesizes while chunk N plays; ordered FIFO emission; first
   chunk latency unchanged; in-flight synths cancelled with the turn.
5. **Interrupted-turn history**: on barge-in, the user message + the SENT
   (heard) reply fragment + `[interrupted]` marker enter the conversation
   history — the next turn knows where it was cut.
6. **Vendor retrieval quality**: heartnote slot-cap 2 (333dbcb),
   response_experience slots 0 + write-path gated off (fa537a9, env-
   reversible; attribution call and user-side trait outlet KEPT),
   query-gated recency (a507978, HU+EN cues) — attribute questions keep
   pure similarity ranking.

### N. What actually IMPROVED LATENCY (mechanism, sandbox-provable)
- **Inter-chunk TTS gap**: previously = full synthesis time of chunk N+1
  (sequential worker); now overlapped with chunk N playback (bounded 2).
  First-chunk latency unchanged (starts alone).
- **„-failure path**: a synthesis that errors no longer can kill a whole
  chunk sentence — no retry loops on unsupported chars at all.
- **Barge-in responsiveness during the tail**: interrupts land during
  browser playback instead of opening a phantom turn (which then had to
  be answered from scratch — the perceived "it keeps talking and then
  answers the echo" failure).
- **Slot pressure (indirect)**: response_experience writes off = one less
  background write per turn; smaller rb prompt = less foreground prompt
  eval per turn (bounded effect; the extraction-prompt size is unchanged
  and remains the dominant background term — see R).
- NOT changed: retrieval timing (still post-EOU on the critical path —
  see R), emotion wait budget (0.6s), llama config (baseline untouched,
  per PART 17).

### O. What still causes OUTLIERS (P0-A/P0-B split, per the operator's data)
- P0-A (30–42s): the SAME single-slot queueing mechanism proven at v0.10.2
  (user chat behind an in-flight background leg). v0.10.2's cooperative
  cancel addresses it WHEN INSTALLED ON TARGET — the operator's outlier
  measurements must state the installed version; if pre-0.10.2, that IS
  the explanation. Additional contributors that remain: extraction retries
  (max_retries=2) and the resolve leg (60s timeout) can still hold the
  slot if the user speaks DURING the post-release idle window before the
  gate re-arms (arm cancels in-flight work, so the window is the grace
  period itself). scripts/llm_slot_forensic.py on the target decides.
- P0-B (2.5–5s normal): components on the voice-turn critical path:
  ASR final decode + memory/emotion wait (bounded 1.6s steady; emotion
  analysis alone measured ~2.3s in the field — it dominates the budget)
  + LLM TTFT. The upstream prefetch that would hide the retrieval portion
  is NOT portable (H). The remaining in-sandbox-legal lever is the
  emotion-wait budget (config) — a target measurement decision, not
  changed blindly here per PART 17 discipline.

### P. Before/after benchmarks (sandbox, deterministic unit level)
- Normalisation: 23 new tests, incl. the exact „ case (no upstream
  equivalent existed).
- Hearing ledger: unit-level timing tests (tail active/inactive/reset).
- Quotas: behaviour tests (2 heartnotes max, 0 experience rows).
- Recency gating: the upstream failure case reproduced as a test
  (0.810-old vs 0.773+0.10-new: attribute query → old wins; recency query
  → new wins).
- Full gate: 1407 tests, 0 regressions, 6 pinned env-gap, GREEN on the
  final tree (fingerprint e4db8308…).
- TTS concurrency + hearing + interrupted-history integration behaviour:
  covered by the existing mock pipeline battery (all green).
- TARGET benchmarks (PART 16 matrix): the sandbox has no RTX 5070 and no
  Supertonic weights — the matrix runs on target via the existing
  scripts/llm_slot_forensic.py + the UI's own per-stage timings
  (llm_first_token_ms, first TTS audio, total_ms are all instrumented
  and visible in the Pipeline panel).

### Q. Target benchmark plan (PART 19)
Authoritative measurements happen on the RTX 5070 machine after install:
normal turns (TTFT distribution with the new history/quotas), barge-in
during playback tail (the previously-dead window), „-sentence playback
(the reported failure), multi-chunk reply (inter-chunk gap audible?),
heartnote-heavy store (rb column composition).

### R. Remaining risks / remaining work
1. Speculative retrieval deferred (needs streaming ASR — H).
2. Reversible barge pause + AudioWorklet player + AudioTimeline heard-text
   deferred (browser protocol changes; hearing window covers the main bug).
3. Attribution-prompt schema shrink (fa537a9's prompt part) deliberately
   not ported — measure first on target (the attribution call remains).
4. The `ma `/`ma?` recency-cue forms are boundary-safe but a query ending
   in bare "ma" without space/punct is not matched (acceptable: misses
   only lose the bonus, never correctness).
5. Sandbox state-restore class hit AGAIN this session (PAT file, venv
   packages openai/sentence-transformers/torch/transformers/mem0ai, E5
   weights, Qwen forensic tokenizer, releases/ zips) — all restored and
   documented; the prompt-size contract was re-measured with the
   PRODUCTION tokenizer (6118 stand-in → 6265 production, prompt file
   byte-identical; band updated with both measurements recorded).
6. Mirror policy: v0.9.1 product zip remains the known mirror gap (recovery
   package IS mirrored) — unchanged policy.

### S. License/provenance
All ports are from xzf-thu/VoiceMem (Apache-2.0 per upstream LICENSE —
checked in the clone; the vendored fork carries our LICENSES.md). No
upstream code was copied verbatim except the quota-table semantics and
cue-list patterns, adapted and attributed per-commit in VOICEMEM_PIN.json
(VM-LOCAL-016..018 with exact upstream commit hashes). No new third-party
code introduced. The Breeze TTS backend was REJECTED partly on license
grounds (non-commercial weights) — we did not adopt it.

### T. Recommended next steps
1. Install v0.10.3 on target; run scripts\llm_slot_forensic.py with the
   operator's outlier reproduction (PART 16 matrix).
2. Report the „-sentence + barge-in-tail + multi-chunk-gap checks.
3. Decide the emotion-wait budget (0.6s) on target data.
4. If outliers persist on v0.10.2+ with the gate armed: capture
   logs/web-server.log around one — the gate stats (cancelled/requeued/
   idle_waits) now name the mechanism.

---
## PORT DECISION MATRIX (PART 14 summary)

| Upstream change | Decision | Technical reason |
|---|---|---|
| 7f842a8 prompt rewrite | KEEP OURS | our prompt already short; native messages cache better |
| 7f842a8 prosody→TTS instruction | DEFER | Supertonic has no instruction param (CPU ONNX, local-only) |
| 7f842a8 two-level synth | PORT (adapted) | removes inter-chunk gap; first-chunk unchanged |
| 6c085d4 SessionBuffer | KEEP OURS + PORT interrupted-flag | native history; interrupted context was our real gap |
| 6c085d4 reversible barge candidates | DEFER | needs browser pause/resume; hearing window covers main bug |
| 6c085d4 noise-turn discard | DEFER | our VSM already gates turn formation |
| 7581656 hearing() tail | PORT | our exact bug: dead barge window + phantom echo turn |
| 7581656 first-audio grace | PORT | turn-start grace expired before audio existed |
| force-stop on supersede | PORT | two replies could interleave on the speaker |
| f99569e AudioWorklet player | DEFER | bigger browser change; sequential scheduling gapless when synth keeps up |
| a450911 AudioTimeline heard_text | DEFER | sent≈heard approximation adequate; no provider timestamps |
| stream.py speculative retrieval | DEFER (blocked) | parakeet streaming=False; ASR untouchable this release |
| 333dbcb heartnote cap | PORT | freshness crowding measured by upstream; env-tunable |
| fa537a9 drop response_experience | PORT (gated) | write-only line; attribution + trait outlet kept |
| fa537a9 attribution schema shrink | DEFER | measure first; prompt change risk |
| a507978 query-gated recency | PORT (adapted) | protects old-but-correct attribute answers; HU cues added |
| ab97cf5 UPDATE→append | KEEP OURS | VM-LOCAL-008 supersession is strictly richer |
| lang.py memory-language-per-space | REJECT | our E5 multilingual + HU/EN mode covers; mono-store not our design |
| 7c22ac7 llm_config roles | KEEP OURS | llama-server role resolver; theirs OpenAI-centric |
| logging_utils tee | KEEP OURS | proper logging already |
| a8d5c76 mem0 embedders | REJECT | violates E5-only invariant |
| 089cb5e re-embed tool | N/A | no re-embed need (single embedder) |
| web display cosmetics (5 commits) | REJECT | zh demo-specific |
| README/docs/assets | N/A | not code |

## ARTIFACTS
- Product: releases/VoiceMemAgent_v0.10.3.zip (2775.3 KB, 366 files,
  SHA256 6D2964237350B64FF108D4861F2477D3447CC755D9D9D33E73F3F931079DA965)
- Gate: releases/gate_record.json — GREEN, fingerprint e4db8308…,
  1407 tests / 0 regressions / 6 pinned env-gap / 31 skipped
- Recovery: VoiceMem_upstreamaudit_v0103_recovery.zip (sidecar'd)
- Evidence: upstream_history_since_pin.txt, code.diff, gate_record copy
