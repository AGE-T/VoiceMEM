# VoiceMem v0.10.3 Recovery — Upstream-Audit Selective Port

## A. What changed (the 6 ports)
1. app/text_utils.py — normalize_for_speech: typographic punctuation
   („ ” ‘ ’ – — … NBSP ZW*) mapped to speakable ASCII at the single TTS
   choke point (_synthesize_chunk). The reported „ (U+201E) Supertonic
   crash is fixed; letters/digits untouched.
2. app/web_server.py — hearing() playback-tail window: barge-in stays
   armed while the browser is (by our sent-audio ledger estimate) still
   playing our reply (24 kHz PCM16 accounting + 0.35 s slack); the
   barge-in grace period now starts at the FIRST audio sent.
3. app/web_server.py — _start_turn force-stop: a new turn superseding an
   answering one stops TTS, resets the ledger and notifies the browser
   (answer_interrupt) — replies no longer interleave.
4. app/web_server.py — two-level concurrent TTS synthesis (2-slot
   semaphore, ordered FIFO emission): the next chunk synthesizes while
   the current one plays; in-flight synths cancel with the turn.
5. app/web_server.py — interrupted turns enter the history (sent text +
   "[interrupted]"); the next turn keeps the context after a barge-in.
6. vendor: rightbrain/brain.py — heartnote (situation_pattern) prompt
   slots capped at 2; response_experience slots default 0 and its write
   path is gated off (VOICEMEM_RB_WRITE_EXPERIENCE=1 restores);
   leftbrain/temporal.py + mem0_backend_store.py — the recency bonus
   applies only to recency-type queries (HU+EN cues).

## B. If the target misbehaves
- TTS sounds wrong on quotes/dashes → check app/text_utils.py
  _SPEECH_CHAR_MAP (no letters are touched; only punctuation maps).
- Barge-in feels too sensitive late in a reply → the hearing window uses
  _PLAYBACK_TAIL_SLACK_S (0.35 s); the window NEVER extends past
  sent-audio duration + slack.
- Replies cut each other off → that is port 3 working as designed (the
  old behaviour interleaved audio on the speaker).
- Memory prompts feel different → the heartnote/experience quota and the
  recency gating are env-reversible:
    VOICEMEM_RB_HEARTNOTE_MAX=2   (upstream default; raise to see more)
    VOICEMEM_RB_RESPONSE_MAX=1    (pre-v0.10.3 behaviour)
    VOICEMEM_RB_WRITE_EXPERIENCE=1 (restore the write path)
  The recency gating is code-level (query cue scan) — rollback = the
  v0.10.2 zip.
- response_experience rows are NOT deleted; they are only hidden from
  prompts by the quota default.

## C. Rollback
Install releases/VoiceMemAgent_v0.10.2.zip (SHA256
F56E5155043B9900B2A45799F4FA1663ED8475584F9DBA1F1BBD80B13C525A54) — the
data formats are unchanged (no migrations this release; all vendor
changes are read-time/env-gated).

## D. Verify the install
- Page footer shows 0.10.3; /api/health reports 0.10.3.
- Say a Hungarian sentence containing „idézőjel” — the reply speaks it
  (previously: TTS error, no audio for that chunk).
- Interrupt a reply near its end (during the last words' playback) — the
  audio stops immediately (previously the interrupt was ignored there).
