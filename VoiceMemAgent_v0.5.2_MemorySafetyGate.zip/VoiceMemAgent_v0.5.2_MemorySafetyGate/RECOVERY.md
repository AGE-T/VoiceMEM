# RECOVERY — TASK 1.5 Memory Safety Gate (v0.5.2)

**Package:** `VoiceMemAgent_v0.5.2_MemorySafetyGate.zip`
**Work unit:** TASK 1.5 — MEMORY SAFETY GATE (before TASK 2 Rich Retrieval)
**Base state:** v0.5.1 (local repo HEAD pre-work: `8450f5a`/`f020279`, mirror
`ec6961b`, release zip SHA `6E4CD79B…`)
**After state:** v0.5.2 (release zip SHA `207426DB…`, gate 954/0/26)

---

## 1. What this package contains

| Path | Content |
|---|---|
| `TASK1_5_MEMORY_SAFETY.md` | The full analysis: Phase 0 current state, the Claude-audit reconciliation table (CD-1…CD-6, F-A…F-F), the P0 traces, the design decisions, the gate results, the safety-gate checklist (13/13 PASS) and the TASK 2 READY verdict |
| `patches/vendor_source.patch` | Unified diff of EVERY source change (vendor + pin + tests) — apply to a clean v0.5.1 tree to reproduce v0.5.2 |
| `patches/vendor/…`, `patches/tests/…`, `patches/VOICEMEM_PIN.json` | The changed files in full (belt and suspenders vs. the patch) |
| `evidence/task15_before_after.json` | **The P0 reproduction + fix proof**: the SAME scenario against the pre-patch vendor (git HEAD) — 12/12 heartnotes DELETED with `VOICEMEM_ALLOW_MEMORY_DELETE` absent — vs. the patched tree — 0 deleted, default deny |
| `evidence/task15_safety_tests_verbose.txt` | The 15-test behavioural battery, verbose run (real vendor + real mem0/Qdrant/E5; deterministic mock LLM decisions only) |
| `evidence/task15_gate_*.log`, `task15_gate_summary.txt` | The full release gate: integration 75/0/0, unit A 246/0/0, unit B 199/0/1, unit C 170/0/1, validation 264/0/24 — **954 tests, 0 failures, 26 skips** |

## 2. What changed (summary)

Three controlled-fork patches + test battery + release plumbing:

1. **VM-LOCAL-007 — right-brain DELETE gate (closes audit CD-1, P0)**
   `vendor/voicemem/voicemem/rightbrain/brain.py`: every hard-delete in
   `run_cleanup` (the LLM heartnote-cleanup decision on the Ingest hot path)
   routes through `_execute_heartnote_deletes`, which requires
   `VOICEMEM_ALLOW_MEMORY_DELETE=1` (default **deny**, loud log). The
   supersede branch was already non-destructive and is unchanged.
2. **VM-LOCAL-008 — non-destructive UPDATE (closes audit CD-2, P0)**
   `mem0_backend_store.update_memory` appends a NEW observation row
   (`supersedes` + session/event-date provenance) and only MERGES
   `superseded_by`/`superseded_at` metadata onto the old row (text and
   created_at preserved — verified against the installed mem0's merge-update
   semantics). `memory_repository.update_memory` appends to the JSON mirror
   instead of overwriting and annotates the cognitive graph on the NEW id;
   `memory_repository_v2` re-tags the new row; `MemorySearchHit` gains
   `superseded_by`; search ranks non-superseded (current) hits first;
   `_dedupe_near` never collapses an explicit supersession pair.
3. **VM-LOCAL-009 — left delete graph cascade (closes audit F-H, P2)**
   A permitted left-brain delete (VM-LOCAL-005 gate unchanged) now also
   removes `memories`, `entity_memory_links`, `memory_tags`,
   `graph_entity_memories` rows (FK-safe order) — no stale graph truth.
4. **Behavioural battery** `tests/integration/test_memory_safety.py`
   (15 tests) + the pre-existing suites still green.
5. **Gate env upgrade + honest env-profile guards** (documented in the gate
   summary): the gate now runs the torch-equipped profile with the
   production offline env; two dep-free-sandbox tests gained scope guards /
   deterministic fixtures (assertions unchanged); the pre-existing v0.5.1
   PAGE_VERSION staleness fixed (0.5.2).
6. **Release plumbing:** VERSION/pyproject/yaml/PAGE_VERSION → 0.5.2;
   build script (docs + release JSONs now stage in the ZIP; V052 markers);
   releases restored from git-tracked public/ after the sandbox reset.

## 3. Data model changes (migration information)

- **No schema migration is required.** All changes are additive metadata:
  - old rows may gain `superseded_by` + `superseded_at` payload keys (mem0
    metadata merge),
  - new rows from UPDATE events carry `supersedes` + the usual provenance.
- Existing v0.5.1 data (no supersession keys) behaves **byte-identically**:
  the ranking guard only affects rows that carry `superseded_by` (none exist
  in old data — measured by the A/B equivalence inside the battery).
- The JSON mirror gains annotated/appended entries only via future UPDATE
  events; no rewrite of existing mirror files happens on upgrade.
- Roll-forward: nothing to run. Roll-back: revert the vendor files (§4).

## 4. Rollback instructions

The whole change set is one vendor+tests diff (no data migration):

```
# from the repo root (the git worktree that built v0.5.2)
git checkout <pre-work-commit> -- voicemem-agent/vendor/voicemem voicemem-agent/VOICEMEM_PIN.json voicemem-agent/tests
# or apply the inverse of patches/vendor_source.patch
```

After rollback, re-run the safety battery (expected: the BEFORE behaviour of
`evidence/task15_before_after.json` returns — the CD-1 P0 is present again;
the UPDATE tests fail because in-place overwrite returns). No data written by
v0.5.2 needs repair on rollback: supersession pairs degrade to ordinary
independent rows (the `superseded_by`/`supersedes` keys are ignored by the
old code; retrieval falls back to plain cosine ranking).

To verify a recovered environment: run
`tests/integration/test_memory_safety.py` — 15/15 PASS = safety patches
present; the `task15_before_after_proof.py` script (in the repo, scripts/)
reproduces the gate comparison against any tree.

## 5. Where the authoritative artifacts live

- Release: `releases/VoiceMemAgent_v0.5.2.zip` (+ sidecar, SHA
  `207426DB22ADAA616DD1C8858861AE5BF429BB07F677AE9D616AE3BA56474330`),
  deployed to `public/` + `public/releases/` and synced to the GitHub mirror
  (see the identity block for the exact mirror HEAD after sync).
- This package: `public/VoiceMemAgent_v0.5.2_MemorySafetyGate.zip` (+ sidecar)
  and the GitHub mirror.
- The mirror additionally carries the FULL first-party source tree under
  `source/` (CD-6 remediation; additive, release zips preserved).
