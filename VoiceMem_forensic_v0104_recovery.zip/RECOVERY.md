# VoiceMem v0.10.4 Recovery — FORENSIC LOGGING (5-class latency attribution)

Identity
- Product: VoiceMemAgent v0.10.4 (releases/VoiceMemAgent_v0.10.4.zip)
- SHA256: 90B827046B19418538E9FC69E2F546D560483FF51FA268C876336570B1109F55
- Gate: GREEN, 1436 tests, 0 regressions, 7 pinned sandbox env-gap,
  29 skipped, deep PASS [embedding, memory, memory-semantics, release,
  runtime-deps]; fingerprint 70ba38d83904cc6c2c3be765bca28432931a457c2fc4a07aa670abec722b51ff
  (record: releases/gate_record.json)
- Scope: ONLY additive forensic logging — the target machine must be
  able to fully distinguish 5 latency classes: (1) background contention,
  (2) real foreground LLM latency, (3) preprocessing-dominated latency,
  (4) queueing/slot occupancy, (5) background gate starvation.

## A. MI VÁLTOZOTT (what changed)

Additive INFO/_diag logging ONLY — zero control-flow change, zero
latency-behaviour change, llama baseline untouched
(-ngl 16 -c 16000 --parallel 1). Four new INFO lines in
app/background_memory.py and one new _diag line in app/web_server.py
(exact formats as they appear in logs/web-server.log):

1. `background memory gate armed (reason=<reason>)`
   — the open→armed transition (a user speech frame re-arms the gate;
   this is the "acquire" timestamp of the gate timeline).
2. `background memory gate released (turn ended; grace=<G>s idle=<I>s)`
   — the release transition at turn end.
3. `background memory gate open (idle window held; background may start)`
   — the open transition: from here a background chain MAY start.
4. `background memory ingest started (turn_no=<N>, <Q> queued, start_wait=<W>s)`
   — the background chain START (the timestamp from which an in-flight
   chain can contend with the next user turn).
5. `[chain] emotion prosody done (waited)` or
   `[chain] emotion prosody pending (late — ran past the wait window)`
   — the prosody (emotion) analysis end, split from the LLM time.

Plus scripts/llm_slot_forensic.py upgraded to schema
`llm-slot-forensic/2` with the S8 OFFLINE product-log correlation phase
(see C) and +29 tests (test_llm_slot_forensic.py NEW with 27,
test_background_memory_gate.py +2 GateForensicLoggingTests).
Release metadata: VERSION / pyproject / config yaml / web PAGE_VERSION →
0.10.4; builder script version pair + notes.

## B. CÉLGÉPI VISELKEDÉS-PLAYBOOK (if the target misbehaves)

The logging is INERT: `logger.info` / `_diag` calls on existing code
paths, no branch, no timing, no config change. Worst case = a few extra
INFO lines per turn in logs/web-server.log (4 gate lines + 1 prosody
line — exactly the volume the S8 phase parses).
- Product answers slower/differently than v0.10.3 → NOT this release by
  construction (no control-flow change); capture
  logs/web-server.log (plus rotations .1–.3) and the forensic
  report.json, then roll back (D) and compare.
- Log file growth: the 5 new lines are a handful per turn — negligible
  against the existing per-turn stage trail; rotation settings
  unchanged.
- Anything unexpected on the forensic tool itself: it is read-only
  (sends only its own probe requests and GETs; writes only inside
  logs/; never touches server state — no /slots erase, no cache clear)
  and crash-safe (one phase failing does not lose the others; the
  report.json is rewritten after EVERY phase).
- If in doubt: capture logs/ + report.json and fall back to v0.10.3 (D).

## C. CÉLGÉPI FORENZIKAI ELJÁRÁS (target-side procedure)

### C.1 The tool

`scripts\llm_slot_forensic.py` (schema llm-slot-forensic/2). The script
takes NO command-line arguments — everything is env-driven:

| Env var | Meaning (verbatim from the script) |
|---|---|
| `LLAMA_SERVER_URL` | base url without /v1 (default http://127.0.0.1:8080) |
| `LSF_MAX_TOKENS` | generation cap for the probes (default 384; the production extraction uses 1536 — a smaller cap keeps the forensic quick; ratios are what matter) |
| `LSF_OUT` | report directory (default logs/llm_slot_forensic_<ts>) |
| `LSF_PHASES` | comma list (default s1,s2,s3,s4,s5,s6,s7,s8) |
| `LSF_MERGE` | path to a previous report.json to continue |
| `LSF_PRODUCT_LOG` | product log (default logs/web-server.log; the rotations web-server.log.1/.2/.3 are picked up automatically) |
| `LSF_SINCE` | epoch seconds or ISO datetime: drop older events |
| `LSF_TURNS` | detail the last N turns in s8 (default 30; 0 = all) |
| `LSF_OUTLIER_MS` | first-token threshold for s8 outlier verdicts (default 10000) |
| `LSF_PREPROC_MS` | preprocessing threshold for s8 verdicts (default 3000) |
| `LSF_BG_WINDOW_S` | how long before a turn a background chain start still counts as "recent" (default 45) |

Report path: `logs\llm_slot_forensic_<YYYYMMDD-HHMMSS>\report.json`
(directory = LSF_OUT or the default; the file is always report.json,
rewritten after every phase — crash-safe).

Which phases need what:
- s1–s7 (identity, baseline TTFT, FIFO occupancy, JSON streaming, LCP
  cache, cache-after-cancel, production interleave): llama server
  RUNNING and the product IDLE — the probes deliberately occupy the
  single slot.
- s8 (product turn trace): OFFLINE — no probe requests; works whether
  or not the server (or even the product) is running; reads
  logs/web-server.log* only.

### C.2 Exact commands (from the product root, product venv)

Full run (server running, product idle — s1..s8):

    .venv\Scripts\python.exe scripts\llm_slot_forensic.py

Offline correlation only (server/product state irrelevant) — set
LSF_PHASES=s8 first; PowerShell:

    $env:LSF_PHASES="s8"
    .venv\Scripts\python.exe scripts\llm_slot_forensic.py

Typical knob combinations (PowerShell, from the product root):

    # only the newest session's turns, all of them, tighter outlier bar:
    $env:LSF_PHASES="s8"; $env:LSF_SINCE="2026-09-18T10:00:00"; $env:LSF_TURNS="0"; $env:LSF_OUTLIER_MS="5000"
    .venv\Scripts\python.exe scripts\llm_slot_forensic.py

    # fixed report directory (easier to find):
    $env:LSF_OUT="logs\forensic_run1"
    .venv\Scripts\python.exe scripts\llm_slot_forensic.py

    # server on another port:
    $env:LLAMA_SERVER_URL="http://127.0.0.1:8081"
    .venv\Scripts\python.exe scripts\llm_slot_forensic.py

    # continue an earlier report (a full run may not fit one console session):
    $env:LSF_MERGE="logs\llm_slot_forensic_<ts>\report.json"; $env:LSF_PHASES="s5,s7"
    .venv\Scripts\python.exe scripts\llm_slot_forensic.py

### C.3 Recommended validation sequence

1. Install v0.10.4 over the existing install (same layout; no data
   migration, no format change).
2. Verify the product still answers normally — the logging must not
   change anything (say a few sentences, check the Pipeline panel
   timings and that replies/voice/memory behave as on v0.10.3).
3. Reproduce a session with the observed 30–42 s outlier (use it
   normally; note the wall-clock time of the slow turn).
4. Run the forensic tool — offline S8 is enough for attribution:
   `$env:LSF_PHASES="s8"` + the command above; add the full run
   (s1–s8, server idle window) when server-side numbers are wanted.
5. Read `report.json` → `s8_product_trace.turns[]` → each turn's
   `verdict` + `gaps_ms` (asr_to_turn / memory / preprocessing /
   llm_wait / first_token / llm_stream / total), plus the session
   `gate_events` timeline and the `outliers` list.

### C.4 Interpretation matrix (what each result proves)

| report.json shows | What it proves |
|---|---|
| `CONTENTION_CONFIRMED` | background chain held the slot DURING the user turn — a gate_cancel / bg_cancel_requested / bg_requeued event lies inside [speech start .. first token]. Class (1) background contention. |
| `CONTENTION_SUSPECT_OR_CACHE_EVICTED` | background ran NEAR the turn (bg_before, within LSF_BG_WINDOW_S=45 s) or the user's prefix was evicted from the slot cache — check the s3/s5/s7 prompt-reprocessing metrics (actual re-evaluated prompt tokens). Class (1)/(4) adjacent. |
| `PREPROCESSING_DOMINATED` | memory/emotion wait consumed the latency BEFORE the LLM call (preprocessing_ms ≥ 3000 default; see memory_ms + the emotion prosody markers). Class (3). |
| `REAL_LLM_LATENCY` | the server itself was slow with a free slot — real model latency (prompt prefill/generation; compare s2 idle baseline + s5/s7 prefill costs). Class (2). |
| `NO_LLM_REQUEST` / `NO_FIRST_TOKEN` | the turn failed before the LLM stage, or the stream never produced content (stalled/failed stream). |
| Gate-time: long gate-armed windows with requeued background pairs (`bg_requeued` events) while user turns were slow | background gate starvation — the gate never opens long enough for the ingest chain to start (repeated `deferred`/`re-queued` with no `ingest started`). Class (5). A memory-consolidation problem, not a user-latency one. |
| `s3_fifo.user_chat.ttft_ms` >> `s3_disconnect_yield.user_chat.ttft_ms` (Run A vs Run B) | server-side queueing/slot occupancy confirmed and the disconnect-yield transport still sound. Class (4). |

Verdict priority chain (deterministic, documented in the report itself):
NO_LLM_REQUEST / NO_FIRST_TOKEN > CONTENTION_CONFIRMED >
CONTENTION_SUSPECT_OR_CACHE_EVICTED > PREPROCESSING_DOMINATED >
REAL_LLM_LATENCY. All 8 correlation points (ASR final, memory
retrieval, emotion, LLM request start, first content token, stream
completion, background gate events, cancellation events) are recorded
per turn with raw timestamps — the interpretation can be redone by hand.

## D. VISSZAÁLLÍTÁS (rollback)

Reinstall v0.10.3: public/VoiceMemAgent_v0.10.3.zip
(SHA256 6D2964237350B64FF108D4861F2477D3447CC755D9D9D33E73F3F931079DA965).
No data migration in either direction (v0.10.4 changes no formats).
Note: v0.10.3 lacks the 5 new log lines, so S8 attribution DEGRADES
there — the contention/cancel lines (CANCELLED, cancel-requested,
requeued) exist since v0.10.2/v0.10.3, so CONTENTION_CONFIRMED still
works, but the gate-open / ingest-started / prosody markers are absent,
so CONTENTION_SUSPECT degrades toward REAL_LLM_LATENCY. Full 5-way
correlation needs v0.10.4.
