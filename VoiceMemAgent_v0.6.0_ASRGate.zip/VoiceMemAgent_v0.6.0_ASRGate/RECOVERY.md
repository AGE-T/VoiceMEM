# RECOVERY — VoiceMemAgent v0.6.0 (TASK A/B: Modular ASR + UI Observability)

## What this package is

The GOLDEN RULE recovery package for release **v0.6.0**. If anything goes wrong
after deploying v0.6.0, this package alone is enough to understand exactly what
changed, why, and how to roll back. Everything in it is verifiable against the
repository at the exact commit recorded in identity.json.

## Identity

| Item | Value |
|---|---|
| Release | 0.6.0 (TASK A: modular ASR engine architecture; TASK B: UI observability) |
| Baseline (before) | v0.5.2 @ bb144fd (branch main) |
| Work commit (v0.6.0 implementation) | f61382f (squashed: asr_core + adapters + VAD fix + web server + UI + tests + corpus + benchmarks) |
| Post-gate commit | see identity.json -> post_gate_commit (test realignment + gate doc + changelog + release build) |
| Release ZIP | releases/VoiceMemAgent_v0.6.0.zip (SHA-256 sidecar; copy in public/) |
| Memory Safety freeze | HELD — zero vendor/ diffs across the whole work unit |
| VoiceMem pin | unchanged: controlled fork @ e8384e0 (VM-LOCAL-001..009 intact) |

## What changed (summary)

1. ROOT CAUSE #1 FIXED (measured): Silero VAD was fed 512-sample windows
   WITHOUT the official 64-sample rolling context — deaf on real speech
   (prob_max 0.0031 vs 1.000 with the official contract). app/vad.py now
   implements the official OnnxWrapper feed; FusedVad (the v0.4.14 energy
   fallback) is DELETED together with the vad_energy_fallback config/env.
2. ROOT CAUSE #2 RETIRED (measured): Qwen3-ASR-0.6B produced repetition
   garbage on valid speech ("让让让让让。"). Removed from production: not in
   the registry, not imported. app/asr.py survives only as a clearly-marked
   non-production migration module for its historical tests.
3. NEW ENGINE CONTRACT: app/asr_core.py (AudioBuffer / AsrResult / AsrError /
   AsrCapability / MODEL_REGISTRY / select_engine, NO fallback), adapters
   app/asr_parakeet.py (default) and app/asr_nemotron.py (selectable, true
   cache-aware streaming).
4. WEB SERVER + UI: engine-contract ASR leg, generic stage events, live
   CHAIN (MIC -> VAD -> ASR -> VoiceMEM -> E5 -> LLM -> TTS), ASR transcript
   in chat with the generic AsrResult dict, collapsible bounded panels.

Evidence: evidence/ (forensics report, both engine benchmarks, corpus
manifest, e2e browser-verification log + screenshots, gate summary).
Full gate: TASK_A_ASR_GATE.md (16-item ASR Exit Gate, PASS).

## Rollback procedure (exact)

1. App rollback to v0.5.2 (restore the previous behaviour):
     git checkout bb144fd -- voicemem-agent/app voicemem-agent/web \
         voicemem-agent/config voicemem-agent/tests voicemem-agent/scripts
   or extract releases/VoiceMemAgent_v0.5.2.zip over the install (complete
   self-contained tree; START.bat + installer unchanged).
2. Memory layer: nothing to roll back — vendor/ was never touched in this
   work unit (verify: git diff bb144fd..HEAD -- voicemem-agent/vendor is
   empty).
3. Data: nothing to roll back — no schema, no migration, no re-embedding.
   The ASR engine swap is code-only; existing memories are untouched.
4. Verify the rollback: run the v0.5.2 gate (954 tests) — it must be green
   on the restored tree; restart the web backend and check GET /api/health
   reports version 0.5.2.

## Verification of THIS package

- patches/v060_full_source.patch — the complete git diff (app/, config/,
  scripts/, web/, tests/) from the v0.5.2 baseline commit to the post-gate
  commit. Apply with git apply against the baseline tree to reproduce v0.6.0
  exactly.
- patches/*.py / patches/voicemem.html — the full post-change files for the
  core of the change (asr_core, both adapters, vad, web_server, config,
  pipeline, mock_components, UI, and the four touched test files).
- evidence/gate_summary.txt — the exact gate numbers at release time.
- evidence/e2e_mic_turn_web_server.log — the browser-verified mic turn chain
  (speech start -> memory -> E5 -> LLM first token 15 ms -> TTS -> done).
