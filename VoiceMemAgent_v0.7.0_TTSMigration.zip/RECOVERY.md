# RECOVERY — VoiceMem Agent v0.7.0 (Supertonic 3 TTS migration)

Datum: 2026-09-13 · Munkamenet: "REPLACE PIPER WITH SUPERTONIC 3" (operátori
megbízás) · Kiadás: `VoiceMemAgent_v0.7.0.zip`
(SHA256 `93EBB49FF64A5119C0694BD5AA3A1929015A50C5340EAD734D8D850AD1289507`).

## Mi változott (éles architektúra-váltás)

A produkciós TTS motor **Piper → Supertone Supertonic 3** (ONNX Runtime CPU).
NINCS fallback: Supertonic-hiba = explicit TTS-hiba.

- Új: `app/tts_supertonic.py` (SupertonicTtsEngine, Piper-kompatibilis
  interfész; modell egyszer töltődik be, életben marad; barge-in
  eldobás-alapú; vocoder él-csend vágás).
- Törölve: `app/tts.py` (Piper wrapper — a git-történelem megőrzi).
- Konfig: `tts_engine: supertonic3` (egyetlen érték), preset hangok
  (F1-F5, M1-M5; alap F1), `supertonic_*` beállítások,
  `output_sample_rate: 44100`.
- Telepítő: piper bináris-letöltés törölve; `supertonic==1.3.1` a
  requirements.lock-ban; MODELS.lock `tts` = supertone-oss-archive/
  supertonic-3 @ aafc6e32416a (SHA256-manifest:
  `models/tts/supertonic-3/ASSET_MANIFEST.json`).
- ~35 teszt-elvárás migrálva; 23 új unit-teszt
  (`tests/unit/test_tts_supertonic.py`).

## Visszaállítás (rollback) — a v0.6.4 állapot

1. A munkakönyvtárban: `git revert <v0.7.0 commit>` VAGY a v0.6.4 ZIP
   kicsomagolása a telepítés fölé (a v0.6.4 teljes forrást tartalmaz).
2. Modell-eszközök: a v0.6.4 Piper-hangokat a
   `scripts/download_models.ps1` tölti le; a Supertonic-eszközök
   törlése NEM kötelező (a v0.6.4 kód nem használja őket).
   Fordított irányban (v0.6.4 -> v0.7.0): a MODELS.lock `tts` bejegyzése
   tölti le a supertonic-3 asseteket (~400 MB, telepítéskor EGYSZER).
3. A `config/voice_settings.json`-ben régi (Piper-id) hangnevek
   maradhatnak — a v0.7.0 kód leniens: ismeretlen preset -> F1 alap.
4. Pip: `pip install -r requirements.lock` (a supertonic csomag a
   v0.7.0-hoz kell; a v0.6.4 nem használja).

## Ellenőrzés visszaállítás után

- v0.6.4: `python -m pytest tests/unit/test_config.py` (Piper-elvárások)
- v0.7.0: `python -m pytest tests/unit/test_tts_supertonic.py` (23 teszt)
- A kiadott ZIP-ek integritása: `releases/RELEASE_INDEX.json` + a
  `.sha256` sidecar-fájlok.

## Tartalom

- `patches/full_change.diff` — a teljes v0.7.0 diff (7944 sor)
- `evidence/` — mérési jelentések (report.json = 15/15 standalone
  validáció, asr_roundtrip.json = ASR-roundtrip WER-kapu, performance.json
  = perf/RSS, steps_comparison.json = 5/8/10), hallgatásra szánt WAV
  minták (hu_normal, hu_question, en_sentence, voice_F1, voice_M1),
  böngésző-ellenőrzési képernyőképek
- `identity.json` — a csomag azonosítója

## Git

A pontos commit-hash a worklog-bejegyzésben és a RELEASE_INDEX.json-ben
van rögzítve (a commit a csomag készítése után készül).
