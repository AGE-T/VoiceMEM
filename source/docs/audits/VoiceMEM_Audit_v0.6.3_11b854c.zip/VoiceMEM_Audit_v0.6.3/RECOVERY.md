# RECOVERY — VoiceMEM v0.6.3 differential audit package

Self-contained, independently recoverable. Audit-only: no project files modified.

## What was audited
- Artifact: `VoiceMemAgent_v0.6.3.zip`, SHA256 `dbd97d7f44c9489b60c76796672e55bc816a591acd4a4b107a4d7bdb6f73de35` (matches the handover's stated value).
- Prior audit: v0.5.0 (commit `57fb6a7`, 2026-09-10). This report is differential.

## Contents
- `AUDIT_REPORT_v0.6.3.md` — full differential audit (integrity, previous-findings status, memory-processing deep-dive, processing-chain deep-dive, test delta, remaining register, roadmap, verdict).
- `KEY_FINDINGS_v0.6.3.md` — severity summary + verdict + priority order.
- `METADATA.json` — hashes, scope, fixed/remaining/new lists.
- `evidence/` — the decisive diffs (memory-safety fixes, processing-chain status, artifact hash).
- `SHA256SUMS.txt` — checksums of every file here.

## Verify
1. `sha256sum VoiceMemAgent_v0.6.3.zip` → `dbd97d7f…de35`.
2. `sha256sum -c SHA256SUMS.txt` inside this package.
3. Reproduce the two P0 fixes: `vendor/voicemem/voicemem/rightbrain/brain.py` `_execute_heartnote_deletes` (VM-LOCAL-007) and `leftbrain/mem0_backend_store.py` `update_memory` (VM-LOCAL-008); run `tests/integration/test_memory_safety.py`.
4. Confirm the two remaining P1 memory items: `leftbrain/time_expand.py` (Chinese-only) and the `mem0_backend_store.py` sort key `(not superseded_by, base_score)` (no recency).
