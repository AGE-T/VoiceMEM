# VoiceMEM v0.6.3 — key findings (differential vs v0.5.0)

Artifact SHA256: `dbd97d7f44c9489b60c76796672e55bc816a591acd4a4b107a4d7bdb6f73de35` (matches handover). Audit date 2026-09-12. Full detail: `AUDIT_REPORT_v0.6.3.md`.

## Fixed since v0.5.0 (verified in code + real tests)
- **CD-1 (P0) right-brain ungated delete → FIXED** — VM-LOCAL-007 default-deny gate (`rightbrain/brain.py _execute_heartnote_deletes`).
- **CD-2 (P0) destructive UPDATE → FIXED** — VM-LOCAL-008 append + `superseded_by`/`supersedes`; old text survives; sort prefers current (`mem0_backend_store.py`). Proven by `tests/integration/test_memory_safety.py` (real store + real E5).
- **CD-5 (P1) CLI bridge → FIXED** — now calls real `vm.search()`/`ingest(agent_reply=)`.
- **F-H (P2) delete graph orphaning → FIXED** — VM-LOCAL-009 cascade (`cognitive_graph/store.py delete_memory_record`); test asserts 0 orphans.
- **F-K (P2) context overflow → RESOLVED** — `llm_context_size: 32768`.
- **Processing chain**: FusedVad energy fallback removed; Silero fed its official 64-sample rolling context (root-cause fix of the deafness behind the original "only the Send button answers" bug). ASR handoff intact; no-silent-fallback contract.
- **ASR** Qwen3-ASR → NVIDIA Parakeet TDT 0.6B v3 (multilingual incl. Hungarian, pinned 541d1f99).
- **Tests** materially improved (real-behaviour memory-safety, delete-gate subprocess, bridge, ASR-modular, LLM-streaming e2e).

## Still present / new (the remaining agenda)
- **LAT-1 (P1, NEW)** production latency **30–50 s** — 35B IQ4_XS, 20/42 layers on a 12 GB GPU, rest streaming from RAM. Order-of-magnitude above the spec (p50<2 s). Model-vs-hardware mismatch; unresolved (handover admits). **Top production decision.**
- **CD-3 (P1) STILL PRESENT** — Hungarian temporal cues unsupported (`time_expand.py` Chinese-only, unchanged). Parakeet transcribes HU, but "jövő héten/tegnap/múlt héten" get no date expansion for retrieval.
- **CD-4 (P1) STILL PRESENT** — recency still not a ranking signal (sort added only the supersession key).
- **CD-6 (P1) STILL PRESENT** — repo still zip-blob; GitHub mirror stale (`8b7e6fb`).
- **F-A (P1) PARTIAL** — both surfaces now use `search()`; rich `classify+search` unused/undocumented.
- **F-B (P1) STILL PRESENT** — provenance/confidence dropped at render.
- **DOC-1 (P2, NEW)** — BUILD_INFO says "vendor untouched"; 8 vendor files changed (the good fixes).
- **BAT-1 (P2)** START.bat double-instance guard blind during ~19 GB load. **OFF-1 (P2)** offline env-configured, not code-enforced. **OCC-1 (P2)** occurrence counting still absent. **SEC-1 (P2)** web 8787 bind/auth not re-verified this round.

## Verdict
**Improved, still not production-ready.** The P0 memory-safety blockers are genuinely fixed and behaviourally tested, and the processing chain is cleaner. Do not go live until **latency (LAT-1)**, **Hungarian temporal retrieval (CD-3)**, and **recency ranking (CD-4)** are resolved — those three decide whether a Hungarian long-term-memory voice assistant works for its user. Evolve, not rewrite; the fix loop is working.

## Priority order
1. LAT-1 latency (model/hardware decision) → 2. CD-3 HU/EN temporal cues → 3. CD-4 recency ranking → 4. CD-6 real source tree/mirror → 5. P2 cluster (F-A doc, F-B render, OCC-1, DOC-1, BAT-1, OFF-1, SEC-1).
