# VoiceMEM v0.6.3 — Differential Audit (processing chain + memory processing)

**Auditor:** Claude (Opus 4.8), independent review for Boost IT
**Audit date:** 2026-09-12 (UTC) · **Prior audit:** v0.5.0 (2026-09-10), commit `57fb6a7`
**Audited artifact:** `VoiceMemAgent_v0.6.3.zip` — SHA256 `dbd97d7f44c9489b60c76796672e55bc816a591acd4a4b107a4d7bdb6f73de35` (matches the handover's stated value exactly). 321 files; app 15,053 LOC, vendor 22,073 LOC. BUILD_INFO: version 0.6.3, built_from 0.6.2, git `11b854c`, built 2026-09-12.
**Focus (per request):** the processing chain (VAD → ASR → LLM → TTS) and memory processing. Method: `diff` of the v0.5.0 and v0.6.3 trees, then line-level verification of each changed memory/pipeline file. The handover (`voicemem-audit-handover.txt`, authored by the developing agent) is treated as claims to verify, not evidence.

**Label key:** FACT (verified in code) / INFERENCE (implied, not executed) / PROPOSAL. Severities P0–P3 as before.

---

## 1. Executive summary — what changed since v0.5.0

**The developer read the v0.5.0 audit and acted on it.** The new code references my finding IDs directly (e.g. `mem0_backend_store.py` "closes audit finding CD-1 (P0)"; `__init__.py` patch ledger adds VM-LOCAL-007/008/009). The two P0 data-safety defects are **genuinely fixed and now covered by real behavioural tests**, and several P1/P2 items are resolved. Two P1 memory issues and the core latency problem remain.

**Verdict change:** v0.5.0 was "not production-ready" primarily because of unsafe memory mutation. Those specific blockers are fixed. v0.6.3 is **closer, but still not production-ready** — now the gating issues are (a) **production latency of 30–50 s** (admitted, unresolved; a model-vs-hardware mismatch), (b) **Hungarian temporal retrieval still absent** (CD-3), and (c) **recency still not a ranking signal** (CD-4), plus supply-chain/provenance and documentation-accuracy gaps.

**Fixed and verified (FACT):**
- **CD-1 (P0) → FIXED.** Right-brain heartnote deletion is now behind the same default-deny `VOICEMEM_ALLOW_MEMORY_DELETE` gate (VM-LOCAL-007).
- **CD-2 (P0) → FIXED.** UPDATE is now non-destructive: it appends a new observation and links `supersedes`/`superseded_by`; the old text survives and stays queryable (VM-LOCAL-008).
- **CD-5 (P1) → FIXED.** The CLI bridge now calls the real `vm.search()` / `ingest(text, agent_reply=…)` instead of duck-typed adapters that never matched the facade.
- **F-H (P2) → FIXED.** A permitted left-brain delete now cascades to cognitive-graph rows (VM-LOCAL-009) — no more orphaning.
- **F-K (P2) → RESOLVED.** LLM context raised to 32768; the 14,000-char prompt budget is now comfortably inside it.
- **Processing chain / §17 → improved at the root.** The `FusedVad` energy fallback was removed and replaced by feeding Silero its official 64-sample rolling context — a root-cause fix of the deafness that caused the original "only the Send button answers" bug. ASR handoff remains code-intact and now has a no-silent-fallback contract.
- **ASR upgraded** Qwen3-ASR-0.6B → NVIDIA Parakeet TDT 0.6B v3 (multilingual incl. Hungarian, pinned rev `541d1f99`), retiring the Qwen module that produced "repetition garbage".
- **Test quality materially improved** — new *real-behaviour* tests (`tests/integration/test_memory_safety.py`, delete-gate subprocess test, bridge-adapter test, ASR-modular test, LLM-streaming e2e) that address my §22/F-F "false confidence" finding.

**Still present / new (the remaining agenda):**
- **CD-3 (P1) STILL PRESENT** — `time_expand.py` unchanged (Chinese-only); Hungarian relative-time queries get no date expansion. More salient now that Parakeet transcribes Hungarian correctly.
- **CD-4 (P1) STILL PRESENT** — left-brain ranking sort added only the supersession key; recency (`observed_at`) still never affects ordering.
- **NEW P1 — production latency 30–50 s** (handover A.6/1): 35B IQ4_XS with 20/42 layers offloaded on a 12 GB GPU (rest streaming from RAM) cannot meet the spec's p50<2 s. Architectural.
- **CD-6 (P1) STILL PRESENT** — the GitHub mirror still isn't a source tree and is stale (handover: mirror HEAD `8b7e6fb`, not synced past v0.6.0).
- **P2 doc-accuracy** — BUILD_INFO claims "vendor/ … untouched" and "memory-safety freeze … untouched", but eight vendor memory files changed. The claim is false (though the changes are the good CD-1/CD-2 fixes).
- **F-A / F-B / confidence-inert / offline-env-dependency / START.bat double-instance** — carried over (details below).

---

## 2. Integrity & provenance (v0.6.3)

- **SHA256 verified (FACT):** `dbd97d7f…de35` on the uploaded ZIP == the handover's stated value. Integrity of the delivered artifact is confirmed.
- **BUILD_INFO accuracy (FACT, P2):** the notes say *"App architecture, the engine contract, the NO-FALLBACK rule, vendor/ and the memory-safety freeze are all untouched."* `diff` proves **eight** `vendor/voicemem` files changed vs v0.5.0 (`__init__.py`, `leftbrain/brain.py`, `cognitive_graph/store.py`, `local_memory_store.py`, `mem0_backend_store.py`, `memory_repository.py`, `memory_repository_v2.py`, `rightbrain/brain.py`). The changes are beneficial (the CD-1/CD-2/CD-9 fixes), but the "untouched" wording is inaccurate and would mislead a reviewer who trusts BUILD_INFO over a diff. *Action:* make BUILD_INFO reflect the actual vendor delta + patch ledger (VM-LOCAL-007/008/009).
- **Mirror/provenance (FACT, P1 — CD-6 persists):** the authoritative record is still shipped as ZIP blobs; the GitHub mirror is stale (handover A.6/4). There is still no diffable first-party source history for the audited code.

---

## 3. Previous-findings status (v0.5.0 → v0.6.3)

| ID | v0.5.0 | v0.6.3 status | Evidence (v0.6.3) |
|---|---|---|---|
| CD-1 | P0 ungated right-brain delete | **FIXED** | `rightbrain/brain.py` new `_execute_heartnote_deletes` (VM-LOCAL-007): `if os.environ.get("VOICEMEM_ALLOW_MEMORY_DELETE","")!="1": … return 0`; both delete branches route through it. |
| CD-2 | P0 destructive UPDATE | **FIXED** | `mem0_backend_store.py update_memory` (VM-LOCAL-008): appends new row `metadata={"supersedes":old}`, marks old `superseded_by`/`superseded_at`, refuses if no user_id, never overwrites. `MemorySearchHit.superseded_by` added; sort `key=(not h.superseded_by, h.base_score)`. `memory_repository.py` mirrors it (JSON mirror no longer overwritten). |
| CD-3 | P1 Hungarian temporal unsupported | **STILL PRESENT** | `leftbrain/time_expand.py` byte-identical to v0.5.0; `_SPANS` still Chinese-only. Parakeet transcribes HU, but retrieval date-expansion doesn't. |
| CD-4 | P1 recency dead in ranking | **STILL PRESENT** | Sort adds only `not h.superseded_by`; `observed_at` still not a ranking term (`mem0_backend_store.py` sort). |
| CD-5 | P1 CLI adapters don't match facade | **FIXED** | `voicemem_bridge.py` new `_retrieve_user_turn` uses `vm.search(query)`; commit uses `ingest(text, agent_reply=…)`; legacy table kept only as forward-compat fallback. |
| CD-6 | P1 repo = zip blobs, no tree | **STILL PRESENT** | Mirror stale (handover A.6/4); artifact still zip-delivered. |
| F-A | P1 public search bypasses rich path | **PARTIAL** | Both surfaces now deliberately use `search()` (consistency fixed via CD-5), but the rich `classify+search` remains unused; the choice should be documented as intentional or the rich path wired in. |
| F-B | P1 provenance/confidence dropped at render | **STILL PRESENT** | Memory-context render still text+date; no confidence/provenance surfaced (no diff to the render path). |
| F-D | P1 confidence inert | **STILL PRESENT** | Ranking still cosine+supersession; confidence not read left-brain. |
| F-H | P2 delete no graph cascade → orphans | **FIXED** | `cognitive_graph/store.py` new `delete_memory_record` (VM-LOCAL-009) deletes `entity_memory_links`/`memory_tags`/`graph_entity_memories`/`memories`; `memory_repository` calls it on a permitted delete; test asserts 0 orphans. |
| F-K | P2 char-budget vs context overflow | **RESOLVED** | `llm_context_size: 32768`; budget still 14,000 chars (~7k tokens) — safely inside. |
| F-F | P1 tests = source-string + mocks | **IMPROVED** | New real-behaviour suite (§6). Source-string tests remain but are now supplemented by real store/E5 tests. |

Memory-model items (§3 of the prior report) that improved: **observation history for corrections now exists** (supersession chain, §5 below). Items still open: repeated *identical* confirmations still don't create counted observations (a duplicate resolves to NONE → no write); confidence/validity/language columns still absent; provenance still not surfaced.

---

## 4. Memory processing deep-dive (verified line-level)

### 4.1 UPDATE is now non-destructive (CD-2 fix — FACT)
`vendor/voicemem/voicemem/leftbrain/mem0_backend_store.py update_memory` (VM-LOCAL-008):
- Reads the existing row; **refuses** (loud log, returns False) if it can't, if not found, or if no `user_id` can own the new row — "never falls back to in-place overwrite".
- Writes the new observation as a **new mem0 row** with `metadata={"supersedes": old_id, session_id, created_at}` via `add(infer=False)`.
- Marks the old row metadata `superseded_by`/`superseded_at` (metadata-merge keeps text + original event time).
- `memory_repository.py` mirrors this in the JSON mirror (old entry annotated, not overwritten); `memory_repository_v2.py` returns the new id.
- Retrieval: `MemorySearchHit` gains `superseded_by` (`local_memory_store.py`); the sort is `key=lambda h: (not h.superseded_by, h.base_score), reverse=True` — **current values first, superseded observations still returned after them**.
- `leftbrain/brain.py` dedup was adjusted so a supersede pair is not collapsed by near-dup dedup.
**Behavioural proof (FACT):** `tests/integration/test_memory_safety.py` runs the REAL mem0/Qdrant store + REAL E5 with a mock LLM that emits a real UPDATE decision, then asserts `old_id != new_id`, the old observation text survives, and no destructive overwrite occurred in the mem0 row or JSON mirror. This is the right kind of test.

**Residual (INFERENCE, P2):** this models *correction/supersession* well, but it is still not a full observation history for *repeated confirmations* — an identical restatement resolves to `NONE` (no write), so "observed N times / first-vs-last observed" for unchanged facts is still not counted. Supersession ≠ occurrence counting.

### 4.2 DELETE safety completed (CD-1 + F-H fixes — FACT)
- Right-brain `run_cleanup` hard-delete now gated default-deny (VM-LOCAL-007), matching the left brain; the supersede branch stays non-destructive.
- Left-brain permitted delete cascades graph rows (VM-LOCAL-009), closing the orphaning gap.
- `tests/integration/test_memory_safety.py` asserts: default env blocks delete (rows + anchors unchanged), explicit `=0` blocks, explicit `=1` deletes **with cascade and 0 orphans**. Real store.
**Net:** the three memory-safety states are now much closer to correct: destructive delete is opt-in everywhere, correction is non-destructive supersession, and archive (reversible) still exists. The remaining conceptual gap (a persistent "never true" vs "no longer known" distinction) is not yet modelled, but the dangerous silent-loss paths are closed.

### 4.3 Ranking & temporal — unchanged where it matters (CD-3, CD-4 STILL PRESENT — FACT)
- `time_expand.py` is byte-identical: Hungarian/English relative-time cues are still unhandled. For a Hungarian assistant this is the highest-value remaining memory gap: the user can *say* "mi lesz jövő héten" (Parakeet transcribes it), but the memory layer cannot expand it to a date range to retrieve the relevant entries.
- Left-brain ranking still sorts by `(not superseded_by, cosine)`; `observed_at`/recency is still computed-but-unused for ordering. "What did I say recently?" is still not recency-biased.

---

## 5. Processing-chain deep-dive (VAD → ASR → LLM → TTS)

### 5.1 VAD re-rooted (§17 — improvement, FACT)
`app/vad.py` removed the `FusedVad` energy-fallback gate and now feeds Silero its **official 64-sample rolling context** (`_SILERO_CONTEXT_SAMPLES = 64`; every call scores `[ctx(64)|frame(512)]`, carrying the last 64 samples forward; `reset()` re-zeros it). The module documents the measured effect (deaf channel 0.003 → prob_max 1.000, 235/312 frames above threshold). This addresses the **root cause** of the original "speech never reaches the LLM" field bug (Silero deafness from an incorrect feed) rather than masking it with an energy gate. **INFERENCE (strong):** this is the correct fix; it should still be confirmed on the reporter's exact capture channel (runtime `[chain]` logs: "ASR final transcript" followed by "llm first token").

### 5.2 Modular ASR + Parakeet (FACT)
- New contract layer `app/asr_core.py`: canonical `AudioBuffer` (16 kHz/mono/float32), `AsrResult`, `AsrError`, a descriptive `MODEL_REGISTRY`, and `select_engine()` — **exactly one engine, explicit, no fallback**; a load failure raises `ASR_MODEL_LOAD_ERROR` and stops the turn (no "empty transcript = success").
- Production engine `app/asr_parakeet.py` (`ParakeetForTDT.from_pretrained` from the local dir; one shared backend per (dir, device, dtype); `ASR_DEVICE=cuda` without CUDA fails explicitly). Parakeet TDT 0.6B v3 is multilingual incl. Hungarian; `language_detection=False` (single decode).
- Old `app/asr.py` (Qwen3-ASR) is retired to a "non-production migration module"; `MODELS.lock.json` asr entry migrated to `nvidia/parakeet-tdt-0.6b-v3` pinned `541d1f99` (this fixed the v0.6.1 field bug where the manifest still pointed at Qwen and Parakeet never downloaded).
- **ASR→LLM handoff (FACT):** intact. `web_server._on_vad_frame` → `asr_result = self._asr.transcribe(buffer)` → `final = asr_result.text` → `_start_turn(final)` → `_run_turn`: `user_text=text.strip()` → `build_messages(user_text, system_prompt, history)` → `c.llm.chat_stream(messages)`. No drop/alter/replace between ASR and the LLM request.
- **Offline caveat (P2, carried):** Parakeet load relies on `HF_HUB_OFFLINE`/`TRANSFORMERS_OFFLINE` env rather than an explicit `local_files_only=True` in `from_pretrained` — env-configured, not code-enforced (same pattern as the vendor LLM clients).

### 5.3 Production LLM profile (FACT + one open risk)
`config/voicemem_config.yaml`: `llm_context_size: 32768`, `llm_n_gpu_layers: 20`, `llm_parallel: 1`, `temp 0.7`, `max_tokens 512`, reasoning off. The 32K window resolves the earlier context-overflow risk (F-K). The measured TTFT delta (ngl20+8192 ≈ 4.90 s vs ngl20+32768 ≈ 4.89 s) is credible *for the sandbox 0.6B stand-in*.
- **NEW P1 — production latency 30–50 s (handover A.6/1, unresolved).** On the target (RTX 5070 12 GB), the 35B IQ4_XS (~19 GB) runs with only 20/42 layers on GPU and the remainder streaming from system RAM. That is the source of the 30–50 s end-to-end latency, which is an order of magnitude above the spec's p50<2 s / p95<2.5 s. This is a **model-vs-hardware mismatch**, not a code bug, and the 32K decision does not address it. *Options to evaluate (PROPOSAL):* a smaller/faster production model (or a more aggressive quant / MoE CPU-offload tuned to this GPU), or resetting the latency target. This should be the headline production decision, above any further memory work.

### 5.4 TTS/language routing — unchanged, still correct (FACT)
Piper via subprocess; per-chunk `detect_language` on the **reply** text selects the voice; no translation of Hungarian to English. (Same as v0.5.0; the heuristic-misroute P3 stands.)

---

## 6. Test-quality delta (§22 follow-up)

New/changed tests that add **real** confidence (FACT):
- `tests/integration/test_memory_safety.py` (700 lines) — real mem0/Qdrant + real E5 + mock-LLM-decision; proves delete gate (default deny / =0 deny / =1 delete+cascade+no-orphans) and non-destructive UPDATE (old text survives, explicit supersede link, no overwrite). Directly cites and closes F-F.
- `tests/unit/test_voicemem_controlled.py` — added `test_delete_guard_blocks_without_opt_in` (subprocess, pops the env, asserts "DELETE-GUARD-OK") — behavioural, not source-string.
- `tests/unit/test_asr_modular.py`, `test_voicemem_bridge_adapters.py`, `test_vendor_llm_env_pin.py`, `tests/integration/test_llm_streaming_e2e.py`, `tests/forensic_llm_mock.py` — cover the new ASR engine, the bridge fix, vendor LLM env pinning, and streaming.

**Still missing real tests (carried):** Hungarian temporal cues, cross-language retrieval (EN↔HU), recency ranking, ASR→LLM handoff assertion (that transcript X reaches the request), retrieval-path selection. The test gate itself is honest about its 1 documented failure (the rollback-deleted v0.6.1.zip in `test_feature_release`) — a bookkeeping artefact, not a product defect.

---

## 7. Remaining findings register (v0.6.3)

| ID | Sev | Label | Status | Evidence |
|---|---|---|---|---|
| CD-3 | P1 | FACT | STILL PRESENT | `leftbrain/time_expand.py` Chinese-only (unchanged) |
| CD-4 | P1 | FACT | STILL PRESENT | `mem0_backend_store.py` sort = `(not superseded_by, base_score)`; recency unused |
| LAT-1 | P1 | FACT/INFER | NEW / OPEN | 35B IQ4_XS, 20/42 offload on 12 GB GPU → 30–50 s (handover A.6/1; `config` ngl20/32K) |
| CD-6 | P1 | FACT | STILL PRESENT | mirror stale `8b7e6fb`; zip-delivered source (handover A.6/4) |
| F-A | P1 | FACT | PARTIAL | both surfaces use `search()`; rich `classify+search` unused/undocumented |
| F-B | P1 | FACT | STILL PRESENT | render path drops provenance/confidence |
| DOC-1 | P2 | FACT | NEW | BUILD_INFO "vendor untouched" false — 8 vendor files changed |
| BAT-1 | P2 | INFER | OPEN | START.bat /health guard blind during ~19 GB load → 2nd llama-server (handover A.6/2; process guard only proposed) |
| OFF-1 | P2 | INFER | CARRIED | offline is env-configured (no `local_files_only`, no loopback hard-guard) |
| OCC-1 | P2 | INFER | CARRIED/PARTIAL | supersession added; repeated identical observations still uncounted (occurrence) |
| SEC-1 | P2 | COULD NOT VERIFY | OPEN | web backend (8787) bind/auth — not re-examined this round (handover A.6/9); verify 127.0.0.1 bind + no-auth exposure |

---

## 8. Roadmap delta & verdict

**Resolved from the v0.5.0 roadmap:** A1 (right-brain delete gate), A2 (non-destructive UPDATE), B2 (delete cascade), C2 (reconcile integration paths), F-K (context budget). Stage-A data-safety blockers are **cleared**.

**New priority order (v0.6.3):**
1. **LAT-1 (P1) — decide the production model/latency story.** 30–50 s makes the assistant unusable against its own spec; this outranks further memory features. Evaluate a smaller/faster model or a re-set target with the client.
2. **CD-3 (P1) — Hungarian + English temporal cues** in `time_expand.py` (+ tests). Highest-value remaining *memory* fix for a Hungarian product.
3. **CD-4 (P1) — recency ranking** on event time (`observed_at`), verifying event-vs-record time semantics first.
4. **CD-6 (P1) — commit a real source tree / sync the mirror.**
5. **F-A / F-B / OCC-1 / DOC-1 / BAT-1 / OFF-1 / SEC-1 (P2)** — document the retrieval-path choice, surface provenance/confidence, add occurrence counting, correct BUILD_INFO, apply the process-level START.bat guard, add `local_files_only`/loopback hard-guards, and confirm the 8787 bind/auth posture.

**Production readiness verdict:** **Improved, still not ready.** The memory engine is now *safe* (no silent history loss, no ungated emotional delete) and the processing chain is cleaner (root-caused VAD, no-fallback ASR contract, Parakeet multilingual ASR, 32K context) — a real step forward, and the developer's evidence-driven, test-backed response to the prior audit is a positive process signal. But it should not go live until **latency (LAT-1)** is resolved and **Hungarian temporal retrieval (CD-3)** and **recency ranking (CD-4)** are implemented and tested, because those three determine whether a Hungarian long-term-memory voice assistant actually works for its user. Continue to **evolve, not rewrite** — the substrate is sound and the last two rounds prove the fix loop works.

---

*Method note: every FACT above was read at the cited `file:line` in the byte-verified v0.6.3 tree (`dbd97d7f…de35`) and, where stated, cross-checked against v0.5.0 via `diff`. Handover claims were verified against code, not accepted. No project files were modified; no fixes were implemented.*
