# VoiceMEM v0.9.2 — Runtime Optimisation + Memory Retrieval Budget

**Evidence package — every material claim labelled FACT / INFERENCE / PROPOSAL.**

- Baseline: v0.9.1 release commit 25a44d5 (ZIP SHA256 `c4b5ab4b…`), audit HEAD add7e91.
- Sandbox: 2-CPU Xeon, 4 GB RAM. **All llama-server wall-times here are SANDBOX
  MEASUREMENTS on the version-exact binary (llama.cpp b10717 ubuntu-x64, build
  10717, commit a32af33de) with a Qwen2.5-0.5B-Instruct Q4_K_M stand-in model.**
  They prove MECHANISM and CACHE RATIOS, not target latencies. The RTX 5070
  production numbers differ; the cache-hit token counts and request shapes are
  model-independent (FACT).

## 1. PART 0 — Baseline [FACT]
HEAD add7e91; VERSION 0.9.1; agent tree content-clean (file-mode drift only).
llm_config.yaml unchanged: qwen3.6-35b-a3b / ngl 20 / ctx 32768 / parallel 1 /
KV q8_0 / temp 0.7 / max_tokens 512 / reasoning off. Environment rebuilt
(v0.9.1-era raw evidence at /home/z/vmforensic was lost to sandbox state
reset; all v0.9.2 measurements re-made from the vendor tree).

## 2. PART 1 — llama-server b10717 cache capabilities [FACT]
Source + binary verified (b10717 ubuntu-x64 runs in sandbox; help + source):
- **RAM-backed prompt cache**: `--cache-ram N` (default 8192 MiB, 0=disable;
  PR #16391). `server_prompt_cache` stores per-slot KV states (list of
  `server_prompt_cache_state`: prompt tokens + KV checkpoint data) in RAM.
- **LCP restore**: `server_prompt_cache::load` picks the cached state with the
  best keep/similarity (Longest Common Prefix with the new tokens, f_keep ≥
  0.25, f_sim maximised) and restores it via `llama_state_seq_set_data_ext`.
- **Intra-slot reuse**: a new request on the same slot reuses its KV up to the
  common prefix (reported as `prompt_tokens_details.cached_tokens`).
- **Idle-slot save**: `--cache-idle-slots` (default ON when cache-ram enabled):
  on a new task, idle slots are saved into the RAM cache; with unified KV they
  are cleared (KV returned to the shared pool).
- **Slot selection**: `--slot-prompt-similarity` (default 0.10) — LCP-based.
- **parallel=2**: `n_ctx_slot() = llama_n_ctx_seq / n_parallel` → per-slot
  context HALVES to 16384 with -c 32768 [FACT, measured log: n_ctx_slot=32768
  at parallel=1; E3 startup log shows the divide].
- Cache size limit eviction: oldest-first when over `--cache-ram` bytes.
- KV quantisation (q8_0/q8_0) orthogonal to the prompt cache (states are raw
  checkpoint bytes).

## 3. PART 2 — extraction prefix decomposition [FACT]
Byte-exact reconstruction (cross-validated: system 8,844 tokens == v0.9.1
wire-tap audit; app-side total 10,397 ≈ server 10,367):
- STATIC system 8,844 (base prompt 7,923 + LANGUAGE 87 + ATTRIBUTE 244 +
  VOICE 593)
- user side 1,553 = sections 513 (Existing 177, New 110, dates 30, headers
  ~25, Language Requirement 179 — stable text but placed AFTER the dynamic
  sections) + merged addendum 1,040 (static, was appended at END)
- **95.4% static**; only ~180 tokens/turn are the actual new conversation.

## 4. PART 3 — cache behaviour measured (version-exact b10717) [FACT]
Production-shaped payloads, -c 32768, q8_0 KV, cache-ram default:

| experiment | config | extraction_1 | chat | extraction_2 (warm) | cached |
|---|---|---|---|---|---|
| E1 cold | orig. prompt | 517.4 s | — | — | 0/10,398 |
| E2 cache ON | orig. prompt | 548.6 s | 12.3 s | 189.0 s | **8,912/10,399 = 85.7%** |
| E2b cache OFF + reduced | reduced | 551.9 s | 2.4 s | 357.9 s | 3/8,594 |
| E3 parallel=2 + reduced | reduced | 359.1 s | 4.7 s | 116.8 s | 7,107/8,594 |
| E4 parallel=1 + reduced, cache ON | reduced | 405.3 s | 4.9 s | 111.3 s | 7,107/8,594 = 82.7% |

- The RAM prompt cache survives a full intervening chat request (E2: 85.7%
  restored after the chat trashed the only slot) — the exact production
  interleaving. [FACT]
- With cache OFF the second extraction is fully re-evaluated (E2b control).
- chat TTFT effect of a concurrently-prefilling extraction: sandbox FIFO
  measurement from the v0.9.1 audit (163.2 s behind a 10.4K prefill;
  1.76 s alone) — the mechanism the v0.9.2 scheduler removes.

**Implemented**: merged addendum MOVED to the FRONT of the user message
(vendor extract(): `prompt_addendum() + "\n\n" + sections`), lifting the
cacheable prefix from system-only (8.8K) to system+addendum.
**E5 measured (reordered assembly, production config)**: extraction_2
restores **8,146/8,594 = 94.8%** of the prompt; warm extraction **35.9 s
vs 459.4 s cold (12.8×)**; only 448 tokens re-evaluated per turn.
Semantics preserved (output-schema text; the "The prompt above"
references still resolve to the system prompt).

## 5. PART 4 — CPU/cache placement [FACT + INFERENCE]
The prompt cache is ALREADY RAM-resident (CPU) by design in b10717 —
states leave VRAM when slots are saved/cleared; restore re-uploads the KV
checkpoint bytes. Nothing was moved: enabling it is a server flag, already
on by default. GPU occupancy is bounded by the reduced prompt + max_tokens.
[INFERENCE] No additional CPU offload is warranted: the KV upload cost is
the restore path itself and it measured 2.9× faster than re-evaluation.

## 6. PART 5 — background scheduler [FACT — implemented + tested]
`app/background_memory.py` (BackgroundMemoryGate):
- armed on the FIRST VAD speech frame + turn start; released at
  answer_done/error/interrupt + 2 s grace (VOICEMEM_BG_GRACE_S);
  re-arms instantly on new speech inside the grace window.
- pairs queued (deque), never dropped, exact duplicates coalesced;
  one-at-a-time sequential worker; ingest runs with vendor async_facts=False
  inside asyncio.to_thread so the WHOLE background chain (extraction →
  conflict → scoring) is visible and completes before "done".
- an in-flight extraction is NOT aborted (memory updates must not be lost);
  its duration is bounded by PART 6/7 instead.
- worker spawned through the session registry → disconnect cancels it (the
  old single _bg_store_task contract, preserved).
- 12 unit tests green (ordering, grace, re-arm, coalescing, failure
  survival, status callbacks, spawn registry, env override).

## 7. PART 6 — extraction output limits [FACT — implemented + tested]
max_tokens added where llama-server previously ran n_predict=-1:
- pair-ingest extraction: 1536 (VOICEMEM_EXTRACT_MAX_TOKENS; schema worst
  case ≈ 800 tokens: ≤6 facts × 15-80-word texts + slot/entities/relations/
  attribute annotations + traits + emotion → 2× headroom)
- conflict resolver: 1024 (VOICEMEM_RESOLVE_MAX_TOKENS; NONE entries are
  omitted per the prompt contract, typical 0-3 entries)
- invalid env values fall back to the defaults (never unbounded);
  finish_reason=length is loudly reported; truncated JSON fails CLOSED
  (json.loads raises → no partial memory writes; proven by test).
- app-side conversational max_tokens stays 512 (pinned by test).
- 6 unit tests green.

## 8. PART 7 — prompt reduction [FACT — implemented + tested]
additive_extraction_prompt.txt: 7,923 → 6,118 base tokens (−22.8%),
full system 8,844 → 7,042. Every cut is one of three evidence classes
(manifest: prompt_reduction_manifest.json):
- EXAMPLE_OVERLAP (2/5/9 removed; 1/3/6/7/10/12 kept and renumbered)
- TEXTUAL_DUPLICATION (8: Bajimaya pair kept verbatim in Integrity Rules;
  11: multi-topic restated in ROLE+Checklist; "Extract ALL dimensions"
  paragraph duplicate of ROLE)
- INPUT_DOMAIN (Shared Photos section — ASR transcripts cannot contain
  photo markers)
No quality standard, integrity rule, temporal anchor, output schema, or
safety-critical instruction was touched. Structural equivalence pinned by
5 tests (38 required signals present, forbidden cuts stay out, example
count/numbering, size band, request shape).

## 9. PART 8 — combined effect [FACT]
E4 (production config: parallel=1, cache default ON, reduced prompt):
cold 405.3 s → warm 111.3 s (−72.6%), 82.7% cached; evaluated tokens per
extraction ≈ 1,487 → with the addendum reorder (E5) the prefix extends by
a further ~1,040 static tokens. App-side prompt: 10,397 → 8,415 (−19.1%).
Net per-turn background GPU work after both: ~400-450 evaluated tokens
warm (was 10.4K cold) + bounded decode.

## 10. PART 9+10 — retrieval cardinality [FACT — measured]
Production search path (real E5 + qdrant store, 30-fact controlled corpus,
12 fixed HU/EN queries with labeled relevance, renderer-exact context):

| k | recall | avg noise hits | avg ctx tokens | near-dups |
|---|---|---|---|---|
| 5 | 0.875 | 3.67 | 123 | 1 |
| 8 | 0.917 | 6.58 | 197 | 1 |
| 10 | 0.917 | 8.58 | 246 | 1 |
| 12 | 0.917 | 10.58 | 296 | 2 |
| 16 | 0.917 | 14.58 | 392 | 3 |

- recall plateaus at k=8: the residual miss (Q10 "Mikor szokott futni…") is
  an EMBEDDING miss (the fact is outside top-16) — not a top-k cutoff.
- DECISION: **KEEP top_k=5, rb[:3]** (PROPOSAL→implemented as no-change).
  Rationale: +4.2 pp recall at k=8 costs +60% context tokens and +79% noise;
  beyond k=8 nothing more relevant arrives, only weak memories — the task
  rule "prefer fewer relevant memories over more weak memories" decides.

## 11. PART 11 — 1200/6000 cleanup [FACT — implemented]
The v0.9.1 audit proved the funnel is top_k=5 + rb[:3]; the 1200-char slice
does not bind at realistic densities (measured 123-197 tokens per context);
the 6000 cap was dead by construction (applied after the 1200 slice).
v0.9.2: `_MEMORY_CONTEXT_MAX_CHARS` unified to 1200 — the SINGLE canonical
character guard; the dead 6000 dual cap removed; canonical budget documented
at the constant. Behaviour unchanged for every reachable input (renderer
pre-slices at 1200); 12/12 prompt-budget tests green.

## 12. PART 12 — history window [FACT — measured, no change]
8 entries (= 4 turn pairs) → 592 tokens average prompt (matches the audit's
~600 converged). Growth: 4→400, 8→592, 12→687, 16→877, 20→1,025 tokens.
The 14000-char budget never binds; turn pairs stay coherent (even window).
DECISION: KEEP 8 — no evidence of a real problem.

## 13. PART 13 — request count/shape [FACT]
Call graph unchanged (no LLM call site added/removed; the gate only defers).
Per turn type the v0.9.1 audit counts stand (2-6 requests). Captured shapes:
- extraction: system 7,039 + user 1,376 tokens, temp 0, json_object,
  **max_tokens 1536**, user message LEADS with the merged addendum.
- conflict resolver: user 2,052 tokens, temp 0, json_object,
  **max_tokens 1024**.

## 14. PART 14 — target-hardware validation [NOT PERFORMED — sandbox only]
All measurements above are sandbox (2-CPU). The RTX 5070 numbers need the
operator's one-run measurement: chat TTFT with/without background work,
extraction prompt_ms, VRAM at parallel 1 (the parallel=2 option was NOT
adopted — no VRAM pressure tradeoff taken; E3 shows cache benefit without
it). Expected target behaviour [INFERENCE]: warm extraction prefill
~1.5K→~0.45K tokens ⇒ seconds-level, contention window closed by the
scheduler regardless.

## 15. PART 15/16 — regression gates [FACT]
- VAD: test_web_vad_trigger_frame 3/3 green (trigger frame retained, "Szia"
  fix intact, 1 sentence = 1 turn).
- Memory semantics: supersession / retrieval-contract / trait semantics
  + all new v0.9.2 tests: 87/87 green.

## 16. PART 17 — open issues reclassification
- FIXED by v0.9.2: unbounded extraction/conflict output (P0-2);
  extraction-vs-chat contention (P0-1, scheduler + cache + reduction);
  10.4K static prompt (P1-1); dead 6000 cap (P1-2).
- STILL PRESENT (documented, not expanded): stance scanner fact-path gap;
  mixed past+negation; un-timestamped replay; archive reactivation; TTL
  producer; cross-language thresholds; occurrence semantics; embedding
  version tracking; Web/CLI prompt differences; emotion wording; Q10-class
  embedding misses (new, measured).
- NEW P2 (documented): two more unbounded-but-conditional vendor legs found
  (rightbrain cleanup prompt, right-channel relevance filter) — not on the
  per-turn path, left unchanged per the no-scope-creep boundary.

## 17. PART 18 — boundaries respected [FACT]
Model unchanged (Qwen3.6 35B A3B IQ4_XS), context 32768, parallel 1,
VoiceMem/E5/ASR/TTS untouched, no search_rich, no Observation Store,
offline guarantees intact, no second model.

## 18. PART 20/21 — release + recovery
See RELEASE section of REPORT.md addendum in the release ZIP; identity in
IDENTITY.json. Mirror sync: PAT absent from the sandbox (state loss, the
documented class) — staged for the operator.
