# VoiceMEM v0.9.2 Recovery Package — Runtime Optimisation + Memory Retrieval Budget

## Identity
- Release commit: **eda974f** (release) / **4222359** (ZIP staging)
- Baseline: v0.9.1 release commit 25a44d5 (audit HEAD add7e91)
- Release ZIP: `releases/VoiceMemAgent_v0.9.2.zip`
  - SHA256: `3A9CAAF44FBFAE6FCE8449E781E42A6007434D9C062C37270C5D8B566DACBF05`
  - 353 files, 2619.3 KB
- Gate: **GREEN** on tree fingerprint `a74af6c54a85f288…` — 1253 tests,
  0 regressions, 13 pinned sandbox env-gap failures (documented), deep
  validation PASS [embedding, memory, memory-semantics, release, runtime-deps].

## What changed (16 files; full diff: evidence/code.diff)
1. **vendor/…/extract_facts_openai.py** — extraction max_tokens=1536,
   conflict max_tokens=1024 (env-overridable; invalid → default; truncated
   JSON fails CLOSED; loud finish_reason=length) + merged addendum moved to
   the FRONT of the user message (prefix-cache).
2. **vendor/…/additive_extraction_prompt.txt** — 7,923 → 6,118 base tokens
   (−22.8%); every cut evidence-classed EXAMPLE_OVERLAP / TEXTUAL_DUPLICATION
   / INPUT_DOMAIN (manifest: evidence/prompt_reduction_manifest.json).
3. **vendor/…/mem0_additive_prompt_build.py** — provenance docstring only.
4. **app/background_memory.py** (NEW) — BackgroundMemoryGate scheduler.
5. **app/web_server.py** — gate wiring (arm on VAD speech_start + turn start;
   release at answer_done/error/interrupt + 2 s grace; submit replaces the
   fire-and-forget _store); RealMemoryLayer.ingest(wait=True) → vendor
   async_facts=False; DemoMemoryLayer parity kwarg; canonical memory budget
   comments; dead 6000 cap removed (single 1200 guard).
6. **tests/** — 4 new files (+1 isolation runner): extraction limits (6),
   background gate (12), prompt reduction equivalence (5).
7. **scripts/build_release_sandbox.py** — 0.9.2 markers + notes.
8. Version surfaces: VERSION, pyproject.toml, voicemem_config.yaml,
   web/voicemem.html (PAGE_VERSION), CHANGELOG.md.

## Measured before/after (version-exact b10717 sandbox; token counts are
model-independent FACTs, wall-times are SANDBOX MEASUREMENTS)
- Extraction prompt: 10,397 → 8,415 app-side tokens (−19.1%).
- Per-turn evaluated tokens (warm): 10,397 → **448** (−95.7%, E5: 94.8%
  cached = 8,146/8,594; 35.9 s vs 459.4 s cold on the stand-in model).
- Extraction output: unbounded (n_predict=−1) → 1536 tokens.
- Conflict output: unbounded → 1024 tokens.
- Background work: free-running (can occupy the only llama-server slot while
  the user speaks) → deferred while a turn is active (gate + 2 s grace).
- Retrieval cardinality: measured; KEEP top_k=5 + rb[:3] (recall plateau at
  k=8: 0.875→0.917→plateau; noise 3.67→14.58; ctx 123→392 tok).
- History: KEEP 8 entries (592 tok; 14000-char budget never binds).

## Rollback instructions
1. Stop the agent (START.bat / web server).
2. `git revert eda974f 4222359` (or check out 25a44d5 for the exact v0.9.1
   tree) — the v0.9.1 ZIP is also in `releases/VoiceMemAgent_v0.9.1.zip`
   (SHA256 c4b5ab4b…).
3. Re-run `python scripts/run_release_gate.py` — expect GREEN on the pinned
   sandbox baseline.
4. No database migrations are involved (no schema change; the memory store
   format is untouched). No configuration migration: the llama-server
   command line is UNCHANGED (context 32768, parallel 1, q8_0 KV — the
   prompt cache is on by default in b10717; no new flag is required).
5. If only the vendor limits must be rolled back (keep everything else):
   unset the new env behaviour by reverting only
   `vendor/voicemem/voicemem/leftbrain/extract_facts_openai.py` — the
   scheduler degrades gracefully to the old timing when extraction returns
   without limits (it never depended on them).

## Verification of this package
- SHA256SUMS.txt covers every file in this package (verify with
  `sha256sum -c SHA256SUMS.txt`).
- The evidence JSONs are the raw experiment outputs (E1–E5, decomposition,
  block audit, reduction manifest, history benchmark, request shapes,
  cardinality) + the gate record.
