# VoiceMem v0.10.6 Recovery — TTS FORENSIC FIX (edac5c9 properly released)

Identity
- Product: VoiceMemAgent v0.10.6 (releases/VoiceMemAgent_v0.10.6.zip)
- SHA256: A310E679F5F6C1A3043F0DB736607DAB3691410B80CDBFA8CEB00E9864046CCC
- Gate: GREEN, 1521 tests, 0 regressions, 2 pinned sandbox env-gap,
  30 skipped, deep PASS [embedding, memory-semantics, release,
  runtime-deps, vad]; fingerprint
  672434143af31d709a6b74999044a5e9d3d443357d08890c02a37490d6bc3bc1
  (record: releases/gate_record.json)
- Scope: EXACTLY ONE production change — commit edac5c9
  (app/text_utils.py): leading-neutral absorption for unquoted
  foreign-phrase runs. Everything else is release bookkeeping
  (version metadata, V0106 builder markers, the stale tree
  BUILD_INFO.json housekeeping) and two test-only files.

## A. MI VÁLTOZOTT (what changed)

The v0.10.5 release ZIP did not contain the leading-neutral
absorption fix (it was committed to the tree as edac5c9 after the
v0.10.5 build). v0.10.6 releases it through the full v0.8.1
gate-order: version/CHANGELOG/page-version bumped FIRST, the complete
gate run on that exact tree (fingerprint-bound record), then the
build.

The fix itself (app/text_utils.py, +67/−3):

1. `PHRASE_RUN_LEADING_BUDGET = {en: 1, hu: 0}` — the mirror of the
   trailing budget: a formed foreign run may absorb up to ONE
   signal-free word immediately BEFORE its first evidence word.
2. `PHRASE_RUN_LEADING_MIN_EVIDENCE = 2` — the loanword shield: a
   single-evidence run ("touch base", "catch up") never absorbs its
   leading neutral word, so "Holnap touch base." keeps "Holnap" with
   the Hungarian host.
3. `_absorb_leading()` guards — host-evidence words block, only
   purely alphabetic tokens absorb, hyphen-trimmed (Hungarian-suffixed)
   stems never absorb, sentence-final punctuation before the candidate
   blocks.

Why: English idiom heads are orthographically signal-free ("**cut**
to the chase", "**hit** the ground running", "**burn** the midnight
oil"), so an evidence-only run start amputated the head into the host
span — the field-reported half-Hungarian pronunciation of embedded
idioms. With the fix the whole idiom is spoken by the English voice.

Explicitly NOT changed: no lexicon, no new detection system, no
engine/chunking/voice change, no ambiguous-word rule loosened (the
protected classes — hazai, autó/auto, tea, euro, projekt, only,
really, city, money, many — are pinned byte-identical by the existing
tests); "break a leg" (zero orthographic evidence) remains a
documented limitation.

Tests: tests/unit/test_tts_code_switching.py 61 → 81 (four idioms
explicit, both hosts; the 10-sentence mandatory matrix; the guard
battery; streaming chunk-boundary documentation; web + CLI integration
sequences). Two further test-only files ship (test_asian_script_guard.py
new, test_pipeline_mock.py span-vs-chunk counting adaptation — no
production counterpart).

Environment note (not a product change): the sandbox environment was
restored before the gate (pinned torch 2.7.0+cpu, transformers
5.17.0, onnxruntime 1.23.0, openai 3.14.0, mem0ai + qdrant-client +
sentence-transformers, the E5 model at pinned revision 614241f6, the
Qwen3.6 tokenizer at 995ad96e, silero ONNX at 394d7e6b, and all 28
released ZIPs restored with SHA-256 verification). The earlier RED
gate was environment-only (byte-identical failure sets before and
after the fix, stash-proven); this gate ran on a genuinely green
environment. The `pip install -e vendor/voicemem` variant that
enables the "memory" deep-validation feature destabilised the 4 GB
sandbox (kernel OOM-kill of the unit package — dmesg evidence) and was
therefore not used; the deep-validation skip count reflects that.

## B. CÉLGÉPI VISELKEDÉS-PLAYBOOK (if the target misbehaves)

- Hungarian sentences that EMBED an English idiom with a signal-free
  head are now spoken fully by the English voice (previously the head
  word was read with the Hungarian G2P). This is the intended change —
  compare against v0.10.5 to confirm.
- Any OTHER behavioural difference → NOT this release by construction
  (the only production delta is the absorption rule above; verify via
  the code.diff in evidence/). Capture the failing sentence + the
  web-server.log chunk trail, then roll back (D).
- The loanword protections to re-check on target: "Holnap touch
  base." (Holnap stays host), single English loans stay host,
  Hungarian-suffixed stems ("base-t") stay host, digits/URLs never
  absorb.
- If in doubt: fall back to v0.10.5 (D) and report the sentence to the
  forensic pipeline (audit/VoiceMEM_tts_codeswitch_v0105_forensic).

## C. CÉLGÉPI ELLENŐRZÉS (target-side verification)

1. `sha256sum VoiceMemAgent_v0.10.6.zip` == the sidecar value above.
2. The 10-sentence matrix of the forensic audit: the four idiom
   sentences ("cut to the chase", "hit the ground running", "burn the
   midnight oil", "break a leg") spoken by the correct voices (the
   first three EN inside HU; "break a leg" in a HU host stays HU —
   documented limitation).
3. Regression spot-check: pure HU, pure EN, quoted English, ambiguous
   loans (hazai/autó/tea/euro/projekt) — unchanged behaviour.

## D. VISSZAÁLLÍTÁS (rollback)

Replace the v0.10.6 deployment with the v0.10.5 package
(`VoiceMemAgent_v0.10.5.zip`, SHA256
401814AC02E81E6258C9BF8C8E6D3656482769ED56AE789CCBDA8AA6BBE7C01C)
and restart via START.bat. No data migration is involved (the release
changes no persistence, no schema, no config semantics). The memory
and logs directories are untouched by both versions.

## E. EVIDENCE IN THIS PACKAGE

- `evidence/code.diff` — the release-to-release production delta
  (v0.10.5 release commit 37baefb → v0.10.6 release commit 124b958):
  the edac5c9 text_utils.py fix + the two test-only files + version
  metadata.
- `evidence/gate_record.json` — the GREEN gate record
  (fingerprint-bound to the exact released tree).
- `evidence/changelog_head.txt` — the stamped 0.10.6 CHANGELOG entry.
- `identity.json` — machine-readable identity (versions, SHAs,
  commits, file list).
- `mirrorsync/` — the mirror synchronisation evidence (added after
  the sync run).
