# VoiceMEM v0.10.0 — Helyreállítási csomag (temporal / memory semantics)

**Mit tartalmaz:** a v0.10.0 (memória-szemantika és temporális memória) kiadás
telepítési/helyreállítási útjai, identitása és bizonyítékai.

## A) Helyreállítás a kiadott ZIP-ből (ajánlott)

1. Töltsd le: `VoiceMemAgent_v0.10.0.zip` (SHA-256 a lenti identity.json-ben —
   a letöltést ELŐTTE ellenőrizd a `.sha256` sidecar-ral).
2. Csomagold ki egy ÜRES könyvtárba (egyetlen legfelső szintű mappa:
   `VoiceMemAgent_v0.10.0/`).
3. `START.bat` (a telepítő: venv létrehozás, függőségek, vendor editable
   install, pin-ellenőrzés, súlyok letöltése/elhozatala).
4. A v0.9.2 → v0.10.0 váltás **nem igényel adatmigrációt**: minden új
   szemantikai mező ADDITÍV metaadat a meglévő sorokon (a régi sorok
   valid_from/valid_until nélkül = pontosan a v0.9.2 rangsor, byte-identikusan
   — randomizált bizonyítással a tesztcsomagban).

## B) Helyreállítás git-ből

```
git clone <tükör> && cd VoiceMEM/source
git checkout a394b69   # v0.10.0 release commit
```
(a forrásfa a tükör `source/` almappája; a ZIP-ek a tükör gyökerében)

## C) Visszagörgetés a v0.9.2-re

A v0.10.0 NEM töröl és NEM migrál semmit — a v0.9.2 bináris visszatelepítése
önmagában elegendő (`VoiceMemAgent_v0.9.2.zip`, SHA `3A9CAAF4…`). A v0.10
által írt új metaadat-mezőket (stance, valid_from, valid_until, observed_at)
a v0.9.2 kód egyszerűen nem olvassa — az adatbázis így is olvasható marad.

## Identitás és bizonyítékok

- `identity.json` — commitok, SHA, gate-számok, scope
- `evidence/gate_record.json` — a ZÖLD kapurekord (ujjlenyomat-kötött)
- `evidence/code.diff` — a v0.10 termelő kódváltozása (app + vendor + scripts)
- `evidence/changed_files.txt` — teljes fájlstatisztika
- `evidence/PHASE0_BASELINE_AND_SEMANTIC_MAP.md` — a PHASE 0 forenzikus
  alapvonal + 15 kérdéses szemantikai térkép (a kódváltás ELŐTT rögzítve)
- `evidence/REPORT.md` — a végső jelentés (IMPLEMENTED/MEASURED/TESTED/
  VERIFIED/RELEASED/OPEN)
- `evidence/zip_verification.txt` — a ZIP tartalmának ellenőrzési kimenete

## Ismert határok (nem regresszió)

- A fact-oldal replay-védelem time-guardja továbbra is last-write-wins (a
  trait-oldalon áll; dokumentált határ a MEMORY_SEMANTICS.md-ben).
- Tranzitív lánc-lekérdezés (history-walk a keresésben) v0.11-jelölt.
- A gate 8 pinned env-gap tesztje sandbox-környezeti (súlyok helye), a
  célgépen zöld — lásd a gate rekordot.
