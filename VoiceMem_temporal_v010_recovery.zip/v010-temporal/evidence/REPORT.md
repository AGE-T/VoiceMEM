# VoiceMEM v0.10.0 — Végső jelentés (memória-szemantika és temporális memória)

**Dátum:** 2026-09-15 · **Kiadás:** VoiceMemAgent_v0.10.0 · **SHA256:** `472FB043ECFBAC43A5487B91C60F81889527F803601B1E3C73D2A816A2220E67` (2653.4 KB, 357 fájl)
**Gate:** GREEN — 1350 teszt, 0 regresszió, 8 pinned env-gap, deep validáció PASS [embedding, memory, memory-semantics, release, runtime-deps], fingerprint `c63ba291…` (a csomagolt fa = a gate-elt fa, ujjlenyomat-kötött rekord)
**Bemeneti operátori utasítás:** PHASE 0 forenzikus alapvonal ELŐBB, csak utána termelő kód; nincs Observation Store; a szemantika bizonyításon alapuljon.

> **Őszinteségi jegyzet a folyamatról:** az előző munkamenet a CHANGELOG 0.10.0 bejegyzését előre megírta (a "Tesztkapu: PASS" és a ZIP-sor még bizonyíték nélkül állt ott — a session a PHASE 11 végén megszakadt, a gate és a build sosem futott le, és a venv + modellek + PAT ismét elvesztek). Ez a munkamenet: (1) helyreállította a tesztkörnyezetet (CPU-torch, sentence-transformers, qdrant, mem0, vendor editable, E5 + Qwen3-tokenizer súlyok), (2) lefuttatta a tényleges gate-et — az első futás 2 "regressziót" jelzett, MINDKETTŐT környezeti állapotvesztésként gyógyította (tokenizer + release-zipek visszaállítása SHA-ellenőrzéssel), nulla kódváltoztatással —, (3) lefuttatta a buildet, amely a CHANGELOG bejegyzést a VALÓDI, rekordból pecsételt számokkal írta felül (1350/8/0). A kiadás most már teljes körűen bizonyított.

---

## IMPLEMENTED (mit valósít meg a v0.10.0)

1. **`voicemem/leftbrain/temporal.py`** (311 sor, új) — determinisztikus (0 LLM, 0 prompt-változás) tény-oldali temporális osztályozás:
   - `fact_stance` — a megfigyelés stance-a, a `rightbrain/stance.py` közös szókincsével (pos/neg/past/qualified/uncertain/**future**) — a QUOTE a ground truth (a "quote-rescue" út).
   - `fact_validity` — `valid_from`/`valid_until` a tény saját szavaiból (csak ha a mondat maga határolja).
   - `query_temporal_intent` — a KERESÉS most/mult/jövő szándéka (HU+EN), keresésenként egyszer.
   - `fact_status` / `row_status` — SZARMAZTATOTT státusz (current/historical/superseded/future), SOHA nem tárolt enum.
   - `temporal_rank_tier` — a rangsor tier-táblája; legacy sorokra a v0.9.2 sorrend BYTE-IDENTIKUS (randomizált bizonyítással).
2. **`rightbrain/stance.py`** — `future` a közös stance-szókincsbe (`_FUTURE_CUES`), a trait-oldal ugyanazt a szót használja.
3. **Eseményidő-horgony javítás** (`orchestrator.py`) — a ts-fallback valódi ISO dátum; a régi "15:18:36" időkarakterlánc minden parserben elhalt (extrakciós Observation Date horgony, recency-súly, [dátum] prefix — a PHASE 0 bizonyította, hogy a termelési úton mind halott volt).
4. **Megszűnés zárója** (`mem0_backend_store.py`) — UPDATE esetén a régi sor `valid_until` = megfigyelés dátuma: a struktúra most rögzíti, MIKOR ért véget az állapot.
5. **Tiltott DELETE → supersession-fallback** — eddig a blokkolt törlés SEMMIT sem tárolt ("abbyahagytam a kavét" csendben jelenlegi maradt); most explicit supersession-t ír.
6. **Temporális rangsor a KANONIKUS keresési útban** (`mem0_backend_store.search`) — query-intent szerinti tier; top_k=5 + rb3 VALENTOZATLAN.
7. **Render-jelzők MINDKÉT másolatban** (`app/voicemem_bridge.py` + `app/web_server.py`) — past/future/uncertain jelzők + `valid_from`/`valid_until` kulcsok a webes payload-ban, ≤25 karakter/találat a változatlan 1200-as kontextus-kupakon belül.
8. **PHASE 9 konszolidációs hook** — `memory_history(memory_id)`: a teljes supersession-lánc oldest→current olvasása.
9. **Talált és javított LÉTEZŐ hiba** — a ConflictResolver explicit-NONE ága nem alkalmazta az uuid-mappinget: a visszahelyesítés-számlálás ("Nx confirmed") sosem működött indexelt id-kkel (a v0.6.3 óta env-gap-pinned OccurrenceExplicitNoneTests most először fut le és ZÖLD).
10. **`docs/MEMORY_SEMANTICS.md`** (199 sor) — a teljes szemantikai szerződés: a megfigyelési primitív 4 idő-jelentése (megfigyelés ideje / sormódosítás ideje / érvényesség / valutasság), stance-szókincs, A–G osztályok, retrieval-szemantika, confidence-határ, backward-kompatibilitás, v0.11-jelöltek.
11. **`scripts/release_tree.py`** — egg-info path-aware ignore (a v0.9.2 utáni fingerprint-eltérés valódi oka).
12. **`scripts/run_release_gate.py` építési lánc** — V0100 self-check markerek + must-ship fájlblokk a ZIP-buildben.

## MEASURED (mért, nem becsült)

- Osztályozás: **55.8 µs/tény**; rangsor-kiegészítés: **2.3 µs/találat** (<0.002% a vektoros kereséshez képest).
- **0 LLM-hívás, 0 prompt-változás** — a v0.9.2 promptredukció és a latencia-költségvetés változatlan.
- PHASE 0 forenzikus mérés: a fájlútvonal `time_start` időkarakterlánca → `_as_date` elutasítja → wall-clock fallback (a javítás előtt mérve).

## TESTED

- **37/37** unit (`test_temporal_semantics.py`): A–G osztályok, quote-rescue, tier-tábla, **legacy rendezés byte-identikussága**, row-status deriválás, query-intent HU+EN, render-jelzők, payload-kulcsok.
- **39/39** integration (`test_temporal_memory.py`, VALÓDI E5 + mem0/qdrant lánc, csak az LLM-döntések mock-olva): A→B→A→B láncok, kereszt-nyelvű supersession (HU tény, EN megszűnés), megfigyési idő / replay-jelenségek, trait-future (a future sosem olvad be / nem fordít currentet).
- **Teljes gate (PHASE 12): GREEN** — 1350 teszt (v0.9.2: 1253, +76 új + a felgyógyult memory-safety kategóriák), 0 regresszió, **8 pinned env-gap** (3 Silero-súly, 1 manifest, 3 bridge-degraded, 1 v0.7.0-zip — mind dokumentált sandbox-osztály, a célgépen zöld), deep validáció PASS.
- A gate első futásának 2 "regressziója" KÖRNYEZETI volt (Qwen-tokenizer + release-zipek elvesztek) — eszköz-visszaállítással gyógyítva, nulla kódváltoztatással, a gate-bázis gyengítése NÉLKÜL.

## VERIFIED

- A build önellenőrzése: VERSION == PAGE_VERSION, saját CHANGELOG-bejegyzés a valós gate-számokkal, V0100 markerek + a 4 must-ship fájl a ZIP-ben, minden korábbi verzió kumulatív markerei.
- BUILD_INFO.json a ZIP-ben: version 0.10.0, gate GREEN, ujjlenyomat-kötött rekord.
- Letöltőoldal-kártya: "VoiceMemAgent v0.10.0 LEGÚJABB STABIL" a gate-adatokkal; nulla konzol/page error; nincs vízszintes túlcsordulás 390px-en (body 390 = viewport 390).
- A kiszolgált ZIP bájt-azonos mindkét útvonalon (`/releases/…` és gyökér): `472fb043…`.
- RELEASE_INDEX feje: 0.10.0; BUILD_HISTORY attempt feljegyezve; CHANGELOG a valós (nem előreírt) gate-számokkal.

## RELEASED

- `releases/VoiceMemAgent_v0.10.0.zip` + `.sha256` — **SHA256 `472FB043ECFBAC43A5487B91C60F81889527F803601B1E3C73D2A816A2220E67`**, 2653.4 KB, 357 fájl, 1 .bat CRLF.
- Staging: `public/` gyökér + `public/releases/` (mindkét letöltési link 200, bájt-azonos).
- Helyreállítási csomag: `VoiceMem_temporal_v010_recovery.zip` (RECOVERY.md + identity.json + evidence/ + SHA256SUMS.txt).
- Visszagörgetés: a v0.9.2 ZIP megmaradt (`public/VoiceMemAgent_v0.9.2.zip`, SHA `3A9CAAF4…`) — a v0.10 metaadat ADDITÍV, a v0.9.2 adat olvasható marad.

## OPEN (operátori teendők)

1. **GitHub-tükör szinkron (PHASE 14) — PAT ismét hiányzik** (`/home/z/.github_sync` elveszett, a dokumentált sandbox-állapotvesztési osztály). Minden bemenet stagingelve; a `scripts/sync_github_mirror.sh` additív + idempotens, a PAT újracsatolása után azonnal futtatható. (A tükör jelenleg a Task A utáni állapotban áll: HEAD `6775208`, <0.8-as zip-ek törölve.)
2. **Célgépi validáció** (Windows 11 + RTX 5070): a 8 pinned env-gap teszt ott zöld (a súlyok operátori elhelyezésével).
3. v0.11-jelöltek dokumentálva a `MEMORY_SEMANTICS.md`-ben (tranzitív lánc-lekérdezés, fact-oldali confidence a rangsorban, időzóna-tudatosság) — a v0.10 szándékosan NEM nyúl hozzájuk.

## A 15 kérdés utóélete (PHASE 0-C → v0.10.0)

A PHASE 0 "lehetetlen a jelenlegi modellel" listája (Q15) minden eleme kezelést kapott: jövő-érvényesség (stance=future + valid_from), érvényességi intervallumok ("januárban kedvelte" strukturált), fact-oldali stance/bizonytalanság (determinisztikus osztályozás + sosem ír felül megerősítettet), megfigyési idő ≠ írási idő a termelési úton (ISO horgony), temporális-szándék-tudatos rangsor (query-intent tier). A "csak látszólag működik" lista (Q14) gyógyítva: az eseményidő-lánc valódi ISO-t kapott; a valutasság immár eseményidő-tudatos rendezést kap (a replayHatár a trait-oldalon régóta fennáll, a fact-oldali last-write-wins a dokumentált határ marad).
