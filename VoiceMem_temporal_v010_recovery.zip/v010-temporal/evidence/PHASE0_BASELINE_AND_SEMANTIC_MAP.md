# VoiceMEM v0.10 — PHASE 0: Baseline & Semantic Map
*(recorded BEFORE any production change; read-only forensic evidence)*

## 0-A. Baseline identity (FACT, verified 2026-09-15)

| Item | Value | Evidence |
|---|---|---|
| my-project git HEAD | `005cad9` (+ pre-existing mode-drift on `tool-results/voicemem-src`, documented class) | `git log` |
| VERSION | `0.9.2` | `voicemem-agent/VERSION` |
| Release ZIP | `VoiceMemAgent_v0.9.2.zip`, SHA256 `3a9caaf44fbfae6fce8449e781e42a6007434d9c062c37270c5d8b566dacbf05` | sha256sum |
| Recovery pkg | `VoiceMem_runtimeopt_v092_recovery.zip`, SHA256 `f8052ecb67451be38dfddfc428ff3ec6f18976a6f8865f0051182c18a168487e` | sha256sum |
| Gate record | GREEN, 1253 tests, 0 regressions, fingerprint `a74af6c5…`, 16 pinned env failures, deep validation PASS (embedding, memory, memory-semantics, release, runtime-deps) | `releases/gate_record.json` |
| Tree vs gated tree | **328/328 shipped files byte-identical to the v0.9.2 ZIP**; tree fingerprint differs ONLY by `vendor/voicemem/voicemem.egg-info/*` (5 pip-editable metadata files, regenerated post-gate, NOT shipped). Latent `release_tree.py` ignore bug proven: `*.egg-info` fnmatch does not match a directory's contents — to be fixed in v0.10. | per-file sha256 compare |

## 0-B/C. Semantic map of the current system (evidence: file:line)

**Storage of record**
- Facts: mem0 → local qdrant (`<space>/vectors/`), payload metadata keys incl. `turn_id, voice_id, time_start, source, speaker_entity_map, affect, supersedes?, superseded_by?, superseded_at?, occurrence_count?, last_observed_at?` + JSON mirror in space-sqlite `kv[leftbrain_store]`.
- Traits: `rb_traits(id,…,first_seen,last_seen,occurrence_count,stance,supersedes,superseded_by,superseded_at)` + `rb_evidence`.
- Cognitive graph sqlite: entities/entity_edges/memories wrapper (+V2 tags).

**The 15 questions**

1. **Current state =** absence of `superseded_by` (facts: `mem0_backend_store.py:613`, sort `:628-631` current-first; traits: active-row filter `traits_store.py:386-387`, priority ×0.75 for superseded `rightbrain/brain.py:305-307`). Currency is STRUCTURAL (chain position), not a flag — good.
2. **Historical state =** rows with `superseded_by` (facts/traits) — retained, retrievable, ranked after current, rendered "superseded" (`voicemem_bridge.py:116-117`, `retrieval_contract.py:231-232`). Trait history frozen (occurrence/confidence not touched post-flip).
3. **Observation time =** facts: `metadata.time_start` — but in the production app path this is a **time-of-day string** (`orchestrator.py:1044` `ts = observed_at or time.strftime("%H:%M:%S")`, `:1174` `time_stamp={"begin": ts…}`); the extraction "Observation Date" anchor is the same string (`voice_input.py:534-535`) → **event-time chain degraded end-to-end in production** (works only when `observed_at` passed — scripts/tests). `last_observed_at` = wall clock at re-confirmation. Traits: `rb_evidence.created_at` = ev.at (observed_at-or-now).
4. **Last modification time =** mem0 top-level `updated_at` (internal); traits `updated_at` column. NOT structurally distinguished from observation time on facts — a metadata merge (supersede marking / occurrence count) leaves no separate trace vs a new observation.
5. **Validity =** nothing. No `valid_from`/`valid_until` anywhere. Future-dated facts are treated as current AND `recency_bonus` counts future dates as freshest (`local_memory_store.py:213-233`). Archived rows: mem0 `expiration_date` (hidden from search).
6. **Supersession =** facts: append-new-row + `supersedes`→`superseded_by`/`superseded_at` (VM-LOCAL-008, `mem0_backend_store.py:294-386`; refuses blind/no-owner updates). Traits: full deterministic gate (bands 0.90/0.88 presuppositional, pos↔neg flip + topic overlap + stale-replay guard, `traits_store.py:359-475`). Trigger: LLM ConflictResolver UPDATE decision + `_SINGLE_VALUED_RULE`. Chain is never walked transitively (no history query).
7. **Uncertainty =** traits only: `stance="uncertain"` (lexical cues, HU+EN, `stance.py:82-91`) → SEPARATE, never merges/flips. Facts: **no uncertainty concept** — "may not like X" is plain text and can UPDATE (overwrite) a confirmed current fact, unguarded.
8. **Provenance =** `turn_id`/`voice_id`/`source`/`speaker_entity_map` (facts, `voice_input.py:699-711`) + trait evidence (quote/emotion/cause/at) — **transport-only: no consumer reads them**; app never passes `session_id`/`observed_at` (`web_server.py:662`, `voicemem_bridge.py:628-629`).
9. **Past/present/future:** past = superseded rows + trait stance "past" (works); present = default (works); **future = impossible** (no field; future-dated fact is current + recency-freshest — worst case it outranks everything as "present").
10. **Safe supersession:** YES both layers (non-destructive, explicit links, delete default-deny VM-LOCAL-005/007, graph cascade VM-LOCAL-009). CAVEAT: out-of-order/stale replay guard exists ONLY on traits; the fact path is last-write-wins with no time guard.
11. **Historical retrievable without outranking current:** YES both layers (current-first sorts, ×0.75 trait priority, render markers) — v0.9.0 semantics suite evidence.
12. **"used to like" / "likes now" / "will like" / "might like":** traits: past→SEPARATE ✓, uncertain→SEPARATE ✓, now=default ✓, future=**misclassifies** (no future cues — future statements fall through to pos/neutral). facts: only text-level; stance classifier never runs on facts; conflict resolver decides by topic/value rules only.
13. **Already works (with tests):** non-destructive supersession + current-first ranking (facts/traits/heartnotes; v0.9.0 suite 87/87); trait stance incl. HU cues + flip gates + frozen history; occurrence counting (render-only); query-side relative-date expansion + date-overlap bonuses (`time_expand.py`, `local_memory_store.py:108-204`); trait stale-replay guard (when timestamps parseable).
14. **Only appears to work (implementation details):** observation time (time-of-day string; `_as_date` rejects it → wall-clock fallback); currency by WRITE ORDER not event time (replayed old observation flips currency on facts); trait `last_seen` = last AGREEING observation (frozen rows keep old value by design); TTL schema exists but no production writer sets it (no-op); `memories.memory_type` always 'fact'.
15. **Impossible with current model:** future validity (no field; recency rewards it); validity intervals ("liked in January, not now" is text-only); fact-side stance/uncertainty (a hedged or past-tense fact can overwrite a confirmed current one — no guard); distinguishing observation time from write time in production; temporal-intent-aware ranking (query asks "before" → historical does not get preference).

**Confidence (PHASE 5 pre-audit):** trait confidence = asymptotic reinforcement (c' = c + (1−c)·0.30, start 0.9) — confirmation strength, NOT probability (documented in `retrieval_contract.py:30-41`); fact annotator confidence default 0.9; NOT used in fact ranking at all (only base cosine + bonuses). Effective trait confidence decays (90d grace / 180d halflife). Superseded rows freeze confidence/occurrence — post-flip reinforcement impossible (correct).

**Dead/broken noted (pre-existing, not v0.10 scope unless free):** `last_observed_session`, `last_observed_event_time`, left-brain `superseded_at` (written, never read), JSON-mirror `updated_at` (always None), `evidence_turn_ids` (never written), `search_with_graph`/`search_combined` (broken, dead), `rb_directive` (deliberately unconsumed).

## Design decision (PHASE 1, justified by the above)

**No Observation Store.** All required semantics fit as ADDITIVE metadata on existing rows:
- fact rows: `stance` (pos/neg/past/qualified/uncertain/future/""), `valid_from`, `valid_until`, real `observed_at`;
- status DERIVED structurally (no enum column): `current` = not superseded ∧ interval open/contains today; `historical` = superseded ∨ `valid_until` < today ∨ stance=past; `future` = `valid_from` > today ∨ stance=future; `uncertain` = stance facet.
- Classification: deterministic (regex) post-extraction via a new `leftbrain/temporal.py` reusing `rightbrain/stance.py` + new future/negation/interval cues — **zero LLM prompt changes**, preserving the v0.9.2 prompt reduction and latency budget.
- Event-time anchor fix: `orchestrator.py` ts fallback → real ISO datetime (single-line class change; legacy time-of-day strings keep the old fallback behavior — backward compatible).
- Ranking: canonical `mem0_backend_store.search` sort key extended with query temporal intent; identical behavior for legacy rows / current-intent queries.
- Consumers: provenance suffix markers (past/future/uncertain) in BOTH render copies (bridge + web_server), payload keys additive.
- No sqlite migration (schemaless metadata + existing trait columns); traits gain only the "future" stance value.

**Domain-neutral memory primitive (v0.10, minimal):** every observation row = {subject, predicate/claim, value-in-text, stance(polarity), temporal validity [valid_from, valid_until], observed_at (event time), first_seen/last_seen, occurrence_count, confidence (confirmation strength), provenance (turn_id/source/speaker), supersession (supersedes/superseded_by/superseded_at)}. Observation time ≠ row modification time (new-row created_at vs supersede-marking wall clock); validity ≠ currency (interval vs chain); uncertainty = stance facet, never a ranking promotion.
