# VoiceMem v0.10.7 Recovery — TTS N1/N2 DETERMINISTIC FIX

Identity
- Product: VoiceMemAgent v0.10.7 (releases/VoiceMemAgent_v0.10.7.zip)
- SHA256: C5A6C4E30056B0EE3A636CD7CDC6315155AB1334F04406BA57ACBA3A7B684DC3
- Gate: GREEN, 1537 tests, 0 regressions, 2 pinned sandbox env-gap,
  30 skipped, deep PASS [embedding, memory-semantics, release,
  runtime-deps, vad]; fingerprint
  7a6b5525d7c3a12194b498ac8ee90148ac413c4c0ec080b10774f370da53d8ba
  (record: releases/gate_record.json)
- Scope: EXACTLY ONE production change — app/text_utils.py — fixing the
  two deterministic defect classes identified by the 2026-09-20
  consolidated audit (audit/VoiceMEM_tts_N1_N2_forensic/REPORT.md).
  Everything else is release bookkeeping and the +16-test regression
  matrix.

## A. MI VÁLTOZOTT (what changed)

1. **N1 — Hungarian vowel-harmony guard on budget absorption**: a
   signal-free budget candidate with ≥2 vowels all in one Hungarian
   harmony class (back a/á/o/ó/u/ú or front e/é/i/í/ö/ő/ü/ű) is a
   Hungarian word and is never absorbed into an English span
   ("A 2026-os meeting fontos..." no longer reads "fontos" in English).
   Applies to BOTH the trailing budget and the leading absorption
   (mirror). Single-vowel tokens are exempt ("up", "next" keep the
   historical absorption — the protected English phrase bodies
   "touch base"/"catch up"/"see you later" are disharmonic or exempt
   and route exactly as before).
2. **N2 — "holnap" table entry**: joined HU_PLAIN_WORDS (the F-O
   accent-free function-word category — the class of "mikor"/"hol").
   "Holnap touch base." now detects a Hungarian host by score.
3. **N2 — tie-break refinement**: on a no-diacritic tie, unquoted
   Hungarian host-context function-word evidence beats the EN side's
   article counting ("Holnap lesz a meeting a csapattal." → HU).
   Tokens inside set-off regions (quotes/parentheses — foreign
   material under discussion, e.g. 'The word "szia" means hello
   here.') do NOT vote on the host; the check is lazy (tie path only).

Two documented false-positive pins were CONSCIOUSLY corrected (both
were the N1 class itself): "Nyisd ki a chat ablakot." → one Hungarian
span; "Holnap see you later." → hu 'Holnap ' + en 'see you later.'.

Tests: +16 (tests/unit/test_tts_n1_n2_matrix.py — the N1/N2 matrix
per the operator's test-matrix specification) with 2 consciously
corrected pins in test_tts_code_switching.py; total gate 1537/0-reg.

## B. CÉLGÉPI VISELKEDÉS-PLAYBOOK (if the target misbehaves)

- Hungarian words no longer ride into English spans after
  ee/ou/ck-class English loans, and accent-free Hungarian sentences
  with function words no longer flip to the English voice. This is the
  intended change — compare against v0.10.6 to confirm.
- Any OTHER behavioural difference → NOT this release by construction
  (the only production delta is the three-part text_utils fix; verify
  via evidence/code.diff). Capture the failing sentence + the
  web-server.log chunk trail, then roll back (D).
- The protections to re-check on target: "touch base"/"catch up"/
  "see you later"/"cut to the chase"/"hit the ground running"/"burn
  the midnight oil" still route English; hazai/auto/tea/euro/projekt/
  only/really/city/money/many stay host; quoted English inside HU and
  quoted HU inside EN both still split correctly.
- Known residuals (documented, out of scope): the bare article "a"
  riding after a loan ("meeting a csapattal" → en 'meeting a');
  accent-free disharmonic Hungarian content words (fiú/kavics-class);
  sentences with no Hungarian function words at all.
- If in doubt: fall back to v0.10.6 (D) and report the sentence to the
  forensic pipeline (audit/VoiceMEM_tts_N1_N2_forensic).

## C. CÉLGÉPI ELLENŐRZÉS (target-side verification)

1. `sha256sum VoiceMemAgent_v0.10.7.zip` == the sidecar value above.
2. The operator cases: "A 2026-os meeting fontos lesz mindenkinnek."
   (all-Hungarian voice, "meeting" included — single-word loan policy)
   and "Holnap lesz a meeting a csapattal." (Hungarian host voice).
3. Regression spot-check: "Holnap touch base veled lesz." (hu 'Holnap '
   + en 'touch base' + hu ' veled lesz.'), the pure HU/EN sentences,
   and the quoted-region cases.

## D. VISSZAÁLLÍTÁS (rollback)

Replace the v0.10.7 deployment with the v0.10.6 package
(`VoiceMemAgent_v0.10.6.zip`, SHA256
A310E679F5F6C1A3043F0DB736607DAB3691410B80CDBFA8CEB00E9864046CCC)
and restart via START.bat. No data migration is involved (no
persistence, schema or config-semantics change).

## E. EVIDENCE IN THIS PACKAGE

- `evidence/code.diff` — the release-to-release production delta
  (v0.10.6 release commit → this tree): the text_utils fix, the new
  matrix, the two corrected pins, version metadata.
- `evidence/gate_record.json` — the GREEN gate record
  (fingerprint-bound to the exact released tree).
- `evidence/changelog_head.txt` — the stamped 0.10.7 CHANGELOG entry.
- `identity.json` — machine-readable identity.
- `mirrorsync/` — the mirror synchronisation evidence.
- Full forensic report: audit/VoiceMEM_tts_N1_N2_forensic/REPORT.md
  in the repository (also mirrored under source/).
