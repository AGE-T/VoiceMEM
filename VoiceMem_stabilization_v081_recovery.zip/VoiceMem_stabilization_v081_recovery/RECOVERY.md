# VoiceMem v0.8.1 — Stabilization Release Recovery Package

**Mire való ez a csomag?** A v0.8.1 stabilizációs kiadás (post-implementation
audit P1-javítások + brit-angol szövegegységesítés) önállóan, a sandbox
working-tree-től függetlenül visszaállítható legyen. Semmi sem szükséges a
sandbozból — ez a ZIP tartalmaz minden bizonyítékot és visszaállítási utat.

## Mit javít a v0.8.1 (a v0.8.0-hoz képest)

1. **P1-1 — PAGE_VERSION**: a v0.8.0 a `web/voicemem.html`-ben
   `PAGE_VERSION='0.7.2'`-t csomagolta VERSION=0.8.0 mellett (hamis
   "stale page" toast minden sessionben). Most: a VERSION fájl az egyetlen
   forrás; `scripts/sync_page_version.py` byte-szintű regenerálás;
   futásidejű injektálás (`_inject_page_version`) a kiszolgált oldalra.
2. **P1-2 — retrieval szerződés**: a v0.8.0-ban kiszámított trait-könyvelés
   (confidence / eff_confidence / occurrence_count / first_seen / last_seen)
   minden fogyasztónál eldobódott. Most: `app/retrieval_contract.py` —
   tipusos, egyetlen kanonikus szerződés; a web payload a teljes
   mezőkeszletet viszi; az LLM kontextus megfigyelés-dátumot + 
   megerősítés-számot kap (raw confidence float NINCS a promptban —
   megerősítés-erő, nem valószínűség); a CLI bridge ugyanazt rendereli.
   `rb_directive`: transzportban megmarad, dokumentáltan nem fogyasztott.
3. **P1-3 — kiadási kapu-sorrend**: a v0.8.0 a teljes gate-et a VERSION
   frissítés ELŐTT futtatta (a csomagolt fa sosem volt kapuzva). Most:
   `scripts/run_release_gate.py` fut a kiadandó pontos fán a
   verzio/CHANGELOG/page-verzió frissítés UTÁN; a build
   (`scripts/build_release_sandbox.py`) fingerprint-kötött GREEN rekord
   nélkül megtagadja a működést.
4. **Brit angol szövegek** (operátori kérés): enrolment / recognised /
   analysed / normalised / minimised söprés + `tests/unit/
   test_british_english.py` őrző teszt a négy látható felületen (I18N
   szótár, _SLOT_EN címkék, persona-prompt, retrieval render).

## Visszaállítás (bármely gépen)

**A. Termék visszaállítása (ajánlott):**
1. `VoiceMemAgent_v0.8.1.zip` (SHA-256: lásd evidence/ oldalcar) kicsomagolás
   tetszőleges mappába.
2. Ellenőrzés: `sha256sum VoiceMemAgent_v0.8.1.zip` == a `.sha256` fájlban.
3. `START.bat` — a bootstrap mindent felépít (venv, függőségek, modellek).

**B. Forrás visszaállítása (git):**
- sandbox repo: `git checkout <release-commit>` (lásd identity.json)
- tükör: `git clone https://github.com/AGE-T/VoiceMEM.git` — a `source/`
  mappa a teljes first-party forrásfa.

**C. Visszaállítás a v0.8.0-ra (rollback):**
1. `VoiceMemAgent_v0.8.0.zip` a tükör gyökeréből (SHA-256 ellenőrzéssel).
2. Forrás-oldal: `git revert` a v0.8.1 commit-láncra
   (identity.json: `git_commits`), vagy a v0.8.0 release commit checkout.
3. A v0.8.1 adatbázis-változásai visszafelé kompatibilisek: a trait
   bookkeeping oszlopok (first_seen/last_seen/occurrence_count) additívak —
   a v0.8.0 kód azokat ignorálja, nem törli. Nincs sémavisszaállítás.

## Tartalom

- `RECOVERY.md` — ez a fájl
- `identity.json` — verzió, commitok, SHA-256, gate számok
- `evidence/gate_record.json` — a GREEN gate rekord (1143 teszt,
  0 regresszió, 14 pin-elt sandbox környzeti rés), fingerprint-kötve
- `evidence/new_tests.txt` — az új viselkedés-tesztek fókuszált futása
- `evidence/code.diff` — a teljes termékforrás-diff (v0.8.0 → v0.8.1)
- `evidence/changed_files.txt` — a változott fájlok listája
- `evidence/VoiceMemAgent_v0.8.1.zip.sha256` — a kiadott ZIP hash-e
