# RECOVERY — VoiceMemAgent_v0.5.1_Task2Gate

**Artifact type:** GOLDEN RULE deliverable (TASK 2 rich-retrieval DESIGN GATE)
**Created:** 2026-09-10, session `web-7b05b5bc-1460-41f0-9ee3-aeaffd50714f`
**Repo state at measurement:** v0.5.1, head `cc4385910466e4ce2b8480f257d358c4314e052e`, vendor pin `e8384e0` (untouched).

## What this is

The TASK 2 design gate: the authoritative retrieval baseline (both paths
measured on the current state), the runtime call-graph trace, the API design
comparison, the recommended design, the result-model / rendering-boundary
proposal, the temporal/speaker/language audits, the production-path
consistency audit, the performance measurement, the test plan, and the single
gate decision. **Design-only: no implementation was performed in this phase**
(per the phase rules).

**The decision in one line:** PROCEED TO IMPLEMENTATION, scoped to Stage 1 —
an app-level `search_rich` composition helper + renderer `[observed_at]` date
prefix + the 15-test battery; no caller flips, no vendor changes, no default
changes. Flipping defaults or fixing the narrowing no-op is
BLOCKED — PREREQUISITE REQUIRED.

## The three headline measurements

1. **Path A ≡ Path B in hit quality today**: rank-1 13/14 on both; the slot
   filter is structurally a no-op (every memory auto-tagged into every base
   slot at ≥0.20 cosine; upsert never deletes spurious rows; confidence
   ignored) and entity narrowing unions back to the full corpus.
2. **The renderer drops even the date**: the app's two renderers emit bare
   `- text` lines; the vendor's proven renderer emits `- [date] text`.
3. **HU/EN temporal words are invisible** to the recognition layer
   (Chinese-only); temporal retrieval works purely by E5 vector similarity;
   the HU↔EN 4-way language matrix is fully intact (regression guard).

## Contents

```
VoiceMemAgent_v0.5.1_Task2Gate/
├── RECOVERY.md                  ← this file
├── TASK2_GATE.md                ← the gate (A–J + decision)
├── identity.json                ← machine-readable record
├── evidence/
│   ├── task2_retrieval_baseline.json   16-query × 2-path matrix, field audits,
│   │                                    speaker/temporal/renderer legs (106,969 B)
│   ├── task2_callgraph.json             runtime sys.setprofile call graphs + divergence
│   └── task2_performance.json           20-run mean/median/p95, simple vs rich
└── harness/
    ├── task2_retrieval_baseline.py      rerunnable measurement driver (mock LLM in-process)
    └── task2_callgraph_trace.py          rerunnable call-graph tracer
```

## Recovery anchors

- **Repo**: `/home/z/my-project` (Next.js gateway + `voicemem-agent/`); task
  work lives in `voicemem-agent/` (VERSION 0.5.1, VOICEMEM_PIN.json).
- **Evidence in-repo**: `voicemem-agent/docs/TASK2_GATE.md` +
  `voicemem-agent/docs/verification_evidence/task2_*.json` (same bytes as
  this package).
- **Harnesses in-repo**: `voicemem-agent/scripts/task2_*.py`.
- **Runtime env** (rebuild if the sandbox resets again):
  `uv venv .venv --python 3.12` in `voicemem-agent/`, then
  `uv pip install --python .venv/bin/python numpy pyyaml httpx openai mem0ai qdrant-client "sentence-transformers" --torch-backend cpu`,
  then download E5:
  `HF_HOME=models/hf python -c "from huggingface_hub import snapshot_download as s; s('intfloat/multilingual-e5-small', cache_dir='models/hf')"`.
- **Re-running the baseline**:
  `cd voicemem-agent && .venv/bin/python scripts/task2_retrieval_baseline.py`
  (deterministic corpus, in-process mock LLM; expect rank-1 13/14 both paths).
- **GitHub mirror**: https://github.com/AGE-T/VoiceMEM — this package is
  synced there by the standing policy (`scripts/sync_github_mirror.sh`).

## Integrity

| File | SHA-256 |
|---|---|
| `VoiceMemAgent_v0.5.1_Task2Gate.zip` | see the `.sha256` sidecar next to this ZIP |
| `evidence/task2_retrieval_baseline.json` | recorded in the ZIP manifest check below |
| `evidence/task2_callgraph.json` | see `evidence/SHA256SUMS.txt` |
| `evidence/task2_performance.json` | see `evidence/SHA256SUMS.txt` |
