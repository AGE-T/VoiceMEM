# VoiceMemAgent v0.6.1 — ASR DELIVERY-LAYER HOTFIX (GOLDEN RULE package)

FIELD REPORT: "start.bat lists asr: qwen; the NVIDIA model never downloads;
the UI shows ASR ERROR 'Unrecognized processing class'". Root cause: the
v0.6.0 release migrated the app layer to the modular parakeet engine but the
DELIVERY manifest (MODELS.lock.json + the downloader self-heal default + its
forced-snapshot 'asr' override) still listed the retired Qwen/Qwen3-ASR-0.6B,
so the idempotent bootstrap never downloaded parakeet. Sandbox-proven
(byte-exact error reproduction: docs/recovery/asr_hotfix_reproduction.txt).

## Rollback (exact)
1. `git checkout 123e09d -- voicemem-agent` (the v0.6.0/recovery state) — or
   extract the previous `VoiceMemAgent_v0.6.0.zip` over the install.
2. No data migration was performed, nothing to undo: v0.6.1 changed ONLY the
   delivery layer + diagnostic text (+ tests); vendor/ and memory/ were never
   touched (Memory Safety freeze held — memory_safety 15/15 green).

## Upgrade (the fix path for the field machine)
1. Extract `VoiceMemAgent_v0.6.1.zip` OVER the existing install (same as
   every previous upgrade).
2. Run `START.bat`. The bootstrap now sees the parakeet entry missing,
   downloads the 6 runtime files (~2.4 GB, pinned revision
   541d1f99c6b0c3cd0b11a95167540bb8edefd82b) into
   `models\asr\parakeet-tdt-0.6b-v3`, then verifies them (min_bytes floors).
3. The ASR chain goes green (engine: parakeet). If the weights are ever
   missing again, the load error now NAMES the repair:
   "run START.bat ... or scripts\download_models.ps1 --only asr".

## Verification steps (after the upgrade)
- START.bat console: the model set check lists `asr` via the PARAKEET dir
  (the retired qwen dir is never checked/downloaded again).
- Web UI: "UI v0.6.1 / backend v0.6.1"; the Pipeline/CHAIN ASR chip goes
  DONE after a spoken turn; the chat transcript carries the ASR line.
- `scripts\verify_m1.ps1`: "ASR config.json" check points at
  `models\asr\parakeet-tdt-0.6b-v3\config.json`.
- transformers floor: the bootstrap probe now enforces >= 5.6
  (ParakeetForTDT exists only from 5.6).

## What is in this package
- identity.json           — version, commits, package SHA256
- HOTFIX_REPORT.md        — root cause, fix list, gate numbers
- patches/v061_hotfix.diff— the complete delivery-layer diff (35 files)
- evidence/asr_hotfix_field_evidence.txt      (user upload, verbatim)
- evidence/asr_hotfix_reproduction.txt        (byte-exact sandbox repro)
- evidence/asr_hotfix_gate.txt                (full gate + build record)

NO SOURCE CHANGES to: vendor/ (frozen), app/asr_core.py, app/asr_nemotron.py,
the memory layer, the LLM/TTS/VAD legs. app/asr_parakeet.py gained ONLY an
explicit pre-check (actionable AsrError; the stage still fails — NO fallback).
