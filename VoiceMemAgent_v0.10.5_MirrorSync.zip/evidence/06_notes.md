# v0.10.5 MirrorSync — engineering notes (2026-09-18)

## Procedure source

The worklog entries Task ID v0102-mirror-sync (~line 3761) and
v0103-upstreamaudit "MIRROR:" (~line 3830) document the established
procedure; this package follows it: PAT re-supplied by the operator
(sandbox state restore wipes /home/z/.github_sync/ — third documented
occurrence), token check first, dry-run before the push, two-push
pattern (release push → evidence package → evidence push), fresh
anonymous-clone verification after each.

## Mirror state found before this sync

- `84501af` (14:22:30 UTC) — the last script-driven sync, source-only:
  the PAT was wiped by the sandbox state restore before the v0.10.5
  release artifacts existed (release built 16:41 UTC), so the v0.10.5
  zip + sidecar + regenerated README were never published.
- `cae034d` (18:43:53 UTC) — the OPERATOR's own manual web-UI upload
  ("Add files via upload") adding `VoiceMemAgent_v0.10.5_learning_prep.zip`
  (the architecture-prep input package) to the mirror root, no sidecar.
  Left untouched by this sync (additive policy; not part of the script's
  public/ sync set, so not listed in the README table).
- This sync pushed from `cae034d`, i.e. the operator's upload is an
  ancestor of the new history — nothing was rewritten.

## What PUSH 1 published (cae034d..384dd96)

- `VoiceMemAgent_v0.10.5.zip` + `.sha256` (2,876,103 B,
  SHA256 401814AC…C01C) — the TTS code-switching release
  (quoted-region span-level language routing).
- Regenerated `README.md` — v0.10.5 as latest stable.
- `source/` — 379 files, the full current first-party tree: the v0.10.5
  release state, the TTS phase-2 fix (unquoted phrase-run segmentation:
  `segment_language_spans`/`_iter_phrase_words` in `app/text_utils.py`),
  the three architecture documents (LEARNING_ENGINE_INTEGRATION_PLAN /
  BRITISH_ENGLISH_AND_LOCALISATION / NEXT_ARCHITECTURE_WORKPLAN), the
  Asian-script regression scanner (`tools/asian_script_scan.py` +
  baseline + gate test), and the two audit packages
  `audit/VoiceMEM_tts_codeswitch_v0105_unquoted/` and
  `audit/VoiceMEM_arch_prep_v0105/`.
- Working tree at sync time == git HEAD `e597cd3` (architecture
  preparation); only the runtime `tool-results/voicemem-src` submodule
  marker was dirty (excluded from the source sync by design).

## gen_readme gate-metadata refresh (same class as the v0.10.2 fix)

The script's README template still carried the v0.10.4 gate record
(1436 passed / 29 skipped / 7 pinned env-gap, fingerprint 70ba38d8…c51ff,
deep validation without vad). Replaced with the authoritative v0.10.5
record from `releases/RELEASE_INDEX.json`: 1478 passed / 0 regressions /
28 skipped (4 pinned env-gap), deep validation PASS (embedding, memory,
memory-semantics, release, runtime-deps, vad), fingerprint
634ac479ab3b230f28775ed16a4601cb324cbb49b0c38a94ec14d32907672c08.
The vendor-patch count line (24 files: 21 modified + 3 added vs the
e8384e08 pin) was verified still current — vendor/voicemem was last
touched by the v0.10.3 port commit 7eaac4b; v0.10.4, v0.10.5, the TTS
phase-2 fix and the architecture preparation are first-party only.

## Self-reference cleanup (transparency)

The PUSH 1 log was initially tee'd to
`voicemem-agent/audit/VoiceMEM_mirrorsync_v0105_workspace/push1_log.txt`
— inside the rsync-ed tree — so the sync copied a mid-write snapshot of
its own log to the mirror (`source/audit/VoiceMEM_mirrorsync_v0105_workspace/`).
This was a scratch location mistake, not a deliverable: the directory
was moved out of the synced tree right after the push
(now /home/z/mirrorsync-v0105-workspace/, outside every repository), and
this evidence push (PUSH 2) carries the rsync --delete removal of the
stale partial file, restoring exact source/ parity (0 content
differences). Evidence assembly for future syncs must stay outside
`voicemem-agent/`.

## Verification summary

Fresh anonymous clone (`/tmp/mirror-verify`, no token): byte-identity of
the v0.10.5 zip, additive policy PASS (51 → 53 root entries, operator's
manual upload retained), README v0.10.5 + correct gate numbers, phase-2
markers + docs + scanner + audit packages present in `source/`,
token hygiene 0 hits (tree + .git object store). Full detail in
evidence/04.
