# VoiceMemAgent v0.10.5 — MirrorSync evidence package

**What this is:** the golden-rule deliverable of the 2026-09-18 GitHub
mirror sync that published the **v0.10.5** release (the TTS
code-switching release: evidence-gated span-level language routing for
embedded foreign phrases) to https://github.com/AGE-T/VoiceMEM. It
documents that the mirror is a byte-identical, additive distribution of
the locally produced artifacts.

**Pre-sync state:** mirror HEAD `cae034d` — a source-only sync at
`84501af` (14:22 UTC) plus the operator's own manual web-UI upload of
`VoiceMemAgent_v0.10.5_learning_prep.zip` (18:43 UTC); **the v0.10.5
release artifacts were never mirrored** (the PAT had been wiped by the
sandbox state restore). **Post-sync state:** mirror HEAD `384dd96` —
`VoiceMemAgent_v0.10.5.zip` (SHA-256
`401814AC02E81E6258C9BF8C8E6D3656482769ED56AE789CCBDA8AA6BBE7C01C`,
2,876,103 bytes) + its `.sha256` sidecar, a regenerated README
("Latest stable release: v0.10.5" with the authoritative gate numbers —
1478/0-reg/28-skip/4-env-gap, fingerprint `634ac479…72c08`), and the
updated first-party source tree under `source/` (379 files: the v0.10.5
release + the TTS phase-2 fix + the architecture-prep deliverables —
three docs, the Asian-script regression scanner, both audit packages).

## Verify (independent, no trust needed)

```bash
git clone https://github.com/AGE-T/VoiceMEM.git vmirror
cd vmirror
sha256sum VoiceMemAgent_v0.10.5.zip
# expected:
#   401814ac02e81e6258c9bf8c8e6d3656482769ed56ae789ccbda8aa6bbe7c01c  VoiceMemAgent_v0.10.5.zip
grep -m1 "Latest stable release" README.md   # -> v0.10.5
grep -m1 "1478 passed"         README.md     # -> the v0.10.5 gate line
git log --oneline -1                          # -> 384dd96 sync: VoiceMemAgent_v0.10.5.zip, …
grep -c "segment_language_spans\|_iter_phrase_words" source/app/text_utils.py   # -> 4
ls source/docs/LEARNING_ENGINE_INTEGRATION_PLAN.md \
   source/docs/BRITISH_ENGLISH_AND_LOCALISATION.md \
   source/docs/NEXT_ARCHITECTURE_WORKPLAN.md \
   source/tools/asian_script_scan.py                                    # -> all present
```

Package contents: `identity.json`, `evidence/01…06` (token-permission
check — redacted; pre-push dry-run; push log; fresh-anonymous-clone
verification with VERDICT: PASS; mirror git log; engineering notes),
`SHA256SUMS` (self-verifying).

## Re-syncing / recovery

The standing policy (owner, 2026-09-10): every update (new release +
evidence packages) goes to the GitHub mirror automatically via
`scripts/sync_github_mirror.sh`:

```bash
# token at /home/z/.github_sync/AGE-T_VoiceMEM.token (chmod 600)
scripts/sync_github_mirror.sh --check                            # dry-run
VOICEMEM_SYNC_WORKDIR=/home/z/mirror-sync scripts/sync_github_mirror.sh
```

The stable-workdir mode lets a killed run resume by pushing the
already-built local commit; the sync is additive-only and idempotent;
`git push` is atomic, so the remote is never partial. This very package
is published by the follow-up push (the established two-push pattern);
the mirror HEAD after that push is recorded in the worklog and in the
download page's mirror badge.

## Rollback / provenance

The mirror only ever moves FORWARD additively; there is nothing to roll
back (no file is ever deleted by the sync at the root level). The
product rollback anchor for this release is the release ZIP's own
gate record (`releases/gate_record.json` inside the ZIP, fingerprint
`634ac479…`) plus `audit/VoiceMEM_tts_codeswitch_v0105_unquoted/` in the
mirrored `source/` tree.
