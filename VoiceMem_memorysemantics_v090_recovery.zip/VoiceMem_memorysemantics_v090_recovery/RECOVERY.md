# VoiceMem v0.9.0 — Memory Semantics Recovery Package

**Mire való ez a csomag?** A v0.9.0 memória-jelentéssemantikai kiadás
(trait-ellentmondás, supersession, érvényesség) önállóan, a sandbox
working-tree-től függetlenül visszaállítható legyen. Semmi sem szükséges a
sandboxból — ez a ZIP tartalmaz minden bizonyítékot és visszaállítási utat.

## Mit old meg a v0.9.0 (a v0.8.1-hez képest)

**A mért veszély (FACT, lokális E5-mérés):** az antipátia
("utálja" 0.9685), a múlt-idő ("régen szerette" 0.9821 / "used to like"
0.9865), a magyar határolt állítás ("kivéve télen" 0.9552) és a
visszaváltás ("megint szereti" 0.9521) MIND a 0.95-ös trait-merge küszöb
FELETT mérett — a v0.8.1 merge egy negált megfigyelést megerősítésként
volt képes beolvasztani a tagadott trait-be. A teljes mért mátrix:
`SEMANTIC_MATRIX.md` (ebben a csomagban) / `scripts/measure_semantic_matrix.py`.

**VM-LOCAL-015 (vendor patch):**

1. **stance.py** — determinisztikus (0 új LLM-hívás!) EN+HU cue-szkenner:
   `pos / neg / past / qualified / uncertain / ""` osztályok; a scan-sorrend
   `uncertain > qualified > past > neg > pos` (a bizonytalanság sosem válik
   kemény cserévé).
2. **Három explicit kimenet** (a csendes megerősítés tilalma): MERGE
   (egyező stance, 0.95 küszöb változatlan), SUPERSEDE (ellentétes pos/neg
   stance + mért sáv 0.90 / presuppozíciós 0.88 + téma-token átfedés +
   nem-stale-replay), SEPARATE (minden más — a határolt/múlt/bizonytalan
   megfigyelések önálló sorok, a feloldás elhalasztva).
3. **Fagyasztás**: a superseded sor occurrence_count-ja és confidence-e a
   flip pillanatában fagy — az ellentmondás SOSEM számít megerősítésnek.
4. **Lánc (append-only)**: S(pos) ← N(neg) ← R(pos…) — minden flip új sort
   nyit, a régi sor csak `superseded_by`/`superseded_at` jelölőt kap; a
   történelmi állapot visszakereshető, de sosem előz meg egy aktuális találatot.
5. **Stale-replay őrszem**: a régi felvétel újraindítása (eseményideje
   régebbi, mint a cél legfrissebb eseményideje) nem fordítja vissza az
   aktuális állapotot — a bizonyíték a lánc megfelelő TÖRTÉNELMI tagjára
   csatolódik (fagyasztva).
6. **Szerződés-bővítés**: `app/retrieval_contract.py` + a négy új kulcs
   (stance / supersedes / superseded_by / superseded_at); a prompt-jelölő
   `[... | superseded]` a tény-oldali szóhasználattal.

**Observation Store (Phase 14): NEM SZÜKSÉGES** — minden szemantikai
követelmény reprezentálható a meglévő modellben (indoklás:
`SEMANTIC_MATRIX.md` §5).

## Ismert korlátok (tudatosan, dokumentálva)

- A cue-szkenner **felületi jeleket** olvas — jelölő nélküli szemantikai
  ellentétet nem észlel (pl. a lexikonon kívüli antonimapárok);
- a magyar múlt-idő detektálás explicit határozószók + kettős-t/es végződések
  — agglutinatív szélsőségek kimaradhatnak (az egyt végződések SZÁNDÉKOSAN
  ki vannak zárva: jelen-idő 1. személyű alakokat zárnának ki);
- vegyes mondatok a scan-sorrend szerint osztályozódnak (pozíció-tudatos
  elemzés nincs — "régen szerettem, de már nem" → past → SEPARATE, sosem
  hamis megerősítés, sosem flip);
- időbélyeg nélküli visszajátszás fail-open a flipre (a stance-kapu a kemény
  biztonság; az élő pipeline minden kört observed_at-val ír);
- a múlt-állításokon BELÜLI poláris egyet neméség nincs diszkriminálva;
- a confidence-csökkentés NINCS implementálva (nincs mért szemantikai
  súlyozás — a feladat kifejezetten tiltja az önkényes matematikát);
- trait-archívum/TTL nincs (nincs interakció építésszerűen); a tény-oldali
  archívum-interakciók tesztekkel rögzítve (reaktiválás dokumentáltan nincs
  implementálva — `unarchive_memory` a kézi út).

## Visszaállítás (bármely gépen)

**A. Termék visszaállítása (ajánlott):**
1. `VoiceMemAgent_v0.9.0.zip` (SHA-256: lásd evidence/) kicsomagolás.
2. Ellenőrzés: `sha256sum VoiceMemAgent_v0.9.0.zip` == a `.sha256` fájl.
3. `START.bat` — a bootstrap mindent felépít.

**B. Forrás visszaállítása (git):**
- sandbox repo: `git checkout 92c8af6` (identity.json: release_git_head)
- tükör: `git clone https://github.com/AGE-T/VoiceMEM.git`

**C. Visszaállítás a v0.8.1-re (rollback):**
1. `VoiceMemAgent_v0.8.1.zip` a tükör gyökeréből (SHA-256 ellenőrzéssel).
2. Forrás-oldal: `git revert` a v0.9.0 commitra, vagy a v0.8.1 release
   commit (`9992829`) checkout.
3. **Adatbázis-visszafelé-kompatibilitás (fontos):** a v0.9.0 sémaváltozások
   (`stance` / `supersedes` / `superseded_by` / `superseded_at` oszlopok a
   `rb_traits` táblán) ADDITÍVAK. A v0.8.1 kód ezeket a sorokat ismeretlen
   oszlopként látja és figyelmen kívül hagyja — a v0.8.1-re rollbackelt kód
   a v0.9.0-val írt adatbázist hibátlanul olvassa (a régi mezők változatlanok).
   Nincs sémavisszaállítás. A supersession-lánc információvesztés nélkül
   megmarad (a v0.8.1 csak nem használja).

## Tartalom

- `RECOVERY.md` — ez a fájl
- `identity.json` — verzió, commitok, SHA-256, gate-számok
- `SEMANTIC_MATRIX.md` — a mért szemantikai mátrix + a teljes döntési modell
- `evidence/gate_record.json` — a GREEN gate rekord (1227 teszt,
  0 regresszió, 11 pin-elt sandbox környzeti hiba), fingerprint-kötve
- `evidence/VoiceMemAgent_v0.9.0.zip.sha256` — a kiadott ZIP ujjlenyomata
- `evidence/zip_verification.txt` — ZIP-ségtesség + bejegyzésszám + checksum-egyezés
- `evidence/changed_files.txt` — a v0.8.1 → v0.9.0 fájlváltozás-lista
- `evidence/code.diff` — a teljes forráskód-diff (app/vendor/web/scripts/tests/config/docs)
- `evidence/new_tests.txt` — az új tesztfájlok listája
