# WORKSPACE RECOVERY — VoiceMemAgent v0.6.0

## What happened
The sandbox workspace was restored from a snapshot that drops gitignored/untracked
runtime artifacts while preserving tracked file content (a documented incident
class in this project's history — see worklog entry for commit 0e4c7ec era notes).
Forensics on arrival proved:

- git HEAD = f730b70 (the v0.6.0 final-report commit), reflog clean, NO reset events
- ALL 53 "modified" files were mode-only (100644->100755) except .zscripts/dev.pid
- release ZIPs bit-identical to the committed blobs; SHA256 sidecars match
- 270/270 files of the GitHub mirror source/ tree byte-identical to the local tree
- LOST: .venv, all model weights, bin/piper, releases/*.zip (untracked),
  /tmp/llama proof instance, /home/z/.github_sync token

## What was rebuilt (NO source changes)
1. .venv — python3.12, torch 2.14.0+cpu, transformers 5.17.0, onnxruntime 1.30.0,
   numpy 2.5.3, soundfile, huggingface_hub, sentence-transformers, qdrant-client,
   mem0ai, openai, librosa, fastapi/uvicorn/websockets/httpx/PyYAML
   (package list: recovery_venv_packages.txt)
2. models: silero_vad.onnx, parakeet-tdt-0.6b-v3 (2.5 GB), multilingual-e5-small
   at the production HF_HOME cache path (models/hf snapshot 614241f), piper
   voices (hu anna + en lessac) — inventory: recovery_model_inventory.txt
3. bin/piper + shared libs + espeak-ng-data (rhasspy/piper 2023.11.14-2)
4. releases/*.zip restored byte-identical from public/ (git-proven copies)

## Verification (all green, see recovery_gate_summary.txt)
- targeted recovery tests 6/6 PASS — the recovered parakeet reproduces the
  recorded v0.6.0 transcript on the real Windows capture BYTE-IDENTICALLY
- full gate 966/0/26 — identical numbers to the v0.6.0 record
- browser E2E: full mic turn reproduced exactly ("ASR · mock · hu · 12.0s"),
  CHAIN live stage states, zero console errors
- Memory Safety freeze held: vendor/ untouched, test_memory_safety 15/15

## Rollback pointers
- source state: git checkout f730b70 (identical to now)
- v0.6.0 product: public/VoiceMemAgent_v0.6.0.zip (SHA 9C55D9E1...)
- v0.6.0 gate package: public/VoiceMemAgent_v0.6.0_ASRGate.zip (SHA 54274F8D...)
- to rebuild this runtime env from scratch: follow RECOVERY.md section above

## Not restorable in-sandbox (by design, not a defect)
- the production LLM GGUF (operator-placed ~19 GB, field machine)
- the GitHub push credential (token file outside the repo was wiped; push
  requires the operator to re-provision /home/z/.github_sync/AGE-T_VoiceMEM.token
  per the standing sync policy — never stored in the repo, never requested here)
