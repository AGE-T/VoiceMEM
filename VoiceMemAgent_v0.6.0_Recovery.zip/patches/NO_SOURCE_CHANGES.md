# Patches: NONE

The workspace-recovery touched ZERO tracked source files. The v0.6.0 source state
was proven intact on arrival (git HEAD f730b70, 270/270 mirror source/ files
byte-identical to the GitHub mirror @ 8b7e6fb, release ZIPs bit-identical with
SHA256 sidecars matching commit 43b88ef). The only workspace mutations were:

1. mode-bit normalization (100755 -> 100644) to the committed values — content untouched
2. untracked runtime artifacts rebuilt (venv, models, releases/ copies, piper binary)
3. .zscripts/dev.pid — runtime PID file of the dev server supervisor (auto-managed)

There is no patch to apply. If a future workspace shows the same regression,
the rebuild recipe is in RECOVERY.md.
