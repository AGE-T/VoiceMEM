# RECOVERY — VoiceMemAgent_v0.5.1_ForensicTrace

**Artifact type:** GOLDEN RULE deliverable (TASK 1 forensic trace + v0.5.1 release record)
**Created:** 2026-09-10, session `web-7b05b5bc-1460-41f0-9ee3-aeaffd50714f`

## What this is

The TASK 1 (ASR → LLM forensic trace) evidence package: the proof of the
EXACT break point in the voice chain, the smallest-correct-fix patch, the
post-fix trace matrix, and the v0.5.1 release identity.

**The finding in one line:** the CLI bridge's feed/commit adapter tables
referenced vendor API names that never existed on the pinned vendor —
every CLI voice turn ran with an empty memory context and replies were
never consolidated; fixed app-side (vm.search retrieval + ingest pair
commit + vendor env pin), verified end-to-end with a wiretap mock.

## Contents

```
VoiceMemAgent_v0.5.1_ForensicTrace/
├── RECOVERY.md                    ← this file
├── FORENSIC_REPORT.md             ← the full TASK 1 report
├── identity.json                  ← machine-readable record
└── evidence/
    ├── runA0_prefix_feed_broken.json / runA0_prefix_stderr.log
    │     the PRE-FIX proof: "No compatible VoiceMem feed API found",
    │     memory_context_chars: 0, vendor_requests: 0
    ├── runA1_prefix_mock_sse_bug.json  (harness-bug run, kept for honesty)
    ├── forensic_report_{full,partial,none}_normal.json   POST-FIX GREEN
    ├── forensic_report_full_thinking.json               the loud failure mode
    ├── forensic_wiretap_*.jsonl         every HTTP request that left the app
    ├── gate_summary.txt                939 tests / 0 failed / 25 skipped
    └── v0.5.1_source.patch             git show 92e7e3e (the complete fix)
```

## How to re-run the trace (any machine)

```bash
# sandbox / any machine with the repo + .venv:
.venv/bin/python scripts/forensic_trace_asr_llm.py --vendor-env full --llm-mode normal
# against the REAL llama-server (user machine, server running on 8080):
.venv/bin/python scripts/forensic_trace_asr_llm.py --vendor-env full --llm-mode normal --port 8080
```
Exit 0 = every stage S1–S7b proven. The JSON report names each stage with
latency and the wiretap log proves what went on the wire (model names!).

## Recovery anchors

- **Product release:** VoiceMemAgent_v0.5.1.zip ·
  SHA-256 `6E4CD79B8213CED3AE7EF198092ED2CD61E9AB87F6051B760831E114CE91D565`
- **Source commit:** `92e7e3e` (the complete fix + tests + version bump)
- **Patch:** `evidence/v0.5.1_source.patch` (applies on top of the v0.5.0
  tree: `git apply v0.5.1_source.patch`)
- **Rollback:** the patch touches only `app/voicemem_bridge.py` and
  `app/web_server.py` (plus additive tests/tools) — `git revert 92e7e3e`
  or apply the reverse patch restores v0.5.0 behaviour; no data was
  migrated, no vendor file changed, HU/EN behaviour untouched.
- **Mirror:** https://github.com/AGE-T/VoiceMEM (the standing sync policy
  pushes this release + evidence automatically).
