# TASK 1 — ASR → LLM Forensic Trace Report (v0.5.1)

**Session:** 2026-09-10, `web-7b05b5bc-1460-41f0-9ee3-aeaffd50714f`
**Scope:** the staged roadmap's TASK 1 — identify the EXACT break point in
`ASR transcript → pipeline handoff → prompt → LLM request → llama-server →
first response token`, implement the smallest correct fix, add regression
tests, re-run the complete trace.
**Constraint honored:** no memory-architecture change, no vendor
modification, no change to mic/VAD/ASR/Piper/storage/retrieval.

---

## 1. Method — how the proof was produced

- **Wiretap mock llama-server** (`tests/forensic_llm_mock.py`): a local
  OpenAI-compatible server that RECORDS every request (model, stream flag,
  message heads) to a JSONL log and can emulate `normal` / `thinking-only`
  / `empty` SSE streams plus the vendor's non-streaming shapes
  (keyword-routed, mirroring `tests/e2e_mock_llm.py`).
- **Forensic driver** (`scripts/forensic_trace_asr_llm.py`): drives the
  REAL application components (AgentConfig → VoiceMemBridge →
  teacher_persona → LlmClient.chat_stream) with a synthetic transcript
  against the mock, recording a concrete proof at every stage boundary:

| Stage | Boundary | Instrument |
|---|---|---|
| S1 | transcript received | driver input (mic→VAD→ASR is user-verified) |
| S1b | memory seeded (store_fact) | bridge store_fact + wiretap |
| S2 | VoiceMem turn (feed/retrieval) | bridge.process_turn + wiretap (vendor LLM calls) |
| S3 | prompt assembled | build_system_prompt + build_messages sizes |
| S4 | LLM request configuration | model + endpoint from config |
| S5 | HTTP request left the app | wiretap record (stream=true) |
| S6 | first response token received | first delta latency |
| S7 | reply complete | char count / explicit failure reason |
| S7b | turn consolidated (commit) | bridge.commit_reply status |

- **Static verification**: the vendor's public API compared method-by-method
  against the bridge's adapter tables (vendor `core.py` + `dir(VoiceMem)`).

## 2. The forensic finding (FACT)

### Pre-fix control run (full env, normal SSE)

```
S2 voicemem.process_turn  memory_context_chars: 0
stderr: "No compatible VoiceMem feed API found on the installed package"
vendor_requests: 0
```

**LAST CONFIRMED SUCCESS:** S3 — prompt assembled (the app-side streaming
leg itself was provable: S4–S7 green once the driver aimed at the mock).

**FIRST FAILED STAGE:** S2 — the transcript never entered VoiceMem.

**ROOT CAUSE (proven three ways):**

1. **Adapter-table API mismatch.** The bridge's tables target
   `feed_partial / feed / process_text / handle_text` (feed) and
   `add_message / remember / feed_partial` (commit). The pinned vendor
   (e8384e0) exposes **none of these** — its public API is
   `ingest / search / classify / reply / reply_stream / stream / flush /
   preprocess / transcribe / warmup`. Every CLI voice turn therefore ran
   with `memory_context = ""` and the assistant reply was **never
   consolidated** into long-term memory. The VoiceMem engine was
   disconnected from the CLI voice chain — while the **web path
   (`web_server.py` MemoryLayer: `vm.search` / `vm.ingest` /
   `vm.classify`) used the correct API all along**.
2. **Environment asymmetry (second defect).** The vendor reads
   `OPENAI_MODEL` (fallback `gpt-4o-mini`), `OPENAI_API_KEY` (fallback
   `None` → the OpenAI() **constructor raises** → swallowed → `""`), and —
   in `memory_repository_v2`/`query_slot_classifier` — `OPENAI_BASE_URL`
   with `None` fallback → the **OpenAI SDK's built-in cloud default** (an
   offline-policy violation). Only `start_agent.ps1:212-214` dot-sources
   `config/env.local.ps1`; a raw-shell CLI start left every vendor LLM leg
   silently dead.
3. **Cosmetic harness findings** (documented, not app defects): my first
   mock had a double-nested `delta` SSE shape (the app parser correctly
   rejected it); `async_facts=True` background ingest needs ~10 s (first
   seed settle); the vendor's embedded qdrant daemon threads SIGABRT the
   C++ runtime at interpreter teardown after the report is written (the
   driver exits via `os._exit`).

## 3. The fix (smallest correct, app-side only)

`app/voicemem_bridge.py` (+ `app/web_server.py`, 2 lines):

1. **`process_turn` → `_retrieve_user_turn`**: retrieval-first through the
   pinned vendor's REAL API — `vm.search(transcript)` → SearchResult.
2. **`_extract_memory_context` + `clean_rb_content`**: SearchResult
   rendered EXACTLY like the proven web path (top-5 facts + top-3
   right-brain notes, date/slot prefix + advisory suffix stripped,
   1200-char cap).
3. **`commit_reply`**: consolidates the turn as ONE
   `vm.ingest(user_text, agent_reply=reply, async_facts=True)` call — the
   pair the left-brain disambiguation and right-brain emotion attribution
   need (the web layer's proven pattern). The transcript is remembered
   per speaker in `_last_user_text`.
4. **`store_fact`** feeds through the new `("ingest", ...)` feed adapter.
5. **`pin_vendor_llm_env(config)`** (the LLM counterpart of
   `pin_e5_local_model`, same never-override-operator rule): exports
   `OPENAI_BASE_URL` / `OPENAI_API_KEY` (dummy) / `OPENAI_MODEL` /
   `OPENAI_CHAT_MODEL` from AgentConfig — called from
   `VoiceMemBridge.__init__` AND the web facade layer.

The legacy adapter tables remain as forward-compat fallbacks only.

## 4. Post-fix trace matrix (the re-run)

| Run | Vendor env | Mock mode | Result |
|---|---|---|---|
| A | full | normal | **ALL GREEN S1→S7b**: 118-char memory context (77 ms), 2-message prompt, `qwen3.6-35b-a3b` @ mock, 1 app stream request, first token 39.6 ms, 82-char reply, commit **committed**; 4 vendor requests, all `qwen3.6-35b-a3b` |
| B | **none** (raw shell) | normal | **ALL GREEN** — the env pin saves every vendor leg; same wiretap profile as A |
| C | partial (no MODEL) | normal | **ALL GREEN** — the pin fills the model; `gpt-4o-mini` never reaches the wire |
| D | full | thinking-only | S5 last OK, **S6 first failed — LOUD, with root cause**: "133 chars of reasoning but no visible answer … keep LLM_DISABLE_THINKING=1 or raise the max_tokens budget" (the v0.4.4/v0.4.9 field failure reproduced and DETECTED) |

## 5. Regression tests (18 new)

- `tests/unit/test_vendor_llm_env_pin.py` (4): pin-all-when-unset,
  never-override-operator, missing-subset, local-target/no-gpt-4o-mini.
- `tests/unit/test_voicemem_bridge_adapters.py` (11 + 1 guard):
  search/render/pair-commit/store_fact/degradation against a duck-typed
  pinned-vendor facade, plus the **drift guard** asserting the REAL
  VoiceMem still exposes `search`/`ingest` (fails BEFORE silent
  production degradation if the pin ever drifts).
- `tests/integration/test_llm_streaming_e2e.py` (3): the app streaming
  leg's **first E2E coverage** — first token + chunked reply + wiretap
  assertions; thinking-mode raises with the root-cause message;
  non-streaming vendor shapes parse.

## 6. Test gates

- Full gate (main sandbox venv, degraded): **939 tests, 0 failed,
  25 skipped** (unittest discover; pytest: 914/25/0).
- Existing affected suites green: bridge (main venv), llm/config/e5,
  pipeline_mock (46), voicemem_controlled (31).
- Known pre-existing artifact: the 3 degraded-mode bridge tests fail in
  the agent `.venv` (voicemem importable there → not degraded) — by
  design they belong to the no-vendor gate environment.

## 7. What remains unproven (honest limits)

- The legs beyond the sandbox: the REAL llama-server serving behaviour
  (model-name tolerance, thinking-channel semantics with the real
  Qwen3.6 GGUF) and real ASR remain user-machine territory. The shipped
  harness (`scripts/forensic_trace_asr_llm.py` with `LLAMA_SERVER_PORT`
  pointed at the real server) is the verification procedure.
- The heartnote cleanup path (`vendor rightbrain/brain.py:885`
  hardcoded `gpt-4o-mini`, triggers ≥10 heartnotes) is a KNOWN vendor
  blemish — out of TASK 1's scope (no vendor modification), documented
  for a future local-patch decision (candidate VM-LOCAL-007).

## 8. Verdict

**TASK 1 complete:** the exact break point was found and PROVEN (adapter
API mismatch + env fragility), fixed with the smallest app-side change,
regression-tested, and the complete trace re-run green end-to-end —
including the previously-unproven streaming leg.
