# VoiceMemAgent v0.8.0 — MEMÓRIA-RÉTEG JAVÍTÁSOK — helyreállítási csomag

Dátum: 2026-09-14 · Kiadás: VoiceMemAgent_v0.8.0.zip (SHA256 980E8E43485513CED2ED8BB9854163B52F550F28D11A48F7FC9EAEFF9FB53E09, 2 573 994 bájt, 332 fájl)

## Miért készült
Operátori utasítás: a külső auditok (v1.0, v0.6.3, két vendor-kutatási dokumentum)
eddig halasztott memória-tételeinek implementálása + F-O (P3) + a részleges
tételek (F-N, F-E, F-M) lezárása.

## Mit változtat (fájlok)
- vendor/voicemem/voicemem/rightbrain/traits_store.py — VM-LOCAL-013: additív
  first_seen/last_seen/occurrence_count oszlopok (idempotens migráció),
  merge-kor aszimptotikus confidence-megerősítés, olvasási csillapítás
- vendor/voicemem/voicemem/rightbrain/brain.py — VM-LOCAL-013: rangsor-tag
  priority = sim × (0.75 + 0.25 × eff_confidence); hit-metadata bővítés;
  (F-N: cleanup-hívás OPENAI_MODEL-env)
- vendor/voicemem/voicemem/orchestrator.py — VM-LOCAL-014: napi hidegmemória-
  archívum (kv-throttle 20h) a post-Ingest karbantartási szálra kötve;
  (F-N: inner-OS-hívás OPENAI_MODEL-env)
- vendor/voicemem/voicemem/rightbrain/store.py — VM-LOCAL-014: TTL olvasása
  (session 1 nap, short_term 14 nap; lejárt sorok a keresésben kihagyva)
- app/text_utils.py — F-O: ékezet nélküli magyar funkciószók + digráf-sűrűség
  + q-jelzés
- scripts/bootstrap.ps1 — F-E: pin-ellenőrzés GATING (mock mód kivétel)
- MODELS.lock.json — F-M: 4 'main' pin pontos commitra (E5 614241f6…,
  emotion2vec b318240b…, speechbrain 0f99f2d0…, silero-vad 394d7e6b…)
- VOICEMEM_PIN.json — VM-LOCAL-013/014 belejegyezve (15 helyi patch)
- CONTRACT.md — v0.8.0 kiegészítő (F-I dokumentáció a hármastárolásról)
- tests: test_traits_observation.py (13), test_archive_ttl_wiring.py (11),
  test_text_utils.py (+6 F-O eset)
- CHANGELOG.md [0.8.0] bejegyzés; VERSION/pyproject/yaml 0.8.0

## Visszagörgetés (rollback)
1. Állítsa vissza a fenti fájlokat a v0.7.2 kiadásból (a ZIP-ből másolja át
   őket a telepítési gyökérbe), vagy
2. Telepítse újra a VoiceMemAgent_v0.7.2.zip csomagot friss kicsomagolással.
A DB-migráció NEM-VISSZAFORDÍTHATATLAN elemszámú: az új oszlopok additívak;
a v0.7.2 kód a régi sémát várja, de az SQLite a plusz oszlopokat ismeretlenül
ignorálja — a régi kód az új adatbázissal működik (az oszlopok nem zavarják);
az új occurrence/adatok megmaradnak, de a v0.7.2 kód nem olvassa őket.

## Bizonyítékok (evidence/)
- code.diff — a vendor+app változások egységes diffje (403 sor)
- new_tests.txt — 50 teszt zöld (traits 13 + archive/TTL 11 + text_utils 26)
- gate_v072_baseline.txt / gate_v080_changes.txt — a teljes kapu hibakészlet-
  diffje a tisztán kicsomagolt v0.7.2 bázissal (egyetlen eltérés: környezeti
  silero/onnxruntime elem; nulla kód-regresszió)
- VoiceMemAgent_v0.8.0.zip.sha256 — a kiadás ujjlenyomata

## Kapcsolódó azonosítók
- A kiadás commit-je a fő repóban: l. identity.json (git_commits)
- Tükör: https://github.com/AGE-T/VoiceMEM (a szinkron a csomag készítése
  után fut le — l. a worklog bejegyzést)
