# VoiceMem v0.10.5 — memory-layer performance & stability audit (audit-only)

- **Task ID:** memperf-0105 · **Date:** 2026-09-18 · **Scope:** the memory layer only
  (read path, write path, streaming/speculative retrieval, concurrency, latency,
  quality, resource behaviour) on the v0.10.5 tree (HEAD `987dc3a`, mirror `f138325`).
- **Audit-only workstream:** zero production/runtime code modified. All
  measurement scripts live in `audit/VoiceMEM_memory_performance_v0105/scripts/`
  and run against throw-away memory roots under `/tmp` — the product
  `voicemem-agent/memory/` tree was never written by this audit.
- **Baseline policy honoured:** the current VoiceMem architecture and the
  upstream repository (pin `e8384e0`, 22 local patches in `VOICEMEM_PIN.json`)
  are the baseline. Every deviation proposed below is tied to a reproduced,
  measured problem. No optimisation was implemented in this phase.

---

## 1. Executive summary

The memory layer is **structurally sound and, in its steady state, fast**:

* The foreground **read path is cheap and stable**: full `Search()` P50 ≈ 98–105 ms
  at 118–500 stored facts (sandbox CPU, 2 shared cores), P95 ≈ 134–151 ms, max 151 ms;
  it scales sub-linearly to 4 000 facts (P50 177 ms, P95 221 ms). Rendering the
  prompt block costs 0.02 ms. The 2.6 s turn-side wait budget is never approached.
* The E5 query embed (P50 19 ms) and the Qdrant-local scan are not bottlenecks at
  personal-memory scale; the single shared E5 instance (module-level
  `lru_cache`) keeps RAM flat across facades.
* Retrieval quality on a 118-fact seeded persona: hit@5 = 86.4 % (19/22 scored
  probes), mean rank of hits 1.26; the superseded-value chain keeps the CURRENT
  value at rank 1 for current-value questions.
* The v0.10.2 BackgroundMemoryGate + cooperative-cancel design works exactly as
  intended **for the two big background legs** (extraction, conflict-resolution):
  measured user TTFT behind a cancelled streaming leg is 0.17–0.29 s vs 2.5–31.2 s
  behind an un-cancellable non-streaming leg (this audit, experiment A).

**The one proven, measured problem class** (the answer to the operator's special
question — "can any memory operation make the current conversational response
wait?"): **yes — the ingest chain's remaining NON-STREAMING LLM legs.** The chain
still contains legs that (a) never poll the cooperative-cancel event and
(b) use the SDK's blocking `create()`: reaction attribution (`_llm_json`,
every turn), inner-OS heartnote generation (10 s timeout), LLM slot tagging
(`_llm_json`), schema-summary refresh and AttributionManager summaries
(`_llm_text`), and right-brain cleanup (`run_cleanup`, 60 s timeout, spawned in
an *un-gated* daemon thread at every +50 heartnotes). When the user starts
speaking while one of these is in flight, their request queues behind it on the
single llama-server slot for the leg's full duration — reproduced here (A1:
user TTFT = the whole remaining leg, worst 31.2 s) and already observed in
production forensics (S8/T5: 10.07 s queue behind exactly this class;
30–42 s target outliers attributed to it).

Everything else examined — gate logic, queueing/coalescing, SQLite WAL usage,
per-call connections, the E5 singleton, the supersession/tier ranking, prompt
capping, facade caches — is defensible as-is and is classified KEEP.

---

## 2. Baseline

| Item | Value |
|---|---|
| Product tree | `voicemem-agent` @ v0.10.5, git HEAD `987dc3a` (main) |
| Memory engine | vendored controlled fork `vendor/voicemem`, pinned to upstream `xzf-thu/VoiceMem` commit `e8384e0` (tag v0.0.1, package 0.2.3), 22 `VM-LOCAL-*` patches (`VOICEMEM_PIN.json`) |
| Embedder | local `intfloat/multilingual-e5-small` (384-d, offline) — sole embedder, module-level shared singleton (`local_e5_embedder.shared_e5`) |
| Vector store | mem0 2.1.0 over embedded Qdrant-local (`qdrant-client` 1.19.1, path per memory_root, collection `voicemem`, payload-filtered per user) |
| Cognitive/right-brain stores | per-call-connection SQLite (WAL where set; `traits_store` timeout 30 s) |
| LLM (target) | Qwen3.6-35B-A3B IQ4_XS on local llama-server, `--parallel 1` (single slot) |
| LLM (sandbox measurement) | llama.cpp b10717, Qwen3-0.6B Q4_K_M stand-in, `-c 8192/12288`, KV q8_0, `--reasoning off` — absolute t/s do not transfer to the RTX 5070 target (documented S8 honesty rule); mechanism classes do |
| Prior evidence reused | S8 latency-correlation audit (2026-09-18): task-timing table, T5/T6 contention decomposition, s3/s5/s6/s7 probes; v0.9.1/v0.9.2 runtime audits; v0102 LLM-priority audit |
| Memory data at audit time | product `memory/` tree effectively empty (schema only) — the audit seeds its own realistic stores (below) |

## 3. Current architecture (as measured, not as redesigned)

```
web turn (aiohttp web_server.py, the production interface)
  ASR final ──> memory search (asyncio.to_thread) ‖ emotion prosody
                     vm.search(query, emotion)          [READ PATH, 0 LLM]
  wait ≤ 25 s cold / ~2.6 s steady (then continue WITHOUT memory)
  ──> teacher prompt (hits[:5] + rb_hits[:3], 1200-char cap)
  ──> LLM streaming ──> TTS chunks ──> reply done
  ──> memory_gate.submit(user_text, reply)             [WRITE PATH, gated]

BackgroundMemoryGate (one per web session)
  idle window (grace 2 s + quiet 6 s, VAD/LLM-delta fed)
  ──> one chain at a time: vm.ingest(text, agent_reply, wait=True)
        (async_facts=False → the gate sees real completion)
        legs: extraction* ‖ conflict-resolution* ‖ attribution(unc) ‖
              inner-OS(unc) ‖ slot tagging(unc) ‖ schema refresh(unc) ‖
              trait writes ‖ store writes ‖ cleanup(unc, +50 heartnotes)
        * = routed through bg_chat_create → cooperative-cancel aware
  arm() on first VAD frame/turn start → BG_CANCEL set →
        streaming legs abort between chunks (slot freed),
        non-streaming legs run to natural completion (slot held)
```

Key structural facts verified in code: the read path is **0-LLM** (no `Classify`
call — slots/entities are always empty from the app, so SearchCogGraph is a no-op
and Rank runs the full-library vector scan); the write path is entirely
**post-reply and idle-gated** on the web interface; the CLI bridge
(`app/pipeline.py` + `app/voicemem_bridge.py`) has **no gate at all** and runs the
same ingest chain via `async_facts=True` (an un-managed daemon thread).

## 4. Memory read path

Traced end-to-end (`Orchestrator.Search` → `LeftBrain.search` → `RightBrain.search ‖ LeftBrain.Rank`):

| Stage | What happens | Evidence |
|---|---|---|
| Query preprocessing | `expand_relative_dates` (regex, expands "next week"-type HU/EN/ISO phrases) + scene inference from text | 0.04 ms P50 (measured) |
| Embedding | one E5 query encode inside `Rank()` (plus one in traits search) | 19 ms P50 / 98 ms max (measured) |
| Routing (slot filter) | `SearchCogGraph` — **dead stage on the live path**: the app never passes slots and never calls `Classify` (an LLM call), so `slot_mem_ids` is always empty | `slot_filter_ms ≡ 0.0` in every measured timing dict |
| Entity narrowing | `_search_data_impl` — also idle (no entities from caller) | `entity_narrow_ms ≡ 0.0` |
| Temporal widening | `_widen_for_time_question` — fires only on duration/date questions, cheap metadata scan | code + probe timings |
| Vector retrieval + ranking | mem0→Qdrant-local scan (`fetch_k = top_k*3` candidates, or full-library when filter empty) then client-side: lexical/time bonuses, date-overlap bonuses, VM-LOCAL-011 recency bonus (≤0.10 additive), occurrence count, supersession tier sort (non-superseded first), `_dedupe_near` trigram near-duplicate collapse, heat recording | `rank_ms` P50 97.9 ms @118 facts → 177 ms @4 000 |
| Right brain (parallel) | anchor-plan retrieve (heartnotes by emotion/entity anchors) + traits semantic search (`search_scored`, E5-cosine, 0.88 floor for 384-d) + priority sort + source quotas | runs concurrently with Rank (`rb_ms == rank_ms` by construction) |
| Top-K | left hits[:5] + rb_hits[:3] (VOICEMEM_RB_TOPN), 1200-char prompt cap | `n_hits` mean 4.4 |
| Provenance | per-hit `[date | Nx confirmed | past/future/uncertain | superseded | by X]` suffix (web + CLI identical render) | measured render cost 0.02 ms |
| Left/right assembly | sequential in `Search()`; rb starts via a per-call `ThreadPoolExecutor(max_workers=1)` (new pool per search — negligible cost) | code |

**Observations.** (1) The "fallback" full-library scan is the *de facto*
architecture — the cognitive-graph routing exists but nothing feeds it. At
personal scale this is fine (sub-250 ms at 4 000 facts) and it avoids an LLM
round-trip per turn. (2) The search emits **no LLM calls**, so the read path can
never contend for the llama-server slot. (3) `ThreadPoolExecutor` per Search is
mild thread churn, not worth changing.

## 5. Memory write path

`vm.ingest(text, agent_reply, async_facts=False)` (the gated web shape) executes
`_finish_ingest`:

| Step | Mechanism | Cost class |
|---|---|---|
| Pair assembly | assistant reply stored verbatim as `role=assistant` row (excluded from retrieval unless asked) | 1 store write (~0.5 s measured: embed+upsert+history) |
| Fact extraction | merged single LLM call (schema+data, bg_chat_create → cancellable, `max_tokens` capped, truncation-warning) | LLM leg (dominant) |
| Conflict resolution | mem0-V1-style ADD/UPDATE/DELETE/NONE decision (bg_chat_create → cancellable; `VOICEMEM_RESOLVE_OMIT_NONE=1` default cuts the output size ~half) | LLM leg |
| Execution | ADD → `add_records_with_ids` (mem0.add, non-destructive); UPDATE → VM-LOCAL-008 supersession (new row + `superseded_by` metadata merge on old row; old text never rewritten); DELETE → opt-in gate (VM-LOCAL-005/007, default DENY) | store writes |
| Per-fact temporal classification | stance/valid_from/valid_until ride the same metadata dict (one write channel) | none (deterministic) |
| Slot tagging | LLM `_llm_tag_memories` per turn with facts (merged when enabled) + co-occurrence recording + graph-entity link | LLM leg (**not cancellable**) |
| Right brain | heartnote upsert + anchors + `_generate_inner_os` (LLM, **not cancellable**, 10 s) + trait `add` (MERGE/SUPERSEDE/SEPARATE gates, stance-aware) | store + 1 LLM leg |
| Reaction learning | `learn_from_reaction` → `_attribute_reaction` LLM (`_llm_json`, **not cancellable**, 15 s) → traits write (response_experience default off, VM-LOCAL-017) | LLM leg |
| Maintenance | `run_cleanup` (LLM, **not cancellable**, **60 s timeout**, at +50 heartnotes — spawned in its own daemon thread *outside the gate*); audio + cold-archive cleanup (disk-only, kv-throttled daily); schema refresh + AttributionManager at thresholds/session boundaries (`_llm_text`, not cancellable) | LLM legs (rare/thresholded) |

**Consistency model.** mem0 write → JSON mirror (kv table) → cognitive-graph rows
happen in sequence; a crash between them leaves the documented orphan-row class
(the delete path has the F-H cascade guard; the add path has none — additive,
benign, observable via the mirror diff). Qdrant-local is in-process
(file-locked); the gate serialises background writers to one, so the worst
concurrent mix is 1 background writer + 1 foreground reader — never observed to
corrupt in this audit's runs or in the test suite.

## 6. Streaming / speculative retrieval

* **When retrieval starts:** at turn END, from the final ASR transcript. Both
  interfaces start the memory task only after VAD closes the utterance
  (web: `mem_task` created after `asr finish`; CLI: `_retrieve_memory` after
  `_transcribe`).
* **Partial transcripts exist but are unused for retrieval.** The web path
  surfaces streaming-ASR partials (`partial_transcript` events, used for UI +
  diag). Nothing pre-embeds or pre-searches on them. The vendor `stream.py`
  streaming API (feed_partial) is legacy for this pinned package (proven by the
  TASK-1 forensic run — the bridge uses `search()`).
* **Can turn-end waiting be avoided?** Partially: a speculative search keyed on
  the last stable partial (or the speaker turn-start) would overlap with the
  ASR tail. However — the final transcript routinely differs from the tail
  partial (Hungarian agglutination, end-of-utterance repairs), and a mismatch
  means either discarding the speculation (wasted ~100 ms of CPU — cheap) or
  serving wrong-context memory (a quality risk). With the measured steady-state
  search cost of ~100 ms, the achievable saving is small; the current
  `asyncio.gather(search, emotion)` overlap already hides the emotion stage.
* **Prediction-mismatch handling:** n/a today (no speculation implemented); the
  bridge's `cancel_pending()` exists for barge-in cancellation of in-flight
  retrieval, and the web path drops a late search result beyond the wait budget
  (turn continues without memory — never stalls).

**Classification: INVESTIGATE (design option, not a defect).** The evidence for
*not* doing it: search is 100 ms P50; the failure mode of a bad speculation is a
wrongly-contextualised reply. The evidence for doing it would have to be a
measured TTFT budget violation on the target, which the S8 data does not show
(memory search was 159 ms in the S8 slow-turn anatomy; the latency lives in the
LLM, not in retrieval).

## 7. Concurrency

Verified mechanisms (all evidence-based):

* **Foreground vs background LLM:** the BackgroundMemoryGate (v0.9.2 defer +
  v0.10.2 cancel + v0.10.2 idle-window release) is correct and tested: starts
  deferred behind speech/turns/LLM deltas; in-flight *streaming* legs abort
  between chunks and the HTTP close frees the single llama-server slot
  (measured here: user TTFT 0.17–0.29 s behind a cancelled streaming leg).
* **The gap:** the chain's **non-streaming legs do not participate** (see §1/§12).
  Reproduced: user TTFT behind a non-streaming leg = the leg's full remaining
  wall time (2.5–31.2 s over three trials).
* **Foreground memory work:** the search runs in `asyncio.to_thread` — the
  event loop is never blocked by retrieval (the v0.4.13 unbounded-emotion-init
  class of bug is separately guarded by `_EMOTION_INIT_TIMEOUT_S`).
* **Thread/process contention:** the vendor chain is synchronous inside one
  gate worker thread; SQLite is per-call connections with WAL — no cross-thread
  connection sharing was found in the live stores. The shared E5 singleton is
  hit from both the search thread and (rarely) background writes: measured
  search inflation under a continuous 12-text background embed loop is +73 %
  (105→182 ms P50) — bounded, far under the wait budget, and smaller on a
  many-core target.
* **Single-resource contention:** one llama-server slot (by design, llama
  baseline untouched); the gate's one-chain-at-a-time policy prevents background
  self-contention; the queue is bounded by coalescing (exact duplicate pairs)
  and never drops pairs (re-queue on cancel).
* **Un-gated escapees:** `_finish_ingest` spawns three daemon threads per
  ingest (cleanup-check, audio-archive-check, cold-archive-check). Two are
  disk-only and kv-throttled (≤1×/day). `check_and_cleanup` is thresholded
  (+50 heartnotes) but when it fires it runs `run_cleanup` — an LLM leg with a
  **60 s timeout** that neither the gate's `is_processing` flag nor the
  cooperative cancel can reach.
* **CLI path:** no gate exists there at all — `commit_reply` runs the full
  chain in a fire-and-forget daemon thread immediately after the reply, and
  nothing ever sets `BG_CANCEL` on that path, so even the cancellable legs are
  not cancelled. The web interface is the production surface (all field
  reports); the CLI is the shipped fallback.

## 8. Latency measurements

All numbers from this audit's runs (`evidence/bench_search_populated.json`,
`bench_scaling.json`, `bench_ingest_chain.json`, `bench_concurrency*.json`);
sandbox = 2 shared CPU cores, no GPU — the *ratios* and mechanism classes
transfer to the target, absolute LLM-leg times do not (see §2).

**Read path (populated 118-fact root, 32 measured searches after warm-up):**

| Metric | P50 | P95 | P99 | max |
|---|---|---|---|---|
| query preprocessing (date expand + scene) | 0.04 ms | 0.07 ms | 0.08 ms | 0.08 ms |
| E5 query embedding (standalone) | 19.5 ms | 62.8 ms | 97.5 ms | 97.5 ms |
| **full `vm.search()` wall** | **100.9 ms** | **134.2 ms** | **135.0 ms** | **135.0 ms** |
| └ internal `rank_ms` | 97.9 | 125.9 | 131.4 | 131.4 |
| └ internal `rb_ms` (parallel with rank) | 97.9 | 129.6 | 131.4 | 131.4 |
| memory-context render (web shape) | 0.02 ms | 0.03 ms | 0.03 ms | 0.03 ms |

One-time costs: facade construction 0.22 s; E5 model load 18.6 s (first search
5.9 s incl. store warm-up) — the product already hides both behind the 25 s
cold-wait budget and the startup warm-up search.

**Scaling (5 canonical queries × 20 runs per size):**

| library size | search P50 | P95 | max |
|---|---|---|---|
| 500 facts | 97.5 ms | 150.7 ms | 150.7 ms |
| 1 000 | 103.9 ms | 138.8 ms | 138.8 ms |
| 2 000 | 158.9 ms | 207.9 ms | 207.9 ms |
| 4 000 | 177.0 ms | 220.5 ms | 220.5 ms |

Sub-linear, no cliff; ≈ 4.7 KB/fact Qdrant storage (18 MB at 4 000 facts).

**Write path (3 turns, real chain, 0.6B stand-in — leg inventory & store-side costs):**

| Leg / step | Measured |
|---|---|
| extraction (bg_chat_create, cancellable) | sandbox-degenerate: the ~9.1 K-token prompt at ~50 t/s prefill exceeds the leg's 60 s client timeout → timeout+retry observed; on the target this leg is the S8-measured dominant one (10.4 K prompt, single warm chain ≈ 111 s on the production model per the v0.9.2 E4 measurement) |
| conflict-resolution (cancellable) | not reached in this run (no extracted facts on the sandbox); structure verified from code + S8 task 200 (331-token leg, 14.4 s natural completion through a cancel) |
| reaction attribution `_llm_json` (not cancellable) | 1.30–1.47 s per call (3 calls) on the stand-in |
| store: single fact add (mem0 add: embed+upsert+history) | 124–1 072 ms, mean 464 ms (3 calls) |
| right-brain heartnote/trait writes | not triggered in this run (no emotion input / no extracted facts — conditional legs; verified from code + unit tests) |
| full gated chain (target, prior evidence) | one warm chain ≈ 111 s (v0.9.2 E4, production model); S8 field: 30–42 s TTFT outliers when the user speaks during it without cancellation |

**Concurrency experiments (the special investigation):**

| Experiment | user TTFT (slot shared with…) |
|---|---|
| baseline (idle slot) | 0.162–0.688 s (P50 0.168 s) |
| **A1: non-streaming leg in flight, BG_CANCEL set at +2 s** (the `_llm_json`/inner-OS/`run_cleanup` transport) | **2.52 / 2.95 / 31.23 s** — the user waits out the whole leg |
| **A2: streaming leg via bg_chat_create, BG_CANCEL set at +2 s** | **0.174–0.290 s** — slot freed at cancel, `BackgroundCancelledError` raised in the leg (62 chars partial discarded) |
| B: search under continuous background E5 embed loop | search P50 105→182 ms (+73 %) |

## 9. Resource measurements

| Item | Value |
|---|---|
| E5 model resident | ~740 MB (single shared instance; every facade reuses it) |
| Python search-process RSS (end) | 1 004.6 MB (E5 + torch + qdrant-local + interpreter) |
| Python ingest-process RSS (peak) | ~1 077 MB |
| llama-server RSS (0.6B stand-in, 8192 ctx q8 KV) | 1 258 MB (target model: 19 GB weights + KV, on-GPU) |
| Per-search CPU time | 120–190 ms (≈ wall × 1.2–1.4 — the parallel rb/rank threads) |
| Qdrant storage growth | ~4.7 KB/fact (vectors+payload): 636 KB @118 → 18 MB @4 000 |
| SQLite (cognitive+history+rb, 118-fact store) | 476 KB (1.9 MB @4 000) |
| Queue growth | bounded: coalescing + gate-worker drain; the failure-mode tests (gate stats `pending`/`requeued`) are covered by `test_background_memory_gate.py` (all green, §16) |
| SQLite contention | WAL + per-call connections; no lock contention observed at 1 writer + 1 reader (the only legal mix — the gate serialises writers) |
| Disk I/O spikes | none pathological: per-fact upserts are small; archive/cleanup are daily-throttled |

## 10. Memory quality observations

Seeded 118-fact persona (HU+EN, temporal variants, occurrence counts,
supersession pair) + 28 heartnotes + 12 traits; 26 probes through the REAL
search path (`evidence/bench_quality_probe.json`):

* **Retrieval accuracy:** hit@5 = 19/22 (86.4 %); rank distribution of hits
  {1: 15, 2: 3, 3: 1}; mean rank 1.26. The 2 genuine misses were
  adjacent-topic dominance (a semantically-neighbouring fact outscored the
  exact one — e.g. "summer holidays in July" beat "Croatia trip in July" for
  *Mikor megyek Horvátországba?*).
* **Supersession:** current-value question returns the new row at rank 1 ✓.
  However the OLD row — present, intact and correctly marked `superseded_by` —
  did **not** surface in top-5/top-10 even for a history-phrased question
  (*Mi volt a kedvenc éttermem régen?*) nor for a query quoting its own
  content: the tier sort demotes superseded rows behind *all* non-superseded
  candidates, which at 118 facts already pushes them out of the candidate cut.
  The "stays queryable" contract (VM-LOCAL-008) is satisfied nominally, not
  effectively, at realistic library sizes.
* **Temporal semantics:** future/past/uncertain rows carry stance + validity
  intervals into the prompt provenance (verified in the rendered hits); the
  date-normalisation fix chain (`_as_date`, event-time anchor) is present.
* **Neutral/out-of-domain queries** ("qwerty…", "Mennyi 2+2?", "vers a
  tengerről") always return 3–5 hits — pure-cosine Top-K has no abstention
  floor. Mitigation in-product: the low-confidence directive tells the reply
  model to say "I don't know" when the evidence is generic (present, verified
  in `Search()`); the persona caps memory influence. No false facts are
  *invented* by the store, but irrelevant Top-K entries are structurally
  guaranteed for off-domain questions.
* **Near-duplicates:** `_dedupe_near` trigram collapse works (no duplicate
  tops observed); duplicates that do coexist (EN/HU near-paraphrase rows
  deliberately seeded) can co-occur in one Top-5 but are marked with dates.
* **Stale memory:** no staleness observed beyond the supersession case (heat
  decay + archive exist but were not exercised — thresholded paths).

## 11. Upstream comparison

Upstream `xzf-thu/VoiceMem` has moved 52 commits past our pin (`e8384e0`).
Checked against our tree:

| Upstream change | Status in our fork |
|---|---|
| `961efe8` use the injected embedder everywhere | **ported** (VM-LOCAL-001, same rationale) |
| `91d2e42` guard vector-dimension mismatch | **ported** (traits_store stale-vector skip + warning) |
| `f535f9d` bind trait threshold to embedder | **ported** (`trait_min_sim` per dim) |
| `fa537a9` drop response_experience | **ported** (VM-LOCAL-017, env-gated default-off) |
| `333dbcb` cap heartnote slots in right-brain top-N | **ported** (`_SOURCE_QUOTA["situation_pattern"]=2`) |
| `e3cc965` fix memory event dates (`_as_date`) | **ported** |
| `ab97cf5` append instead of overwrite | **superseded by a richer local design** (VM-LOCAL-008 explicit supersession chain — upstream simply treats UPDATE as ADD) |
| `a507978` narrow recency weighting (multiplicative, then gated to recency-cue queries) | **not ported; deliberately different**: our VM-LOCAL-011 recency is a small *additive* bonus (≤0.10) applied to all queries, avoiding upstream's documented failure mode (long-term attributes being punished); upstream then had to add cue-gating. Our probe shows the intended behaviour. Different-but-equivalent; documented divergence |
| `a48e90f`/`0472c41`/`6f282e8` memory-language-per-space family | **rejected by policy** (UPSTREAM_POLICY invariant 4: no global `memory_language` coercion; HU/EN behaviour preserved) |
| `7c22ac7` unify model configuration | not adopted (pin/lock discipline) |
| `6c085d4`/`a450911`/`7581656` barge-in/session/playback (upstream's Flask `web/run.py` + worklet) | different web stack; our aiohttp server has its own barge-in/session handling — out of memory-layer scope, noted |

**Conclusion:** nothing upstream currently ships a memory mechanism that our
fork is missing *and* that would demonstrably improve the system under our
invariants. The one interesting behavioural difference (recency) is covered by
a deliberate local design.

## 12. Findings — KEEP / IMPROVE / INVESTIGATE

### KEEP (no proven problem)

| # | Finding | Basis |
|---|---|---|
| K1 | Read-path architecture: full-library E5+Qdrant scan with client-side bonus/tier ranking, 0 LLM on the hot path | measured §8; no bottleneck at ≤4 000 facts |
| K2 | Memory-search turn budget (25 s cold / ~2.6 s steady, then continue without memory) + late-failure drain | code + S8 (search 159 ms on the slow-turn anatomy) |
| K3 | BackgroundMemoryGate: idle-window release, one-chain-at-a-time, coalescing, never-drop re-queue | code + 61 unit tests green + S8 timeline |
| K4 | Cooperative cancel transport (`bg_chat_create`) for extraction + conflict-resolution | measured A2 (0.17–0.29 s user TTFT) |
| K5 | Shared E5 singleton (`lru_cache`), local-model pin, no remote embedding path | code + RAM flat across facades |
| K6 | SQLite usage: per-call connections, WAL where it matters, traits timeout 30 s | code; no contention at the only legal concurrency mix |
| K7 | Non-destructive supersession + opt-in DELETE + stance/temporal metadata on one additive channel | tests green (§16), probe behaviour §10 |
| K8 | Provenance suffix (date/occurrence/supersession/attribution) rendered identically web+CLI | code + render cost 0.02 ms |
| K9 | Prompt-side guards: 1200-char memory block, 6000-char reply hook cap, 14000-char budget fit | code + tests (prompt budget) |
| K10 | Facade caches (CLI LRU+idle eviction; web per-space with construction-failure degradation) | code; web cache is unbounded by space count (see I4) |
| K11 | Per-search `ThreadPoolExecutor(1)` for rb‖rank | negligible; not worth touching |
| K12 | The vendor's three daemon maintenance threads (audio/cold-archive daily-throttled) — disk-only halves | code; disk-only, kv-throttled |

### IMPROVE (reproduced problem + measured impact + justified fix exists)

| # | Finding | Reproduction / measurement | Fix |
|---|---|---|---|
| **M1** | **Remaining non-streaming, non-cancellable LLM legs in the ingest chain hold the single llama-server slot through `arm()`:** reaction attribution (`_llm_json`, every turn), inner-OS generation (10 s), slot tagging (`_llm_json`), schema refresh + AttributionManager (`_llm_text`), `run_cleanup` (60 s timeout). A user turn starting mid-leg queues behind it. | this audit A1 (user TTFT = full leg: 2.5 / 2.95 / 31.2 s); S8 T5 (10.07 s queue, "the cancel freed the slot for every subsequent leg but not for the in-flight one"); v0102 report conclusion (s3 Run A 71.9 s vs Run B 0.30 s); target field 30–42 s TTFT outliers attributed to this class | mechanical, bounded: route these legs through `bg_chat_create` (the existing, proven transport — the same change v0.10.2 already made for the two big legs). No new mechanism, no queue, no cache. | 
| **M2** | **`run_cleanup` escapes the gate entirely** (spawned as its own daemon thread inside `_finish_ingest`; the gate's `_running` is already False when it runs) **and holds the slot up to 60 s un-cancellable** when the +50-heartnote threshold fires. | code path (`threading.Thread(target=self._check_and_cleanup, daemon=True)` per ingest, → `run_cleanup` → plain `create`, `timeout=60.0`); transport cost measured in A1 | same transport fix as M1 + let the gate observe it (or run it under the gate's own worker) — the thread is already the last step of a gated chain, so routing its LLM call through `bg_chat_create` plus keeping the gate's `_running` true until the thread exits is a ~10-line change. |

### INVESTIGATE (suspicious/potential, evidence insufficient to act)

| # | Finding | What is known | What would decide it |
|---|---|---|---|
| I1 | CLI path has no gate and no cancellation at all (`commit_reply` → `ingest(async_facts=True)` fire-and-forget; `BG_CANCEL` never set on that path) — the S8-class contention is structurally possible there after every reply | code-proven; transport impact measured (A1); actual CLI usage in the field unknown (all field reports are web) | one operator decision: is the CLI agent a supported conversational surface? If yes → apply the same gate (the BackgroundMemoryGate is importable as-is); if no → document it as a non-guaranteed surface |
| I2 | Superseded rows are effectively unreachable for history questions at realistic library sizes (tier demotion behind ALL non-superseded candidates) | probe §10: old row absent from top-5/top-10 even when quoting its own content (marked, present, intact) | a product decision on whether "Mi volt régen?" must be answerable from memory; if yes, a demotion *within rank order* (e.g. score − δ instead of tier-last) is the minimal change — needs a quality A/B before touching it |
| I3 | Neutral/off-domain queries always fill Top-K (no similarity floor) | probe §10: 3–5 hits for "qwerty"/"2+2" | only if the target shows wrong-memory-flavoured replies: a calibrated floor is a quality-risk change (false negatives), the current mitigation (low-confidence directive) is prompt-side and reversible |
| I4 | Web MemoryLayer facade dict is unbounded by space count (no LRU/idle eviction; CLI bridge has both) and one construction failure poisons ALL spaces (`self._failed` global) | code (`web_server.py` `_facade`); scale is operator-spaces (tens), not users — not measured as a problem | only if multi-space deployments grow; then reuse the CLI's `_prune_vm_cache` pattern |
| I5 | Speculative retrieval on ASR partials (turn-end avoidance) | §6: no defect; benefit bounded by the 100 ms search cost; wrong-speculation risk on HU agglutination | only a target TTFT budget violation would justify a trial |
| I6 | E5 contention inflation (+73 % P50 under a continuous background embed loop) | measured §8-B; 2-core sandbox worst-case, bounded at ~180 ms absolute | none unless the target shows >1 s searches during ingests; not worth pre-optimising |
| I7 | Space switch between `submit()` and the gate worker run can write a pair into the newly-active space (`MemoryLayer.ingest` resolves the active space at run time) | code-read; additive (nothing lost, but cross-space attribution could mislabel) | reproduce with a scripted switch test if multi-space switching is a real usage pattern |

## 13. Concrete recommendations (proven problems only)

1. **M1 — extend the cooperative-cancel transport to the remaining ingest legs**
   (`_llm_json`, `_llm_text`, `_generate_inner_os`, the AttributionManager calls
   they back, and `run_cleanup`). This is the same change pattern v0.10.2
   applied to extraction/conflict-resolution: wrap the request in
   `bg_chat_create`, keep the response shim. Expected effect per the A1→A2
   measurement: the worst-case user TTFT behind ANY memory leg drops from
   "the leg's full duration" to ~0.2–0.3 s. Risk: low (transport only; the legs
   already tolerate empty-string failures); consistency unchanged (cancellation
   still only strikes between/in legs, results still written only after
   completion).
2. **M2 — bring `run_cleanup` (and the daemon-thread spawns) under the gate's
   visibility** so `is_processing` reflects the true end of background work and
   the 60 s leg cannot start outside an idle window.
3. When implementing 1–2: full golden-rule gate (complete test suite, zero new
   regressions, recovery package, worklog, mirror sync) — none of which is done
   in this audit phase, per the audit-only order.

No other change is recommended by the evidence.

## 14. Things explicitly NOT recommended

* **No cache** (embeddings, searches, or results): the measured problems live
  in LLM-leg scheduling, not in retrieval cost. E5 query embed is 19 ms P50;
  `embed_cache` already exists inside the vendor for entity/slot anchors. A new
  cache layer would add invalidation risk for no proven benefit. **NOT RECOMMENDED.**
* **No queue/broker/worker framework** for memory work: the single gated worker
  is the design bound (deliberate, documented); a framework would multiply
  background LLM legs — the opposite of the operator's user-priority contract.
* **No new concurrency model** (async vendor rewrite, thread pools around
  stores): no measured lock contention or reader/writer conflict exists at the
  legal concurrency mix.
* **No speculative/partial-transcript retrieval** (see I5): unproven benefit,
  real wrong-context risk.
* **No Qdrant server migration**: local mode is correct for single-user
  personal-memory scale; the measured scan cost is trivially inside budget.
* **No schema/DB change, no second store, no Learning-Engine scaffolding**:
  audit-only phase; the supersession/temporal metadata channel already carries
  what a future layer needs (arch-prep findings).
* **No upstream re-sync** (recency-weighting commit et al.): §11 — every
  behaviour we lack is either already covered by a deliberate local design or
  rejected by policy invariant.
* **No refactor of the "dead" routing stages** (Classify/SearchCogGraph on the
  read path): removing or wiring them (an LLM call per turn!) would be a
  latency regression for zero measured recall benefit at current scale.

## 15. Proposed next steps

1. Operator decision on M1/M2 (the only proven problem class): approve the
   transport extension + gate-visibility change as the next implementation task
   (est. small, mechanical, testable with the existing llm_bg_gate test
   pattern).
2. If the CLI agent is a supported surface: decide I1 (gate on the CLI path).
3. Optionally schedule I2 (superseded-row reachability) as a *product* question
   — it is a behaviour choice, not a defect.
4. Target-side validation of the M1 effect after implementation: replay the S8
   methodology (llm_slot_forensic) — the T5-class queue wait should disappear
   from outlier anatomy.

## 16. Test evidence

Runs executed by this audit (all green unless noted):

* `pytest tests/unit/test_background_memory_gate.py tests/unit/test_llm_bg_gate.py tests/unit/test_retrieval_contract.py tests/unit/test_retrieval_contract_semantics.py tests/unit/test_fact_supersession_semantics.py tests/unit/test_trait_semantics.py tests/unit/test_traits_observation.py tests/unit/test_temporal_semantics.py` — **154 passed** (34.2 s)
* `pytest tests/validation/test_feature_memory.py tests/validation/test_feature_memory_semantics.py tests/validation/test_feature_embedding.py tests/integration/test_memory_safety.py` — **30 passed** (34.2 s)
* Benchmark scripts (audit-local, no production code touched):
  `scripts/seed_memory.py` (real-store seeding: 118/10-fact roots + right brain),
  `scripts/bench_search.py`, `scripts/bench_scaling.py`, `scripts/bench_ingest.py`,
  `scripts/bench_concurrency.py` (llm + e5 modes), `scripts/bench_quality.py` —
  outputs in `evidence/` (`bench_search_populated.json`, `bench_scaling.json`,
  `bench_ingest_chain.json`, `bench_concurrency.json`, `bench_concurrency_e5.json`,
  `bench_quality_probe.json`, `environment.json`).
* Sandbox environment honesty notes: (a) the sandbox could not run the 19 GB
  production model — all LLM-leg timings used the documented stand-in and the
  S8 target-shaped evidence; the extraction leg could not complete inside its
  60 s client timeout at the sandbox's ~50 t/s prefill (the identical class the
  S8 capture recorded as the task-197 rejection artifact) — leg *structure* and
  store-side timings remain valid; (b) sandbox RAM (4 GB) OOM-killed the
  llama-server twice when the full ingest bench co-resided with the mandatory
  Next.js dev server — mitigated by the smaller stand-in and split benchmark
  runs; both OOM events are sandbox artifacts, not product findings (matches
  the S8 honesty section); (c) memory seeding went through the real store APIs
  with no LLM, mirroring the production post-extraction write shape.

---

## What was measured, what is hypothesis, what is not worth changing

* **Measured (this audit):** read-path latency decomposition and scaling
  (118→4 000 facts), render cost, E5 embed cost, one-time construction/E5-load
  costs, process RSS, per-fact store-write cost, attribution-leg wall time,
  user-TTFT behind cancelled-streaming vs un-cancellable-non-streaming legs,
  E5-contention search inflation, retrieval hit@5/ranks on a 118-fact persona,
  superseded-row reachability, neutral-query Top-K composition, all
  memory-related unit/validation/integration suites (184 tests).
* **Reused prior target-shaped evidence:** S8 task-timing table (T5 10.07 s
  queue; s3 71.9 s vs 0.30 s; warm-chain 111 s), v0102 LLM-priority audit,
  v0.9.1/v0.9.2 runtime audits.
* **Hypothesis only (no action taken):** I1 CLI-usage frequency, I2 whether
  history-questions must be memory-answerable, I3 similarity-floor trade-off,
  I4 multi-space scale, I5 speculative-retrieval benefit, I7 space-switch
  mislabelling.
* **Not worth changing (documented KEEP):** everything in the KEEP table —
  most notably the full-scan read path (fast at 33× the current store size),
  the gate design, the SQLite/WAL usage, the shared-E5 policy, and the
  existing cancellation transport for the two big legs.
* **Proven and fixable (the only recommended work):** M1 + M2 — extend the
  proven `bg_chat_create` transport to the remaining ingest LLM legs and bring
  the cleanup thread under the gate's visibility. Nothing else in this audit
  meets the IMPROVE bar.
