# RECOVERY — VoiceMemAgent_v0.10.5_MemoryPerformanceAudit

## What this is
The audit-only deliverable for the v0.10.5 memory-layer performance & stability
audit (task memperf-0105). Contains: the 16-section REPORT.md, the raw
measurement evidence (7 JSON files), and the exact benchmark scripts used.

## What it is NOT
A product release. No production/runtime code was modified by this audit. No
VERSION bump. Nothing in this package needs rollback — it is additive
documentation + evidence only.

## How to verify
1. `sha256sum -c SHA256SUMS` (inside the unpacked package).
2. Report claims cite the evidence files by name; each measurement block in
   REPORT.md §8-§10 maps 1:1 to a JSON in `evidence/`.
3. To re-run: see `scripts/` (they run against throw-away memory roots under
   /tmp; the product `memory/` tree is never written). Sandbox honesty notes
   are in REPORT.md §16.

## If the M1/M2 recommendations are later implemented
They are explicitly NOT part of this package (audit-only order). Any
implementation goes through the golden rule: full test gate, zero new
regressions, recovery package, worklog, mirror sync.
