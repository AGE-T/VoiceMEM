"""AUDIT-ONLY: memory QUALITY probe on the seeded root (no LLM involved).

Measures on the REAL vendor search path:
  * hit@5 and rank-of-expected for 24 query->expected-fact pairs,
  * neutral-query behaviour (irrelevant Top-K entries),
  * supersession rendering (old row appears marked, new row ranks first),
  * temporal marking (past/future facts carry stance in provenance),
  * duplicate/near-duplicate composition of Top-K.

Usage: bench_quality.py <memory_root> <out_json>
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

AGENT = Path(__file__).resolve().parents[3] / "voicemem-agent"
os.environ.setdefault("VOICEMEM_E5_MODEL", str(AGENT / "models/embedding/multilingual-e5-small"))
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("OPENAI_BASE_URL", "http://127.0.0.1:8080/v1")
os.environ.setdefault("OPENAI_API_KEY", "audit-dummy")
os.environ.setdefault("OPENAI_MODEL", "audit-standin")
sys.path.insert(0, str(AGENT))

sys.path.insert(0, str(Path(__file__).resolve().parent))
import seed_memory  # noqa: E402  (for the expected-text map)

# query -> expected fact text (exact FACTS[i] text)
PAIRS = [
    ("Milyen kávét iszom reggel?", 0),
    ("Miért vagyok ideges prezentáció előtt?", 1),
    ("Kivel dolgozom együtt sokat?", 20),
    ("Mi a húgom neve és hol lakik?", 7),
    ("Milyen nyelvet tanulok most?", 9),
    ("Mi a célom szeptemberig?", 10),
    ("Mire vagyok allergiás?", 19),
    ("Hol lakom most?", 17),
    ("Mikor megyek Horvátországba?", 18),
    ("Mi a főnököm neve?", 46),
    ("Hányan vannak a csapatomban?", 47),
    ("Mi a kedvenc filmem?", 23),
    ("Hogy hívják a macskámat?", 14),
    ("Mikor kel reggel?", 25),
    ("Mi a bankszámlám bankja?", 40),
    ("Milyen autóm volt korábban?", 43),
    ("Mi a becenevem?", 95),
    ("Mikor van a születésnapom?", 96),
    ("Mi a teljes nevem?", 97),
    ("Mit szoktam csinálni péntek este?", 39),
    ("Hova járok edzeni?", 4),
    ("Mi a kedvenc reggelim?", 3),
    ("Mi volt a kedvenc éttermem régen?", None),  # supersession probe (old row)
    ("Mi a mostani kedvenc éttermem?", None),     # supersession probe (new row)
]

NEUTRAL = [
    "qwertyuiop asdfgh",
    "Mennyi 2+2?",
    "Elmondasz egy verset a tengerről?",
    "Hogyan kell leülni egy székre?",
]


def main() -> None:
    root = sys.argv[1]
    out_path = sys.argv[2]

    from voicemem import VoiceMem

    def ef():
        from voicemem.leftbrain.local_e5_embedder import LocalE5Embedder
        return LocalE5Embedder()

    vm = VoiceMem(mode="text_mode", user_id="voice_user",
                  base_url=os.environ["OPENAI_BASE_URL"], top_k=5,
                  memory_root=root, embedding=ef)
    vm.search("warm up")

    sys.path.insert(0, str(AGENT / "app"))
    from app.web_server import clean_rb_content, hit_provenance_suffix

    rows = []
    hits_at_5 = 0
    ranks = []
    for query, idx in PAIRS:
        r = vm.search(query)
        texts = [getattr(h, "text", "") for h in (r.hits or [])]
        if idx is None:
            rows.append({"query": query, "type": "supersession",
                         "texts": texts, "timing": r.timing})
            continue
        expected = seed_memory.FACTS[idx][0]
        rank = None
        for i, t in enumerate(texts):
            if t.strip() == expected.strip():
                rank = i + 1
                break
        if rank:
            ranks.append(rank)
            hits_at_5 += 1
        rows.append({"query": query, "expected": expected, "rank": rank,
                     "texts": texts, "timing": r.timing,
                     "provenance": [hit_provenance_suffix(h) for h in (r.hits or [])]})

    neutral_rows = []
    for q in NEUTRAL:
        r = vm.search(q)
        neutral_rows.append({"query": q,
                             "texts": [getattr(h, "text", "")[:70] for h in (r.hits or [])],
                             "n_hits": len(r.hits or [])})

    out = {
        "pairs": rows,
        "neutral": neutral_rows,
        "summary": {
            "hit_at_5": hits_at_5,
            "n_scored": len([p for p in PAIRS if p[1] is not None]),
            "hit_rate": round(hits_at_5 / max(1, len([p for p in PAIRS if p[1] is not None])), 3),
            "mean_rank_of_hits": round(sum(ranks) / len(ranks), 2) if ranks else None,
            "rank_distribution": {str(i): ranks.count(i) for i in sorted(set(ranks))} if ranks else {},
        },
    }
    Path(out_path).write_text(json.dumps(out, indent=1, ensure_ascii=False))
    print(json.dumps(out["summary"], indent=1))
    for nr in neutral_rows:
        print("NEUTRAL:", nr["query"][:30], "->", nr["n_hits"], "hits")


if __name__ == "__main__":
    main()
