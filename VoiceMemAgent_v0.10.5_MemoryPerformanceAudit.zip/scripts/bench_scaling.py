"""AUDIT-ONLY: read-path SCALING probe — search latency vs library size.

Seeds fresh roots with N facts (realistic base set + synthetic fillers through
the REAL store APIs, no LLM), then measures Search() latency at each size.

Usage: bench_scaling.py <out_json>
"""
from __future__ import annotations

import json
import os
import statistics
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
AGENT = Path(__file__).resolve().parents[3] / "voicemem-agent"
os.environ.setdefault("VOICEMEM_E5_MODEL", str(AGENT / "models/embedding/multilingual-e5-small"))
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("OPENAI_BASE_URL", "http://127.0.0.1:8080/v1")
os.environ.setdefault("OPENAI_API_KEY", "audit-dummy")
os.environ.setdefault("OPENAI_MODEL", "audit-standin")
sys.path.insert(0, str(AGENT))

import seed_memory  # noqa: E402

SIZES = [500, 1000, 2000, 4000]

FILLER_TOPICS = [
    "a szokásos reggeli rutinja", "a kedvenc buszjárata", "a hétvégi takarítás rendje",
    "a munkahelyi ebéd szokásai", "a kedvenc TV sorozata", "a nyaralási csomagolási listája",
    "a kerti növények öntözése", "a havi könyvelési rutinja", "a gyerekkori játékai",
    "a jelenlegi olvasmányai", "a kedvenc ételkülönlegessége", "a sporteszközei listája",
]

QUERIES = [
    "Milyen kávét iszom reggel?",
    "Mire vagyok allergiás?",
    "Mi a főnököm neve?",
    "Mikor megyek fogorvoshoz?",
    "Mit csináltam tegnap?",
]


def pct(sv, p):
    if not sv:
        return None
    i = min(len(sv) - 1, max(0, int(round(p / 100.0 * (len(sv) + 1))) - 1))
    return round(sv[i], 1)


def main() -> None:
    from voicemem import VoiceMem

    def ef():
        from voicemem.leftbrain.local_e5_embedder import LocalE5Embedder
        return LocalE5Embedder()

    out = {"sizes": {}, "queries": QUERIES}
    for n in SIZES:
        root = f"/tmp/vm-audit/root-n{n}"
        os.system(f"rm -rf {root}")
        Path(root).mkdir(parents=True, exist_ok=True)
        # seed realistic base (118 facts incl. right brain)
        seed_memory.seed(root, "voice_user")
        # append synthetic fillers to reach n total
        from voicemem import VoiceMem as VM
        vm = VM(mode="text_mode", user_id="voice_user",
                base_url=os.environ["OPENAI_BASE_URL"], top_k=5,
                memory_root=root, embedding=ef)
        repo = vm._o._get_repo()
        remaining = n - 118
        from voicemem.leftbrain.cognitive_graph.slot_v2 import SlotV2
        t0 = time.perf_counter()
        batch = []
        for i in range(remaining):
            topic = FILLER_TOPICS[i % len(FILLER_TOPICS)]
            batch.append((f"A felhasználó #{i} megjegyzése: {topic}, a(z) {i % 30 + 1}. alkalommal",
                          "user", {"created_at": "2026-08-20T10:00:00", "source": "audit-fill"}))
        # add in chunks of 50 to bound memory
        for c0 in range(0, len(batch), 50):
            chunk = [("", b[0], b[1], b[2]) for b in batch[c0:c0 + 50]]
            ids = repo._vector_store.add_records_with_ids("voice_user", chunk)
            for mid in ids[: max(1, len(ids) // 4)]:  # tag ~25% so slot filtering has data
                repo._cognitive_store.upsert_memory_record(
                    "voice_user", mid, SlotV2.DAILY_LIFE, "filler")
                repo._cognitive_store.upsert_memory_tags(mid, "voice_user", [("daily_life", 0.8)])
        seed_s = time.perf_counter() - t0

        # measure
        for q in QUERIES:
            vm.search(q)  # warm
        lat = []
        for i in range(20):
            q = QUERIES[i % len(QUERIES)]
            t0 = time.perf_counter()
            vm.search(q)
            lat.append((time.perf_counter() - t0) * 1000.0)
        s = sorted(lat)
        out["sizes"][str(n)] = {
            "seed_s": round(seed_s, 1),
            "mean": round(statistics.fmean(lat), 1),
            "p50": pct(s, 50), "p95": pct(s, 95), "p99": pct(s, 99),
            "min": round(min(lat), 1), "max": round(max(lat), 1),
        }
        print(n, out["sizes"][str(n)], flush=True)
        # free the qdrant handle so the next root starts clean
        try:
            repo._vector_store._mem0.client.close()
        except Exception:
            pass

    Path(sys.argv[1]).write_text(json.dumps(out, indent=1))
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
