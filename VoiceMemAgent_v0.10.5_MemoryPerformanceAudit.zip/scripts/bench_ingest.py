"""AUDIT-ONLY: memory WRITE-path (ingest chain) latency benchmark.

Runs the REAL vendor ingest chain (facade.ingest(text, agent_reply=reply,
async_facts=False) — the exact web-gated shape) against the local llama-server
stand-in, with process-local timing wrappers around every LLM leg and every
store write. No production code is modified.

Usage: bench_ingest.py <memory_root> <out_json>
"""
from __future__ import annotations

import json
import os
import statistics
import sys
import time
from collections import defaultdict
from pathlib import Path

AGENT = Path(__file__).resolve().parents[3] / "voicemem-agent"
os.environ.setdefault("VOICEMEM_E5_MODEL", str(AGENT / "models/embedding/multilingual-e5-small"))
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("OPENAI_BASE_URL", "http://127.0.0.1:8080/v1")
os.environ.setdefault("OPENAI_API_KEY", "audit-dummy")
os.environ.setdefault("OPENAI_MODEL", "audit-standin")
sys.path.insert(0, str(AGENT))

# (user_text, agent_reply) — realistic Hungarian turns; several reference
# already-stored facts (forces UPDATE/conflict candidates), some add new ones.
TURNS_ALL = [
    (
        "Kérlek jegyezd meg, hogy júliusban Horvátországba megyünk szabadságra, és a húgom is jön velünk",
        "Rendben, jegyzem: júliusi horvátországi családi nyaralás a húgoddal együtt. Ez szép terv lesz!",
    ),
    (
        "Ma azt hittem, megint a Belvárosi Étterembe megyünk vacsorázni, de végül a Kisbuda Gyöngye lett a kedvencem",
        "Értem, szóval mostanában a Kisbuda Gyöngye a kedvenc éttermed. Jó választás, ott mindig finom az étel!",
    ),
    (
        "Kicsit fáradt vagyok, egész nap a Q4-es riporton dolgoztam, de sikerült befejezni az elemzést",
        "Nagyon jó munka! A Q4-es riport elemzése kemény feladat volt, és fáradtság mellett is sikerült. Pihenj egy kicsit!",
    ),
    (
        "Új információ: anyukám születésnapját idén nem májusban, hanem júniusban ünnepeljük, mert áthelyezték a családi összejövetelt",
        "Jegyzem: anyukád születésnapjának ünneplése idén júniusra tolódott a családi döntés miatt. Így már tudom!",
    ),
    (
        "Az edzőteremben változás: mostantól hétfőn és csütörtökön járok, nem kedden",
        "Értem, frissítem: az edzőtermi napjaid mostantól hétfő és csütörtök. Így egyenletesebben oszlik el a hét!",
    ),
    (
        "Köszönöm a segítséget a jelentéssel, sokat segített amit mondtál",
        "Nagyon szívesen segítettem! Örülök, hogy hasznos volt. Ha megint kérdésed van a jelentésekkel, szólj bátran!",
    ),
]

TURNS = TURNS_ALL[:3]


def stats(vals):
    if not vals:
        return {"n": 0}
    s = sorted(vals)
    return {
        "n": len(vals),
        "mean": round(statistics.fmean(vals), 1),
        "min": round(min(vals), 1),
        "max": round(max(vals), 1),
    }


def main() -> None:
    root = sys.argv[1]
    out_path = sys.argv[2]

    from voicemem import VoiceMem

    def ef():
        from voicemem.leftbrain.local_e5_embedder import LocalE5Embedder
        return LocalE5Embedder()

    vm = VoiceMem(mode="text_mode", user_id="voice_user",
                  base_url=os.environ["OPENAI_BASE_URL"], top_k=5,
                  memory_root=root, embedding=ef)
    o = vm._o
    vm.search("warm up")

    legs: dict[str, list[float]] = defaultdict(list)
    leg_order: list[dict] = []

    # ---- process-local instrumentation (wraps, never edits files) -------------
    import voicemem.utils.common.llm_bg_gate as bg_gate

    _orig_bg = bg_gate.bg_chat_create

    def timed_bg(client, *, leg, **kw):
        t0 = time.perf_counter()
        try:
            return _orig_bg(client, leg=leg, **kw)
        finally:
            dt = (time.perf_counter() - t0) * 1000.0
            legs[f"llm:{leg}"].append(dt)
            leg_order.append({"leg": f"llm:{leg}", "ms": round(dt, 1)})

    bg_gate.bg_chat_create = timed_bg
    # the extractor/ConflictResolver imported the symbol at module load: rebind
    import voicemem.leftbrain.extract_facts_openai as efo
    efo.bg_chat_create = timed_bg

    _orig_json = o._llm_json

    def timed_json(prompt):
        t0 = time.perf_counter()
        try:
            return _orig_json(prompt)
        finally:
            dt = (time.perf_counter() - t0) * 1000.0
            legs["llm:_llm_json(attribution/tagging)"].append(dt)
            leg_order.append({"leg": "llm:_llm_json", "ms": round(dt, 1)})

    o._llm_json = timed_json
    o._left._llm_json = timed_json
    o._right._llm_json = timed_json

    _orig_text = o._llm_text

    def timed_text(prompt, max_tokens=300):
        t0 = time.perf_counter()
        try:
            return _orig_text(prompt, max_tokens=max_tokens)
        finally:
            dt = (time.perf_counter() - t0) * 1000.0
            legs["llm:_llm_text(schema/attribution)"].append(dt)
            leg_order.append({"leg": "llm:_llm_text", "ms": round(dt, 1)})

    o._llm_text = timed_text
    o._left._llm_text = timed_text

    _orig_os = o._generate_inner_os

    def timed_os(*a, **kw):
        t0 = time.perf_counter()
        try:
            return _orig_os(*a, **kw)
        finally:
            dt = (time.perf_counter() - t0) * 1000.0
            legs["llm:inner_os_generation"].append(dt)
            leg_order.append({"leg": "llm:inner_os", "ms": round(dt, 1)})

    o._generate_inner_os = timed_os

    repo = o._get_repo()
    rb_repo = o._right._rb_repo()

    _orig_add = repo._vector_store.add_records_with_ids

    def timed_add(uid, items):
        t0 = time.perf_counter()
        try:
            return _orig_add(uid, items)
        finally:
            legs["store:mem0_add_records"].append((time.perf_counter() - t0) * 1000.0)

    repo._vector_store.add_records_with_ids = timed_add

    _orig_upd = repo._vector_store.update_memory

    def timed_upd(*a, **kw):
        t0 = time.perf_counter()
        try:
            return _orig_upd(*a, **kw)
        finally:
            legs["store:mem0_update(supersede)"].append((time.perf_counter() - t0) * 1000.0)

    repo._vector_store.update_memory = timed_upd

    _orig_occ = repo._vector_store.count_occurrence

    def timed_occ(*a, **kw):
        t0 = time.perf_counter()
        try:
            return _orig_occ(*a, **kw)
        finally:
            legs["store:count_occurrence"].append((time.perf_counter() - t0) * 1000.0)

    repo._vector_store.count_occurrence = timed_occ

    _orig_rbw = rb_repo._store.upsert_memory

    def timed_rbw(*a, **kw):
        t0 = time.perf_counter()
        try:
            return _orig_rbw(*a, **kw)
        finally:
            legs["store:rb_upsert_heartnote"].append((time.perf_counter() - t0) * 1000.0)

    rb_repo._store.upsert_memory = timed_rbw

    _orig_trait_add = o._right._traits().add

    def timed_trait(*a, **kw):
        t0 = time.perf_counter()
        try:
            return _orig_trait(*a, **kw)
        finally:
            legs["store:rb_trait_add"].append((time.perf_counter() - t0) * 1000.0)

    o._right._traits().add = timed_trait

    # ---- run the chain --------------------------------------------------------
    def rss_mb():
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return round(int(line.split()[1]) / 1024.0, 1)
        return -1.0

    turn_rows = []
    for i, (utext, reply) in enumerate(TURNS):
        t0 = time.perf_counter()
        n_legs_before = len(leg_order)
        result = vm.ingest(utext, agent_reply=reply, async_facts=False)
        total_s = time.perf_counter() - t0
        turn_legs = leg_order[n_legs_before:]
        llm_ms = sum(l["ms"] for l in turn_legs if l["leg"].startswith("llm:"))
        turn_rows.append({
            "turn": i + 1,
            "total_s": round(total_s, 2),
            "llm_ms_of_turn": round(llm_ms, 1),
            "facts_count": result.get("facts_count"),
            "memory_ids": len(result.get("memory_ids") or []),
            "rss_mb": rss_mb(),
            "legs_this_turn": turn_legs,
        })
        print(f"turn {i+1}: total={total_s:.2f}s llm={llm_ms:.0f}ms "
              f"facts={result.get('facts_count')} rss={rss_mb()}MB", flush=True)

    llm_total = sum(v for k, vs in legs.items() if k.startswith("llm:") for v in vs)
    store_total = sum(v for k, vs in legs.items() if k.startswith("store:") for v in vs)
    grand = sum(r["total_s"] for r in turn_rows) * 1000.0

    out = {
        "turns": turn_rows,
        "leg_stats_ms": {k: stats(v) for k, v in sorted(legs.items())},
        "summary": {
            "n_turns": len(TURNS),
            "grand_total_ms": round(grand, 1),
            "llm_total_ms": round(llm_total, 1),
            "store_total_ms": round(store_total, 1),
            "other_ms": round(grand - llm_total - store_total, 1),
            "llm_share": round(llm_total / grand, 3),
        },
        "leg_order_sample": leg_order[:60],
    }
    Path(out_path).write_text(json.dumps(out, indent=1, ensure_ascii=False))
    print(json.dumps(out["summary"], indent=1))


if __name__ == "__main__":
    main()
