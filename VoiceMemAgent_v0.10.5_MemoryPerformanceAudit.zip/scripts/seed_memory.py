"""AUDIT-ONLY helper: build a realistic populated VoiceMem memory root.

Writes through the REAL vendor store APIs (mem0/qdrant + cognitive sqlite +
right-brain heartnotes/traits) with NO LLM calls, mirroring the production
post-extraction write shape (memory_repository.append_extracted /
RightBrain.write / TraitStore.add). Never touches the product memory/ tree:
the target root must be a fresh directory under /tmp.

Usage: python3 seed_memory.py <memory_root> [user_id]
"""
from __future__ import annotations

import os
import sys
import uuid
from datetime import datetime, timedelta
from pathlib import Path

# --- offline/product env discipline (mirrors config/env.local.ps1) -------------
AGENT = Path(__file__).resolve().parents[3] / "voicemem-agent"
os.environ.setdefault("VOICEMEM_E5_MODEL", str(AGENT / "models/embedding/multilingual-e5-small"))
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("OPENAI_BASE_URL", "http://127.0.0.1:8080/v1")
os.environ.setdefault("OPENAI_API_KEY", "audit-dummy")
os.environ.setdefault("OPENAI_MODEL", "audit-standin")

sys.path.insert(0, str(AGENT))

BASE = datetime(2026, 8, 26)  # observation date base


def _d(days: int) -> str:
    return (BASE - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%S")


# --- left-brain facts: (text, slot, age_days, extra_meta) -----------------------
FACTS = [
    ("A felhasználó kedvenc kávéja a long coffee, és minden reggel iszik egyet Budapesten", "daily_life", 21, {}),
    ("A felhasználó PresentationPers előtt mindig ideges lesz", "work", 20, {}),
    ("A felhasználó nem szeret hosszú értekezleteket", "work", 20, {}),
    ("A felhasználó kedvenc reggelije a túrós csusza", "daily_life", 19, {}),
    ("A felhasználó minden kedden edzőterembe jár", "health", 19, {}),
    ("A felhasználó havi kerete 350000 forint", "finance", 18, {}),
    ("A felhasználó spórol egy új laptopra", "finance", 18, {}),
    ("A felhasználónak van egy Anna nevű húga, aki Szegeden lakik", "relationships", 18, {}),
    ("A felhasználó anyja májusi születésnapját mindig együtt ünneplik", "relationships", 17, {}),
    ("A felhasználó tanulja a spanyol nyelvet, hetente kétszer van órája", "knowledge", 17, {}),
    ("A felhasználó célja, hogy szeptemberig lefussa a félmaratont", "goals", 16, {}),
    ("A felhasználó kedvenc sportága az úszás", "health", 16, {}),
    ("A felhasználó a BME-n végzett informatikusként", "knowledge", 15, {}),
    ("A felhasználó szeret hegyet mászni, évente kétszer túrázik", "daily_life", 15, {}),
    ("A felhasználó macskája Mici-nek hívják, és 3 éves", "relationships", 14, {}),
    ("A felhasználó kontárja a Facebook felületét", "daily_life", 14, {}),
    ("A felhasználó vezetékneve Kiss", "knowledge", 13, {}),
    ("A felhasználó bérelt lakásban lakik a IX. kerületben", "daily_life", 13, {}),
    ("A felhasználó júliusban szabadságra megy Horvátországba", "goals", 12, {"stance": "future", "valid_from": "2026-07-01"}),
    ("A felhasználó allergiás a mákra", "health", 12, {}),
    ("A felhasználó kollégája Péter sokat segít neki a projektekben", "work", 11, {}),
    ("A felhasználó jelenleg egy raktárkezelő rendszert fejleszt", "work", 11, {}),
    ("A felhasználó hetente egyszer moziba jár", "daily_life", 10, {}),
    ("A felhasználó kedvenc filmje a Titanic", "knowledge", 10, {}),
    ("A felhasználó biciklivel jár be a munkahelyére", "daily_life", 9, {}),
    ("A felhasználó reggel 6-kor kel", "daily_life", 9, {}),
    ("A felhasználó este 10 után már nem dolgozik", "work", 8, {}),
    ("A felhasználó fehérborral koccint, ha ünnepel", "daily_life", 8, {}),
    ("A felhasználó sógora Németországban él", "relationships", 7, {}),
    ("A felhasználó sushi-t rendelt szombat este", "daily_life", 7, {}),
    ("The user's favourite coffee is a long coffee and they drink one every morning in Budapest", "daily_life", 21, {}),
    ("The user's best friend is called Tamas and they have known each other for 12 years", "relationships", 21, {}),
    ("A felhasználó barátnője Tamás, és 12 éve ismerik egymást", "relationships", 21, {}),
    ("The user works as a backend developer at a logistics company", "work", 20, {}),
    ("The user reads before bed every night", "daily_life", 19, {}),
    ("The user is allergic to poppy seeds", "health", 12, {}),
    ("A felhasználó gyerekkorában zongorázni tanult", "knowledge", 11, {}),
    ("A felhasználó nyaraláskor mindig könyvet visz magával", "daily_life", 10, {}),
    ("A felhasználó nyári szabadságát júliusban tölti", "goals", 9, {}),
    ("A felhasználó szeret borozni a barátaival péntek esténként", "relationships", 8, {}),
    ("A felhasználó bankja az OTP", "finance", 7, {}),
    ("A felhasználó befektetett egy részvénybe tavaly", "finance", 25, {"stance": "past"}),
    ("A felhasználó tavaly eladta a régi autóját", "finance", 24, {"stance": "past"}),
    ("A felhasználó vezetett egy Peugeot 308-at korábban", "finance", 24, {"stance": "past"}),
    ("A felhasználó fogorvoshoz készül jövő szerdán", "health", 2, {"stance": "future", "valid_from": "2026-09-24"}),
    ("A felhasználó szeretnéd megtanulni a gitáros alapokat", "goals", 5, {"stance": "uncertain"}),
    ("A felhasználó főnöke Gábor, és szigorú de korrekt", "work", 6, {}),
    ("A felhasználó csapatában öten dolgoznak", "work", 6, {}),
    ("A felhasználó egészségbiztosítása csoportos", "finance", 5, {}),
    ("A felhasználó havi 12000 forintot fizet a streaming szolgáltatásokért", "finance", 4, {}),
    ("A felhasználó húga Anna Pesten tanul pszichológiát", "relationships", 4, {}),
    ("A felhasználó nagyszülői Debrecenben élnek", "relationships", 3, {}),
    ("A felhasználó szeret futni a Duna-parton", "health", 3, {}),
    ("A felhasználó vásárolt egy új futócipőt múlt héten", "health", 3, {}),
    ("A felhasználó jelenleg a Q4-es riporton dolgozik", "work", 2, {}),
    ("A felhasználónak múlt csütörtökön megbeszélése volt a termékcsapattal", "work", 1, {}),
    ("A felhasználó tegnap későig dolgozott a hibajavításon", "work", 0, {}),
    ("A felhasználó ma reggel korán érkezett az irodába", "work", 0, {}),
    # a few filler/noise facts so the library has realistic volume
    ("A felhasználó elektromos fogkefét használ", "daily_life", 40, {}),
    ("A felhasználó kedvenc színe a zöld", "daily_life", 40, {}),
    ("A felhasználó progit ír a szabadidejében", "knowledge", 39, {}),
    ("A felhasználó tavaly Olaszországban nyaralt", "goals", 39, {"stance": "past"}),
    ("A felhasználó kedveli a tengerparti nyaralást", "goals", 38, {}),
    ("A felhasználó vezeték nélküli fülhallgatót használ", "daily_life", 38, {}),
    ("A felhasználó szülei nyugdíjasok", "relationships", 37, {}),
    ("A felhasználó nővére orvos", "relationships", 37, {}),
    ("A felhasználó szeret gyalogtúrázni a hegyekben", "daily_life", 36, {}),
    ("A felhasználó reggelente általában kenyeret eszik", "daily_life", 36, {}),
    ("A felhasználó januárban kezdte a jelenlegi munkáját", "work", 35, {}),
    ("A felhasználó Excel táblázatokat készít a riportokhoz", "work", 34, {}),
    ("A felhasználó virtualizációs rendszerekben jártas", "knowledge", 34, {}),
    ("A felhasználó részmunkaidőben egyetemista volt", "knowledge", 33, {"stance": "past"}),
    ("A felhasználó szívesen főz olasz ételeket", "daily_life", 33, {}),
    ("A felhasználó imádja a pizzát", "daily_life", 32, {}),
    ("A felhasználó barátaival rendszeresen kártyázik", "relationships", 32, {}),
    ("A felhasználó havi edzőbérlete 15000 forint", "finance", 31, {}),
    ("A felhasználó megtakarítása növekedésben van", "finance", 31, {}),
    ("A felhasználó sportolás előtt mindig bemelegít", "health", 30, {}),
    ("A felhasználó derékfájásra jár gyógytornászhoz", "health", 30, {}),
    ("A felhasználó tavasszal megbetegedett", "health", 45, {"stance": "past"}),
    ("A felhasználó influenzára volt karanténban februárban", "health", 45, {"stance": "past"}),
    ("A felhasználó okostelefonja Samsung", "daily_life", 44, {}),
    ("A felhasználó kedvenc zenekara az Illés", "knowledge", 44, {}),
    ("A felhasználó jazz koncertre készül", "goals", 43, {"stance": "future", "valid_from": "2026-10-10"}),
    ("A felhasználó úszástanfolyamra iratkozott fel ősszel", "goals", 43, {"stance": "future", "valid_from": "2026-10-01"}),
    ("A felhasználó szomszédja fontos ember a közösségben", "relationships", 42, {}),
    ("A felhasználó kertészkedik a nyaralóban", "daily_life", 42, {}),
    ("A felhasználó műveli a kertet májustól szeptemberig", "daily_life", 41, {}),
    ("A felhasználó szőlőt termel a kertben", "daily_life", 41, {}),
    ("A felhasználó borospincét épít tavaly óta", "daily_life", 28, {}),
    ("A felhasználó rendszeresen olvassa a HVG-t", "knowledge", 28, {}),
    ("A felhasználó érdeklődik a történelem iránt", "knowledge", 27, {}),
    ("A felhasználó podcasteket hallat munka közben", "daily_life", 27, {}),
    ("A felhasználó reggeli híreket hallgat útközben", "daily_life", 26, {}),
    ("A felhasználó vasárnaponként rendszeresen családi ebédet tart", "relationships", 26, {}),
    ("A felhasználó unokatestvére júliusban látogatta meg", "relationships", 25, {"stance": "past"}),
    ("A felhasználó születésnapja március 14.", "knowledge", 25, {}),
    ("A felhasználó neve Kiss Bence", "knowledge", 25, {}),
    ("A felhasználó beceneve Benci", "relationships", 24, {}),
    ("A felhasználó szüleivel vasárnap telefonál", "relationships", 24, {}),
    ("A felhasználó szívesen segít a beköltözőknek", "daily_life", 23, {}),
    ("A felhasználó tavassyan festette át a lakást", "daily_life", 23, {"stance": "past"}),
    ("A felhasználó budapesti kollégiumban lakott egyetemista korában", "knowledge", 22, {"stance": "past"}),
    ("A felhasználó érettségi után dolgozott egy évig", "knowledge", 22, {"stance": "past"}),
    ("A felhasználó diáksegédként dolgozott egyetemista korában", "work", 21, {"stance": "past"}),
    ("A felhasználó jelenlegi munkája a harmadik állása", "work", 20, {}),
    ("A felhasználó programozóként kezdte a pályafutását", "work", 20, {"stance": "past"}),
    ("A felhasználó céges laptopot használ", "work", 19, {}),
    ("A felhasználó irodája a harmadik emeleten van", "work", 19, {}),
    ("A felhasználó home office-t tesz hetente kétszer", "work", 18, {}),
    ("A felhasználó korán érkezik a megbeszélésekre", "work", 17, {}),
    ("A felhasználó jegyzetel a megbeszéléseken", "work", 17, {}),
    ("A felhasználó kedveli az online meetingeket", "work", 16, {}),
    ("A felhasználó esküvőre készül a barátjával", "relationships", 16, {"stance": "future", "valid_from": "2026-10-18"}),
    ("A felhasználó nyelvvizsgára készül spanyolból", "knowledge", 15, {"stance": "future", "valid_from": "2026-11-20"}),
    ("A felhasználó szeretné kipróbálni a vitorlázást", "goals", 15, {"stance": "uncertain"}),
    ("A felhasználó edzőtermi bérletét meghosszabbította szeptemberre", "health", 14, {"stance": "future", "valid_from": "2026-09-30"}),
    ("A felhasználó fogszakorvosi kontrollra októberben megy", "health", 13, {"stance": "future", "valid_from": "2026-10-15"}),
]

# occurrence counts: coffee fact seen 4x, allergy 3x (OCC-1 provenance signal)
OCCURRENCE = {
    0: 4,      # long coffee
    19: 3,     # poppy allergy
    31: 4,     # EN coffee dup
    35: 3,     # EN allergy dup
}

# --- supersession pair: old value + new value -----------------------------------
SUPERSEDED_PAIR = (
    ("A felhasználó kedvenc étterme a Belvárosi Étterem", "daily_life", 30),
    ("A felhasználó kedvenc étterme mostanában a Kisbuda Gyöngye", "daily_life", 3),
)

# --- right-brain: heartnotes (content, emotion, age_days) -----------------------
HEARTNOTES = [
    ("Nagyon elfáradtam a hetekben, de büszke vagyok magamra", "tired", 20),
    ("Úgy tűnik, a prezentáció előtti izgalommotiválja a felkészülést", "anxious", 18),
    ("A húga említése mindig mosolyt csal az arcára", "happy", 17),
    ("Úgy látszik, a pénzügyi célok miatt aggódik mostanában", "worried", 15),
    ("Az edzések után mindig jobb a hangulata", "happy", 13),
    ("Úgy tűnik, nehezen mond nemet a kollégáknak", "frustrated", 11),
    ("A szüleit említve nosztalgikus lett", "nostalgic", 9),
    ("A szabadság tervezése felvillanyozza", "excited", 8),
    ("A régi autó eladása után megkönnyebbült", "relieved", 7),
    ("A fogorvos említésénél feszült lett", "anxious", 5),
    ("Az új projekt lelkesíti a felhasználót", "excited", 4),
    ("A fáradtság ellenére hatékonyan dolgozott", "tired", 2),
    ("Ma reggel energikusnak tűnt", "happy", 0),
    ("A Q4 riport miatti feszültség érződik a hangján", "anxious", 2),
    ("A futás után mindig kiegyensúlyozottabb", "calm", 3),
    ("A testvérével való kapcsolata fontos neki", "warm", 6),
    ("A macskája említésekor ellágyul", "warm", 10),
    ("A bankszámla egyenlege miatt izgul", "worried", 12),
    ("A zongora emlékei boldoggá teszik", "nostalgic", 11),
    ("A hosszú értekezletek kimerítik", "frustrated", 16),
    ("Az olvasás kikapcsolja", "calm", 14),
    ("A nyaralás tervezése közben felenged", "relaxed", 9),
    ("A városi lásma ellenére szeret Budapesten élni", "content", 21),
    ("A céges változások miatt bizonytalan", "uncertain", 5),
    ("A baráti kártyaestek a hét fénypontjai", "happy", 7),
    ("Az anyukájával való beszélgetések megnyugtatják", "warm", 8),
    ("A kerti munka örömöt okoz neki", "content", 6),
    ("Az allergia miatt óvatos az ételekkel", "cautious", 4),
]

# --- right-brain traits (slot, claim, quote, age_days) --------------------------
TRAITS = [
    ("喜好与厌恶", "kedveli a strukturált munkát", "A listáim mindig kész vannak reggelre", 18),
    ("喜好与厌恶", "nem szeret nagy tömegben lenni", "Mindig a csendesebb helyet választom", 15),
    ("表达风格", "rövid, lényegretörő válaszokat prefersál", "Csak a lényeget mondd, légyszives", 12),
    ("表达风格", "szívesen viccelődik a beszélgetésekben", "Ezt most jó humorral kell venni", 9),
    ("思维模式", "döntései előtt listázza a tényezőket", "Minden szempontot leírok előbb", 14),
    ("思维模式", "problémákat szívesen darabokra bont", "Lépésenként haladjunk", 8),
    ("应对方式", "nyomás alatt is nyugodt marad", "Ilyenkor kell a hidegvér", 10),
    ("应对方式", "problémát látva azonnal megoldást keres", "Mit tehetünk most ellene?", 6),
    ("情绪", "a teljesítmény-nyomás kimutathatóan fárasztja", "Megint minden az én fejemen múlik", 4),
    ("情绪", "sikerélmény után felenged", "Sikerült! Menjünk el ünnepelni", 7),
    ("喜好与厌恶", "kedveli a korai reggeleket", "Reggel 6 a kedvenc időpontom", 20),
    ("情绪", "az anyja említésekor ellágyul", "Anyu mindig ezt mondaná", 11),
]


def seed(root: str, user_id: str = "voice_user") -> dict:
    from voicemem import VoiceMem

    def embedding_factory():
        from voicemem.leftbrain.local_e5_embedder import LocalE5Embedder
        return LocalE5Embedder()

    vm = VoiceMem(
        mode="text_mode",
        user_id=user_id,
        base_url=os.environ["OPENAI_BASE_URL"],
        top_k=5,
        memory_root=root,
        embedding=embedding_factory,
    )
    o = vm._o
    repo = o._get_repo()

    from voicemem.leftbrain.cognitive_graph.slot_v2 import SlotV2

    slot_map = {
        "work": SlotV2.WORK, "finance": SlotV2.FINANCE, "relationships": SlotV2.RELATIONSHIPS,
        "health": SlotV2.HEALTH, "goals": SlotV2.GOALS, "daily_life": SlotV2.DAILY_LIFE,
        "knowledge": SlotV2.KNOWLEDGE,
    }

    left_ids: list[str] = []
    for i, (text, slot, age, meta) in enumerate(FACTS):
        md = {"created_at": _d(age), "source": "audit-seed"}
        md.update(meta)
        ids = repo._vector_store.add_records_with_ids(
            user_id, [("", text, "user", md)])
        if ids:
            mid = ids[0]
            repo._cognitive_store.upsert_memory_record(user_id, mid, slot_map[slot], text)
            repo._cognitive_store.upsert_memory_tags(mid, user_id, [(slot, 0.9)])
            # occurrence count: the production counter is count_occurrence();
            # emulate repeated confirmation
            occ = OCCURRENCE.get(i, 1)
            if occ > 1:
                try:
                    repo._vector_store.count_occurrence(mid, observed_at=_d(max(0, age - 1)))
                    for _ in range(occ - 1):
                        repo._vector_store.count_occurrence(mid, observed_at=_d(1))
                except Exception:
                    pass
            left_ids.append(mid)

    # superseded pair (production shape: new row + metadata merge on old)
    old_text, old_slot, old_age = SUPERSEDED_PAIR[0]
    new_text, new_slot, new_age = SUPERSEDED_PAIR[1]
    old_ids = repo._vector_store.add_records_with_ids(
        user_id, [("", old_text, "user", {"created_at": _d(old_age), "source": "audit-seed"})])
    old_id = old_ids[0] if old_ids else ""
    new_ids = repo._vector_store.add_records_with_ids(
        user_id, [("", new_text, "user",
                   {"created_at": _d(new_age), "source": "audit-seed", "supersedes": old_id})])
    new_id = new_ids[0] if new_ids else ""
    if old_id and new_id:
        # mark old row superseded via metadata merge (production update path)
        try:
            repo._vector_store._mem0.update(memory_id=old_id, metadata={"superseded_by": new_id})
        except Exception as exc:
            print("supersede mark failed:", exc)
        repo._cognitive_store.upsert_memory_record(user_id, old_id, slot_map[old_slot], old_text)
        repo._cognitive_store.upsert_memory_record(user_id, new_id, slot_map[new_slot], new_text)
        repo._cognitive_store.upsert_memory_tags(old_id, user_id, [(old_slot, 0.9)])
        repo._cognitive_store.upsert_memory_tags(new_id, user_id, [(new_slot, 0.9)])

    # ---- right brain: heartnotes via the real store --------------------------
    from voicemem.rightbrain.types import MemoryAnchor
    from voicemem.rightbrain.anchor_router import normalize_emotion_strict

    rb_repo = o._right._rb_repo()
    heart_ids = []
    for content, emotion, age in HEARTNOTES:
        rb_mem = rb_repo._store.upsert_memory(
            user_id=user_id,
            memory_class="heartnote",
            content=content,
            metadata={"emotion": emotion, "entities": [], "left_memory_id": "",
                      "inner_os": "", "agent_reply": ""},
            evidence_memory_ids=[],
            created_at=_d(age),
        )
        canon = normalize_emotion_strict(emotion)
        if canon is not None:
            rb_repo._store.link_anchor(
                rb_mem.id, user_id,
                MemoryAnchor(anchor_type="emotion", anchor_id=canon,
                             role="trigger", weight=1.0, confidence=1.0))
        heart_ids.append(rb_mem.id)

    # ---- right brain: traits via the real TraitStore --------------------------
    from voicemem.rightbrain.traits_store import Evidence
    trait_ids = []
    for slot, claim, quote, age in TRAITS:
        tid = o._right._traits().add(
            user_id, slot, claim,
            Evidence(quote=quote, emotion="", cause="", cause_id="", at=_d(age)))
        if tid:
            trait_ids.append(tid)

    return {
        "user_id": user_id,
        "left_facts": len(left_ids),
        "superseded_pair": [old_id, new_id],
        "heartnotes": len(heart_ids),
        "traits": len(trait_ids),
    }


def seed_light(root: str, user_id: str = "voice_user", n_facts: int = 10) -> dict:
    """Light variant: right brain full, only the first n_facts left facts.

    Keeps the extraction prompt small (a few existing memories) so the ingest
    chain benchmark measures leg structure without the sandbox's ~50 t/s
    prefill cost dominating on a 9K-token prompt.
    """
    global FACTS
    full = FACTS
    FACTS = full[:n_facts]
    try:
        return seed(root, user_id)
    finally:
        FACTS = full


if __name__ == "__main__":
    root = sys.argv[1]
    uid = sys.argv[2] if len(sys.argv) > 2 else "voice_user"
    if len(sys.argv) > 3 and sys.argv[3] == "light":
        out = seed_light(root, uid, int(sys.argv[4]) if len(sys.argv) > 4 else 10)
    else:
        out = seed(root, uid)
    print("SEEDED:", out)
