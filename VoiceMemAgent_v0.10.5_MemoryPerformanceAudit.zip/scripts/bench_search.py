"""AUDIT-ONLY: memory READ-path latency benchmark (search pipeline).

Runs the REAL vendor Search() (facade -> Orchestrator.Search) against a seeded
memory root and decomposes latency into:
  * query preprocessing (expand_relative_dates + scene inference),
  * E5 query embedding,
  * Search() total + its internal phases (slot_filter / entity_narrow / rank / rb),
  * memory-context render (the web prompt block shape).

Reports P50/P95/P99/max. No production code is modified; wrappers are
process-local instrumentation only.

Usage: bench_search.py <memory_root> <out_json> [label]
"""
from __future__ import annotations

import json
import os
import statistics
import sys
import time
from pathlib import Path

AGENT = Path(__file__).resolve().parents[3] / "voicemem-agent"
os.environ.setdefault("VOICEMEM_E5_MODEL", str(AGENT / "models/embedding/multilingual-e5-small"))
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("OPENAI_BASE_URL", "http://127.0.0.1:8080/v1")
os.environ.setdefault("OPENAI_API_KEY", "audit-dummy")
os.environ.setdefault("OPENAI_MODEL", "audit-standin")
sys.path.insert(0, str(AGENT))

QUERIES = [
    "Milyen kávét iszom reggel?",
    "Mi a kedvenc éttermem?",
    "Kivel dolgozom együtt a projektben?",
    "Mikor van anyukám születésnapja?",
    "Mire vagyok allergiás?",
    "Hol lakik a húgom?",
    "Mi a célom szeptemberre?",
    "Mikor megyek fogorvoshoz?",
    "Mennyi a havi keretem?",
    "Mi a főnököm neve?",
    "Milyen nyelvet tanulok?",
    "Hogy hívják a macskámat?",
    "Mikor megyek szabadságra?",
    "Mit csináltam tegnap?",
    "Milyen betegségem volt tavasszal?",
    "Mi a kedvenc filmem?",
    "Kivel töltöm a vasárnapokat?",
    "Milyen autóm volt korábban?",
    "Mikor kezdtem a jelenlegi munkámat?",
    "Mi a becenevem?",
    "Mit szoktam csinálni péntek esténként?",
    "Mire spórolok most?",
    "Milyen sportokat űzök?",
    "Hol nyaraltam tavaly?",
    "Mi a legfontosabb találkozóm ezen a héten?",
    "Hányan vannak a csapatomban?",
    "Milyen zenéket hallgatok szívesen?",
    "Mit tudok a spanyol tanulmányaimról?",
    "Which report did I finish last week?",
    "What coffee do I drink every morning?",
]

NEUTRAL = ["qwertyuiop asdfgh", "teljesen semleges mondat időjárásról"]

WARMUP = 4
RUNS = 32


def rss_mb() -> float:
    with open("/proc/self/status") as f:
        for line in f:
            if line.startswith("VmRSS:"):
                return int(line.split()[1]) / 1024.0
    return -1.0


def cpu_times():
    with open("/proc/self/stat") as f:
        p = f.read().split()
    return int(p[13]) + int(p[14]), int(p[15]) + int(p[16])  # utime+stime, cutime+cstime


def pct(sorted_vals, p):
    if not sorted_vals:
        return None
    idx = min(len(sorted_vals) - 1, max(0, int(round(p / 100.0 * (len(sorted_vals) + 1))) - 1))
    return sorted_vals[idx]


def stats_block(vals):
    s = sorted(vals)
    return {
        "n": len(vals),
        "mean": round(statistics.fmean(vals), 2) if vals else None,
        "p50": pct(s, 50), "p95": pct(s, 95), "p99": pct(s, 99),
        "min": round(min(vals), 2) if vals else None,
        "max": round(max(vals), 2) if vals else None,
    }


def main() -> None:
    root = sys.argv[1]
    out_path = sys.argv[2]
    label = sys.argv[3] if len(sys.argv) > 3 else root

    from voicemem import VoiceMem

    def embedding_factory():
        from voicemem.leftbrain.local_e5_embedder import LocalE5Embedder
        return LocalE5Embedder()

    t0 = time.perf_counter()
    vm = VoiceMem(
        mode="text_mode", user_id="voice_user",
        base_url=os.environ["OPENAI_BASE_URL"], top_k=5,
        memory_root=root, embedding=embedding_factory,
    )
    facade_construct_s = time.perf_counter() - t0
    rss_after_facade = rss_mb()

    # preload shared E5 (first search pays the model load otherwise)
    from voicemem.leftbrain.local_e5_embedder import shared_e5
    t0 = time.perf_counter()
    shared_e5()
    e5_load_s = time.perf_counter() - t0
    rss_after_e5 = rss_mb()

    from voicemem.leftbrain.time_expand import expand_relative_dates
    from voicemem.utils.audio.environment.scene_classifier import infer_scene_from_text

    from app.web_server import clean_rb_content, hit_provenance_suffix  # the real render helpers
    from app.retrieval_contract import trait_prompt_suffix

    def render_memory_context(result):
        if result is None:
            return ""
        parts = []
        for h in (getattr(result, "hits", None) or [])[:5]:
            t = (getattr(h, "text", "") or "").strip()
            if t:
                parts.append(f"- {t}{hit_provenance_suffix(h)}")
        for h in (getattr(result, "rb_hits", None) or [])[:3]:
            t = clean_rb_content(getattr(h, "content", "") or "").strip()
            if t:
                parts.append(f"- {t}{trait_prompt_suffix(h)}")
        return "\n".join(parts)[:1200]

    # ---- first (cold) search ------------------------------------------------
    t0 = time.perf_counter()
    first = vm.search(QUERIES[0])
    first_search_s = time.perf_counter() - t0

    # ---- warm-up ------------------------------------------------------------
    for q in QUERIES[:WARMUP]:
        vm.search(q)

    # ---- measured runs ------------------------------------------------------
    rows = []
    all_queries = QUERIES + NEUTRAL
    for i in range(RUNS):
        q = all_queries[i % len(all_queries)]
        t_pre0 = time.perf_counter()
        expanded = expand_relative_dates(q)
        scene = infer_scene_from_text(q)
        t_pre = (time.perf_counter() - t_pre0) * 1000.0

        t_e50 = time.perf_counter()
        from voicemem.leftbrain.local_e5_embedder import LocalE5Embedder
        LocalE5Embedder().embed_query_text(expanded)
        t_e5 = (time.perf_counter() - t_e50) * 1000.0

        c0, _ = cpu_times()
        t_s0 = time.perf_counter()
        result = vm.search(q)
        t_search = (time.perf_counter() - t_s0) * 1000.0
        cpu, _ = cpu_times()
        cpu_ms = (cpu - c0) * (1000.0 / os.sysconf("SC_CLK_TCK"))

        t_r0 = time.perf_counter()
        ctx = render_memory_context(result)
        t_render = (time.perf_counter() - t_r0) * 1000.0

        tim = getattr(result, "timing", None) or {}
        rows.append({
            "query": q,
            "preprocess_ms": round(t_pre, 2),
            "e5_embed_ms": round(t_e5, 2),
            "search_total_ms": round(t_search, 2),
            "search_cpu_ms": round(cpu_ms, 2),
            "render_ms": round(t_render, 2),
            "ctx_chars": len(ctx),
            "n_hits": len(getattr(result, "hits", None) or []),
            "n_rb_hits": len(getattr(result, "rb_hits", None) or []),
            "internal": tim,
        })

    # e2e "memory stage" per the product definition: preprocess+embed happen
    # INSIDE search() too (Rank embeds internally), so the stage total IS
    # search_total_ms; report render as the additional formatting cost.
    out = {
        "label": label,
        "facade_construct_s": round(facade_construct_s, 3),
        "e5_load_s": round(e5_load_s, 3),
        "first_search_s": round(first_search_s, 3),
        "rss_mb_after_facade": round(rss_after_facade, 1),
        "rss_mb_after_e5": round(rss_after_e5, 1),
        "rss_mb_end": round(rss_mb(), 1),
        "runs": RUNS,
        "warmup": WARMUP,
        "latency": {},
        "internal_phases": {},
        "rows": rows,
    }
    for key in ("preprocess_ms", "e5_embed_ms", "search_total_ms", "search_cpu_ms",
                "render_ms", "ctx_chars", "n_hits", "n_rb_hits"):
        out["latency"][key] = stats_block([r[key] for r in rows])
    for phase in ("slot_filter_ms", "entity_narrow_ms", "rank_ms", "rb_ms", "total_ms"):
        vals = [float(r["internal"].get(phase, 0.0)) for r in rows if r["internal"]]
        out["internal_phases"][phase] = stats_block(vals)

    Path(out_path).write_text(json.dumps(out, indent=1, ensure_ascii=False))
    print(json.dumps({k: v for k, v in out.items() if k not in ("rows",)}, indent=1, ensure_ascii=False))


if __name__ == "__main__":
    main()
