"""AUDIT-ONLY: the foreground-blocking special investigation + E5 contention.

Experiment A (the user's question: can a memory operation make the CURRENT
conversational response wait?):
  A1. A NON-STREAMING LLM leg — the exact transport used by the vendor's
      un-cancellable legs (_llm_json / _generate_inner_os / run_cleanup) —
      is started; 2 s later the cooperative-cancel event is SET (exactly what
      BackgroundMemoryGate.arm() does); a user-shaped streaming request fires
      immediately after. We measure user TTFT.
  A2. The same, but the leg runs through bg_chat_create (the cancellable
      transport used by extraction + conflict-resolution): the cancel closes
      the stream; measure user TTFT.
  A3. Baseline: user TTFT with nothing else on the slot.

Experiment B (memory-level contention, no LLM): search latency while a
background thread runs E5 batch embeds (the ingest chain's store-side work).

Usage: bench_concurrency.py <out_json>
"""
from __future__ import annotations

import json
import os
import statistics
import sys
import threading
import time
from pathlib import Path

AGENT = Path(__file__).resolve().parents[3] / "voicemem-agent"
os.environ.setdefault("VOICEMEM_E5_MODEL", str(AGENT / "models/embedding/multilingual-e5-small"))
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("OPENAI_BASE_URL", "http://127.0.0.1:8080/v1")
os.environ.setdefault("OPENAI_API_KEY", "audit-dummy")
os.environ.setdefault("OPENAI_MODEL", "audit-standin")
sys.path.insert(0, str(AGENT))

from openai import OpenAI  # noqa: E402

USER_MSG = [{"role": "user", "content": "Szia! Röviden: mi a kedvenc kávém?"}]
LEG_MSG = [{"role": "user", "content": "Summarise this for memory. " + ("adat " * 400)}]


def user_ttft(client, timeout=240.0) -> float:
    """Fire a user-shaped streaming request; return TTFT (first content delta)."""
    t0 = time.perf_counter()
    s = client.chat.completions.create(
        model="u", messages=USER_MSG, max_tokens=48, stream=True, temperature=0.7)
    try:
        for ch in s:
            if ch.choices and getattr(ch.choices[0].delta, "content", None):
                return time.perf_counter() - t0
    finally:
        try:
            s.close()
        except Exception:
            pass
    return time.perf_counter() - t0


def main() -> None:
    out_path = sys.argv[1]
    mode = sys.argv[2] if len(sys.argv) > 2 else "all"
    client = OpenAI(api_key="audit-dummy", base_url=os.environ["OPENAI_BASE_URL"], timeout=240.0)

    results: dict = {"A_baseline": [], "A1_nonstream_uncancellable": [],
                     "A2_stream_cancel": [], "notes": []}

    if mode in ("all", "llm"):
        # ---- A3 baseline (slot idle) --------------------------------------------
        for _ in range(3):
            results["A_baseline"].append(round(user_ttft(client), 3))
        print("baseline TTFT:", results["A_baseline"], flush=True)

        # ---- A1: non-streaming leg + cancel set mid-leg -------------------------
        for trial in range(3):
            leg_done = threading.Event()

            def leg_nonstream():
                t0 = time.perf_counter()
                # exact shape of the vendor's _llm_json / inner-OS legs:
                # non-streaming create, runs to natural completion
                r = client.chat.completions.create(
                    model="bg", messages=LEG_MSG, max_tokens=300, temperature=0.7,
                    timeout=240.0)
                results.setdefault("A1_leg_wall", []).append(round(time.perf_counter() - t0, 3))
                leg_done.set()

            t = threading.Thread(target=leg_nonstream, daemon=True)
            t.start()
            time.sleep(2.0)  # the user starts speaking mid-leg
            # exactly what BackgroundMemoryGate.arm() does:
            import voicemem.utils.common.llm_bg_gate as gate
            gate.set_cancel("bench-arm")
            ttft = user_ttft(client)
            gate.clear_cancel("bench-done")
            results["A1_nonstream_uncancellable"].append(round(ttft, 3))
            print(f"A1 trial {trial+1}: user TTFT={ttft:.3f}s (leg still running: "
                  f"{not leg_done.is_set()})", flush=True)
            t.join(timeout=240)

        # ---- A2: cancellable streaming leg (bg_chat_create transport) ------------
        import voicemem.utils.common.llm_bg_gate as gate
        from voicemem.utils.common.llm_bg_gate import bg_chat_create

        for trial in range(3):
            leg_done = threading.Event()
            cancelled = threading.Event()

            def leg_stream():
                t0 = time.perf_counter()
                try:
                    bg_chat_create(
                        client, leg="bench-extraction",
                        model="bg", messages=LEG_MSG, temperature=0.7, max_tokens=300)
                except Exception as exc:
                    results.setdefault("A2_cancel_class", []).append(type(exc).__name__)
                    cancelled.set()
                results.setdefault("A2_leg_wall", []).append(round(time.perf_counter() - t0, 3))
                leg_done.set()

            t = threading.Thread(target=leg_stream, daemon=True)
            t.start()
            time.sleep(2.0)
            gate.set_cancel("bench-arm")
            ttft = user_ttft(client)
            gate.clear_cancel("bench-done")
            t.join(timeout=30)
            results["A2_stream_cancel"].append(round(ttft, 3))
            print(f"A2 trial {trial+1}: user TTFT={ttft:.3f}s "
                  f"(cancelled={cancelled.is_set()})", flush=True)

    if mode in ("all", "e5"):
        # ---- B: search latency under background E5 batch embed ------------------
        from voicemem import VoiceMem

        def ef():
            from voicemem.leftbrain.local_e5_embedder import LocalE5Embedder
            return LocalE5Embedder()

        vm = VoiceMem(mode="text_mode", user_id="voice_user",
                      base_url=os.environ["OPENAI_BASE_URL"], top_k=5,
                      memory_root="/tmp/vm-audit/root-seeded", embedding=ef)
        vm.search("warm up")

        def search_once():
            t0 = time.perf_counter()
            vm.search("Milyen kávét iszom reggel?")
            return (time.perf_counter() - t0) * 1000.0

        idle = [search_once() for _ in range(5)]

        stop = threading.Event()
        embed_times: list[float] = []

        def embed_worker():
            from voicemem.leftbrain.local_e5_embedder import LocalE5Embedder
            e5 = LocalE5Embedder()
            batch = [f"passage: A felhasználó #{i} megfigyelése a kávéivási szokásairól és a napi rutinról"
                     for i in range(12)]
            while not stop.is_set():
                t0 = time.perf_counter()
                e5.embed_texts(batch)
                embed_times.append((time.perf_counter() - t0) * 1000.0)

        wt = threading.Thread(target=embed_worker, daemon=True)
        wt.start()
        time.sleep(0.3)  # let the worker get going
        busy = [search_once() for _ in range(5)]
        stop.set(); wt.join(timeout=5)

        results["B_e5_contention"] = {
            "search_idle_ms": [round(x, 1) for x in idle],
            "search_under_embed_ms": [round(x, 1) for x in busy],
            "idle_p50": round(statistics.median(idle), 1),
            "busy_p50": round(statistics.median(busy), 1),
            "embed_batch_ms_p50": round(statistics.median(embed_times), 1) if embed_times else None,
            "n_embed_batches": len(embed_times),
        }
        print(json.dumps(results["B_e5_contention"], indent=1), flush=True)

    def stats_block(vals):
        if not vals:
            return {}
        s = sorted(vals)
        return {"n": len(vals), "min": round(min(vals), 3), "p50": round(statistics.median(vals), 3),
                "max": round(max(vals), 3)}

    Path(out_path).write_text(json.dumps({
        "results": results,
        "stats": {
            "A_baseline": stats_block(results["A_baseline"]),
            "A1_nonstream_uncancellable": stats_block(results["A1_nonstream_uncancellable"]),
            "A2_stream_cancel": stats_block(results["A2_stream_cancel"]),
        },
        "method": {
            "leg_prompt": "~420 tokens, max_tokens=300, temperature 0.7",
            "user_prompt": "short chat question, max_tokens=48, streaming",
            "cancel_set_at": "2.0s after leg start (BackgroundMemoryGate.arm() analogue)",
        },
    }, indent=1, ensure_ascii=False))
    print("DONE")


if __name__ == "__main__":
    main()
