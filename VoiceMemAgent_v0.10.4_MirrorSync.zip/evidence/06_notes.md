# v0.10.4 MirrorSync — engineering notes (2026-09-17)

## Procedure source

The v0.10.2/v0.10.3 worklog entries (Task v0102-mirror-sync /
v0103-upstreamaudit "MIRROR:" line) document the established procedure;
this package follows it: PAT re-supplied by the operator (sandbox state
restore wipes /home/z/.github_sync/), token check first, dry-run before
the push, two-push pattern (release push → evidence package → evidence
push), fresh anonymous clone verification after each.

## Pre-commit hygiene (release commit 6d6cd8b)

- 45 modified paths classified: (a) REAL — voicemem-agent release
  metadata (CHANGELOG/VERSION/pyproject/config yaml/web PAGE_VERSION,
  RELEASE_INDEX/BUILD_HISTORY, build_release_sandbox.py v0.10.4 update)
  + new public artifacts + recovery/v0104 + audit/VoiceMEM_forensic_v0104
  + worklog + screenshots; (b) MODE-ONLY — 18 paths (644→755, the
  documented sandbox-restore mode-drift class) restored via
  `git checkout --` after content verification (text: git diff shows no
  hunks; binaries: `git hash-object` == index blob — the v0.10.3 zips,
  screenshots, audit/ + recovery/v0103 trees); (c) runtime —
  .zscripts/dev.pid + tool-results/voicemem-src left uncommitted.
- The models/hf E5 README typechange (tracked symlink → regular file) was
  COMMITTED deliberately: the materialized file is byte-identical to the
  original blob (git hash-object == e56327af…), and the blobs/ directory
  no longer exists in the restored worktree — `git checkout` would
  recreate a DANGLING symlink and lose the model card from the tree.
  Committing the regular file is the content-preserving action.
- Tracked runtime snapshots (logs/web-server.log +238,
  data/emotion_demo_log.jsonl +9 — the v0.10.4 gate-run trail, incl. the
  new forensic log lines) were committed per the c235ea1/f6d826a
  precedent.

## Resurrected-public quarantine (scope guard)

The sandbox state restore resurrected 14 pre-v0.8 evidence zips + their
sidecars in public/ (v0.5.0 GitHubSync/MirrorCheck/SyncSetup/
Verification, v0.5.1 ForensicTrace/Task2Gate, v0.5.2 MemorySafetyGate,
v0.6.0 ASRGate/LLMConfig_ngl20-c32768/Recovery, v0.6.1 ASRHotfix,
v0.6.2 PinHotfix, v0.7.0 TTSMigration, llmconfig_v072_recovery). The
sync script's pattern set (VoiceMemAgent_v<ver>_<suffix>.zip +
VoiceMem_*_recovery.zip) would have pushed all of them as unreviewed
extras in this release push. They were NOT deleted: moved (tracked-guard
verified — all were untracked) to .resurrected-public-archive/ with an
SHA256SUMS.archive manifest; all 14 zips hash-match their sidecars
(verified case-insensitively; the v0.6.0 LLMConfig sidecar carries a
historical literal-\n filename bug). This keeps PUSH 1 exactly to the
briefed release set; whether the historical v0.5.x–v0.7.x evidence
packages join the mirror is an explicit operator decision, not an
accident of a state restore.

## gen_readme stale-metadata fix (the v0.10.2-established class)

The script's hardcoded "verification story" section still carried
v0.10.2 gate numbers (1386 / 0-reg / 28 skipped / 6 env-gap,
fingerprint 768cc7b5…) — the mirror README said "Latest stable release:
v0.10.4" but "Test gate (v0.10.2 release gate)". Replaced with the
authoritative v0.10.4 record from releases/RELEASE_INDEX.json:
1436 passed / 0 regressions / 29 skipped (7 pinned sandbox env-gap),
deep PASS [embedding, memory, memory-semantics, release, runtime-deps],
fingerprint 70ba38d8…c51ff. Vendor ledger range corrected to
VM-LOCAL-001…021 + EN (22 entries) with query-gated recency named;
vendor file count re-measured vs the pinned upstream copy:
still 24 files (21 modified + 3 added).

## source/tools/forensic (scope note, operator flag)

PUSH 1's source/ update carried tools/forensic/ (5 files:
CAPTURE_START.bat, REPLAY_CAPTURED_TURN.bat, README_FORENSIC.md,
llm_latency_forensics.py, llm_runtime_forensic_report.stage3.md — the
self-documented TEMPORARY latency-investigation helpers, untracked in
the local repo but present on disk inside voicemem-agent/). The
standing source-tree policy (CD-6 fix, since 2026-09-10) syncs the
on-disk first-party tree, so they entered the mirror; the additive
golden rule forbids removing them again. Flagged for the operator:
the delete-after-investigation decision (stage-1 flag) now has a
mirror dimension.

## Sync run mechanics

Foreground run + VOICEMEM_SYNC_WORKDIR=/home/z/mirror-sync (stable
workdir mode: the clone survives a killed run and a later run resumes
the push; git push is atomic, the remote is never partial). No detached
(nohup/setsid) launches — the v0.10.2-documented detached-death class.
This run: anonymous clone + push both succeeded on the FIRST attempt.
Push range 5a0f03b..0ccb533; the script's own push output is piped
through its redact() sed — the stored 03 log contains no token material.

## Package layout note

This package follows the FULL v0.10.2 MirrorSync layout
(RECOVERY.md + identity.json + evidence/01–06 + SHA256SUMS at zip
root). The v0.10.3 MirrorSync package was a slimmed variant
(evidence/03–05 + SHA256SUMS only); the full layout restores the
golden-rule deliverable set (RECOVERY.md + identity.json + evidence).
