# VoiceMemAgent v0.10.4 — MirrorSync evidence package

**What this is:** the golden-rule deliverable of the 2026-09-17 GitHub
mirror sync that published the **v0.10.4** release (the forensic-logging
release: additive gate ARMED/RELEASED/OPEN/INGEST-STARTED +
emotion-prosody diag lines; `llm_slot_forensic` schema 2 + S8 offline
product-log correlation) to https://github.com/AGE-T/VoiceMEM. It
documents that the mirror is a byte-identical, additive distribution of
the locally produced artifacts.

**Pre-sync state:** mirror HEAD `5a0f03b` — v0.10.3 fully mirrored
(product zip + recovery + MirrorSync evidence), **v0.10.4 missing**.
**Post-sync state:** mirror HEAD `0ccb533` — `VoiceMemAgent_v0.10.4.zip`
(SHA-256 `90B827046B19418538E9FC69E2F546D560483FF51FA268C876336570B1109F55`,
2,861,793 bytes, 367 staged files), `VoiceMem_forensic_v0104_recovery.zip`
(`514ecdd8010e78efcc6c5cd1dd31b062c41b6a8d85019882fa597a442274842c`),
a regenerated README ("Latest stable release: v0.10.4" with the
authoritative v0.10.4 gate numbers — 1436/0-reg/29-skip/7-env-gap,
fingerprint `70ba38d8…c51ff`), and the updated v0.10.4 first-party
source tree under `source/`.

## Verify (independent, no trust needed)

```bash
git clone https://github.com/AGE-T/VoiceMEM.git vmirror
cd vmirror
sha256sum VoiceMemAgent_v0.10.4.zip VoiceMem_forensic_v0104_recovery.zip
# expected:
#   90b827046b19418538e9fc69e2f546d560483ff51fa268c876336570b1109f55  VoiceMemAgent_v0.10.4.zip
#   514ecdd8010e78efcc6c5cd1dd31b062c41b6a8d85019882fa597a442274842c  VoiceMem_forensic_v0104_recovery.zip
grep -m1 "Latest stable release" README.md   # -> v0.10.4
grep -m1 "1436 passed"         README.md     # -> the v0.10.4 gate line
git log --oneline -1                          # -> 0ccb533 sync: VoiceMemAgent_v0.10.4.zip, …
```

Package contents: `identity.json`, `evidence/01…06` (token-permission
check — redacted; pre-push dry-run; push log; fresh-anonymous-clone
verification with VERDICT: PASS; mirror git log; engineering notes),
`SHA256SUMS` (self-verifying).

## Re-syncing / recovery

The standing policy (owner, 2026-09-10): every update (new release +
evidence packages) goes to the GitHub mirror automatically via
`scripts/sync_github_mirror.sh`:

```bash
# token at /home/z/.github_sync/AGE-T_VoiceMEM.token (chmod 600)
scripts/sync_github_mirror.sh --check                            # dry-run
VOICEMEM_SYNC_WORKDIR=/home/z/mirror-sync scripts/sync_github_mirror.sh
```

The stable-workdir mode lets a killed run resume by pushing the
already-built local commit; the sync is additive-only and idempotent;
`git push` is atomic, so the remote is never partial. This very package
is published by the follow-up push (the established two-push pattern);
the mirror HEAD after that push is recorded in the worklog and in the
download page's mirror badge.

## Rollback / provenance

The mirror only ever moves FORWARD additively; there is nothing to roll
back (no file is ever deleted by the sync). The product rollback anchor
is `VoiceMem_forensic_v0104_recovery.zip` (this release's own recovery
package, mirrored in the same push).
