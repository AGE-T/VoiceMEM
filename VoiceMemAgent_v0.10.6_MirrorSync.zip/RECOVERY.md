# VoiceMemAgent v0.10.6 — MirrorSync evidence package

**What this is:** the golden-rule deliverable of the 2026-09-20 GitHub
mirror sync that published the **v0.10.6** release (the edac5c9 TTS
leading-neutral absorption fix properly released through the v0.8.1
gate-order) to https://github.com/AGE-T/VoiceMEM. It documents that the
mirror is a byte-identical, additive distribution of the locally
produced artefacts.

**Pre-sync state:** mirror HEAD `4cf11af` — the consolidated 0.10.5
audit sync (five audit reports + worklog, pushed 2026-09-20); the
v0.10.6 artefacts did not exist yet.

**Post-sync state:** mirror HEAD `dae46e4` —
`VoiceMemAgent_v0.10.6.zip` (SHA256
A310E679F5F6C1A3043F0DB736607DAB3691410B80CDBFA8CEB00E9864046CCC),
`VoiceMemAgent_v0.10.6_recovery.zip` (SHA256
93BE0B264F0BFAD12D91E283659DA421836B4985E4EFD8DCFBD04D9E7BC37B58),
the regenerated README (v0.10.6 as the latest stable release) and the
`source/` tree at the 0.10.6 release state (VERSION, CHANGELOG entry,
the text_utils fix, the BUILD_INFO housekeeping, the V0106 builder
markers).

**Verification:** anonymous fresh clone at `dae46e4` — both new ZIPs
byte-identical (SHA-256 table in evidence/04), the README metadata
correct, the source tree carrying the release identity. Token hygiene:
the fine-grained PAT never appears in any repo file, log, or evidence
artefact.

**Contents:** `evidence/01_token_check.txt` (redacted token check),
`evidence/02_dryrun.txt` (pre-push dry-run + post-push re-check),
`evidence/03_push_log.txt` (push `4cf11af..dae46e4`),
`evidence/04_fresh_clone_verification.txt` (byte-identity proof),
`evidence/05_mirror_git_log.txt` (mirror history), `evidence/06_notes.md`,
`identity.json`.
