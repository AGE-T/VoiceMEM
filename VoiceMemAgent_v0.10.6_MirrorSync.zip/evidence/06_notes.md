# v0.10.6 MirrorSync notes

- This is the FIRST mirror sync after the consolidated 0.10.5 audit
  (mirror HEAD moved 4cf11af -> dae46e4).
- The sync set is governed by scripts/sync_github_mirror.sh (standing
  policy: every update goes to the GitHub mirror; additive only).
- The v0.10.6 product ZIP is the release of the edac5c9 TTS
  leading-neutral absorption fix; the gate record (GREEN, 1521 tests,
  0 regressions) ships inside the ZIP and the recovery package carries
  the fingerprint-bound evidence.
- Token hygiene: the fine-grained PAT is env-file-only
  (/home/z/.github_sync/AGE-T_VoiceMEM.token, chmod 600); it never
  appears in any repo file, log, or evidence artefact (grep-verified
  after every run).
- Anonymous fresh-clone verification: PASS (see 04).
