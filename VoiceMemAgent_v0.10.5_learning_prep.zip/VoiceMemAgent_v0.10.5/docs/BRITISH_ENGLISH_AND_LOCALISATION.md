# British English and Localisation Contract

Status: Active engineering requirement
Scope: VoiceMemAgent product-owned source, UI labels, logs, prompts, documentation and test fixtures

## 1. Goal

All product-facing static terminology shall be consistently written in British English.

Asian-script labels currently present in the VoiceMem codebase must not appear in product UI, logs, prompts, runtime labels or product-owned documentation.

This is a localisation requirement, not an instruction to alter arbitrary user utterances or model/input data.

## 2. Canonical Memory Labels

The following VoiceMem memory labels are canonical British-English product terminology:

| Existing label | Canonical English label |
|---|---|
| `喜好与厌恶` | `likes and dislikes` |
| `表达风格` | `expression style` |
| `思维模式` | `thinking style` |
| `应对方式` | `coping style` |
| `情绪` | `emotion` |

The canonical labels above must be used consistently in UI, logging and product-owned runtime formatting.

## 3. Required Audit

Scan the complete project for Asian-script characters, including but not limited to:

- Han / CJK ideographs
- Japanese Hiragana / Katakana
- Korean Hangul
- CJK punctuation when used as product text

Classify every match as one of:

1. Product-owned runtime/UI text — must be translated and removed.
2. Product-owned source comments/docstrings — translate to British English.
3. Product-owned tests/fixtures — translate unless the test explicitly exists to validate multilingual input handling.
4. Historical evidence / immutable forensic artefacts — may remain only when required to preserve evidence; document the exception.
5. Third-party / vendored code or model assets — do not silently modify upstream assets. Document the remaining occurrences and keep product-facing wrappers English.
6. User-generated or model-generated content — do not mutate content merely to satisfy this static localisation rule.

The final audit must report all remaining occurrences and their classification.

## 4. British English Rules

Use British spelling and terminology throughout product-owned text, including for example:

- behaviour, not behavior
- organisation, not organization
- analyse, not analyze
- optimise, not optimize
- modelling, not modeling
- centre, not center
- licence for the noun; license only where technically required by a proper licence name or external identifier
- favourite, not favorite

Do not rewrite technical identifiers, package names, API names, model names or upstream licence titles merely to force British spelling.

## 5. Required Validation

Add a repository audit test or deterministic scanner which:

- scans product-owned source/UI/docs/test paths;
- detects Asian-script characters;
- fails on newly introduced product-owned occurrences;
- allows explicitly documented evidence and vendored exclusions;
- checks the canonical five memory labels are present in English form and absent from product-owned runtime label maps.

## 6. Regression Requirements

The localisation change must not alter:

- memory slot semantics;
- retrieval semantics;
- trait identifiers used as stable internal keys unless a compatibility migration is explicitly implemented;
- VoiceMem persistence formats;
- LLM/ASR/TTS behaviour;
- user-generated memory content;
- evidence needed for forensic reproduction.

Where stable internal keys currently use the old labels, preserve compatibility internally and expose only the English presentation label. Do not silently break historical data.
