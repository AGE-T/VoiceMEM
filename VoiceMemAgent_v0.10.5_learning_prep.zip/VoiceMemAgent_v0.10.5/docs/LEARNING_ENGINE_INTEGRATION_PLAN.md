# VoiceMem ↔ MAXIM Learning Engine Integration Plan

Status: Architecture proposal / implementation preparation
Scope: VoiceMem v0.10.5 + MAXIM V4 Learning Engine
Owner: Architecture

## 1. Purpose

This document defines how the existing VoiceMem memory system shall connect to the MAXIM Learning Engine without creating a second competing memory system.

The core architectural decision is:

- **VoiceMem is the evidence and experience layer.**
- **The Learning Engine is the learning, validation, approval and mutation layer.**
- **The Knowledge Bundle is the canonical persistent knowledge boundary consumed by MAXIM.**

VoiceMem remains responsible for remembering what happened. The Learning Engine decides whether observed evidence represents knowledge worth proposing and, after authorisation, mutates the canonical Knowledge Bundle.

## 2. Existing Architecture We Should Preserve

MAXIM already defines a controlled learning lifecycle:

Observation
→ Candidate Knowledge
→ Validation
→ Learning Proposal
→ User Decision
→ Knowledge Mutation
→ Knowledge Bundle Update
→ Version Creation

Persistent user knowledge has one writer: the Learning Engine.

VoiceMem must therefore remain read-only from the Learning Engine's perspective. It supplies evidence; it does not become an alternative writer of MAXIM knowledge.

## 3. Responsibility Split

| Layer | Primary question |
|---|---|
| VoiceMem | What happened before? What evidence do we have? |
| Learning Adapter | Which VoiceMem evidence is relevant to learning? |
| Learning Engine | Is there enough evidence to form a candidate and should we propose it? |
| Knowledge Bundle | What persistent knowledge is currently canonical? |
| Parser / Knowledge Base | What language pattern is present and what goal may it represent? |
| Goal Resolver | What does the user want now? |
| Planner | What should the system do? |
| Home Assistant Gateway | How is the approved plan executed? |

## 4. VoiceMem Capabilities Available as Learning Evidence

The existing VoiceMem work provides a strong evidence foundation, including:

- facts and episodic memories
- temporal information and recency
- occurrence counts
- confidence and evidence
- traits and preferences
- stance and supersession
- corrections
- routines
- relationships / graph information
- emotional context
- response experience signals
- historical versus current state

These should not automatically become persistent operational knowledge. They are evidence sources.

## 5. Proposed Learning Event Contract

Introduce a stable boundary object between VoiceMem and the MAXIM Learning Engine.

```text
LearningEvent

id
user_id
session_id
observed_at
source
source_memory_ids
source_turn_ids

event_type

subject
context
observation
evidence[]

candidate_type
candidate_value
confidence
status
```

Initial `event_type` values should include:

- `repeated_phrase`
- `repeated_alias`
- `correction`
- `preference_signal`
- `execution_outcome`
- `response_feedback`
- `routine_signal`

The contract is an interface only. It must not grant the Learning Adapter write access to the Knowledge Bundle.

## 6. Learning Knowledge Types

The learning architecture should grow around explicit knowledge types rather than a single generic memory record.

Initial types:

- Alias
- Phrase → Goal mapping
- Preference
- Correction
- Constraint

Later types:

- Outcome policy
- Procedure
- Routine
- Skill
- Response policy
- User terminology

Evidence and knowledge are deliberately different objects.

## 7. Important Gap: Outcome Learning

One of the most valuable future learning sources is the complete chain:

User request
→ Goal
→ Plan
→ Execution
→ Result
→ User feedback
→ Outcome

Example:

```text
Goal: increase_temperature
Execution: set living room to 22°C
Result: Home Assistant success
User feedback: "Ez túl meleg."
```

The system should record this as evidence first. Repeated, validated outcomes may later generate a candidate preference or policy.

## 8. Important Gap: Procedural Knowledge

VoiceMem can already retain routine-like observations, but MAXIM should eventually represent procedures explicitly.

Example:

```text
Movie mode
1. Lower blinds
2. Dim lights
3. Turn TV on
4. Set amplifier input
```

A repeated successful sequence may become a Candidate Procedure. It must not become executable knowledge merely because it occurred repeatedly; validation and explicit approval remain required.

## 9. Learning Phases

### Learning V1 — Phrase / Alias Learning

Target:

- phrase → goal
- phrase → entity
- phrase → alias

This directly connects to the existing Goal Catalog and Knowledge Base concept.

### Learning V2 — Preference / Correction Learning

Target:

- stable preferences
- repeated corrections
- persistent terminology

### Learning V3 — Outcome Learning

Target:

request → goal → execution → result → user feedback

### Learning V4 — Procedure / Routine Learning

Target:

repeated multi-step successful behaviour → candidate procedure

### Learning V5 — Knowledge Consolidation

Target:

many observations → a small number of stable, explicit knowledge objects

## 10. Knowledge Base Integration

The existing MAXIM Knowledge Base already follows the principle that there is one Knowledge Base rather than separate static and learned databases.

Learned records should therefore enter the same canonical Knowledge Base after Learning Engine approval.

Example:

```json
{
  "phrase": "ahogy szoktuk",
  "goal": "activate_scene",
  "source": "learned"
}
```

The implementation should preserve provenance so the runtime can distinguish manual knowledge, learned knowledge and other sources without creating separate runtime knowledge stores.

## 11. What VoiceMem Should NOT Learn Directly

Do not promote every observed fact into persistent operational knowledge.

Examples such as temporary mood, one-off behaviour, single events or transient runtime state should normally remain memory/evidence unless a validated learning rule says otherwise.

Learning must remain selective.

## 12. Governance Rules

The MAXIM Learning Engine remains the sole writer of persistent user knowledge.

Every implicit learning path follows:

Observation
→ Candidate
→ Validation
→ Proposal
→ User Decision
→ Mutation

Every persistent mutation must be auditable, reversible and versioned.

No Learning Engine component may execute a Home Assistant action.

## 13. Implementation Preparation

Before implementing runtime learning, create and test:

1. `LearningEvent` schema / contract.
2. VoiceMem → Learning Adapter interface.
3. Candidate Knowledge model.
4. Evidence provenance model.
5. Candidate conflict checks.
6. Learning Proposal model.
7. Knowledge Bundle mutation interface.
8. Version / rollback test fixtures.
9. Goal Catalog integration tests.
10. Missing Information Matrix integration tests.

Runtime behaviour should not change until these boundaries are tested.

## 14. Long-Term Architecture

```text
                         VOICEMEM
               Evidence / Experience Layer
                         |
                         | Learning Events
                         v
                  LEARNING ADAPTER
                         |
                         v
                  LEARNING ENGINE
          Candidate / Validation / Proposal
             Approval / Mutation / Versioning
                         |
                         v
                  KNOWLEDGE BUNDLE
             Canonical Persistent Knowledge
                         |
                         v
                  MAXIM RUNTIME
      Parser → KB → Goal → Need Resolution → Plan
                         |
                         v
                   HA Gateway
```

The architecture intentionally avoids a second independent learning database.
