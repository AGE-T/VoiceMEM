# Next Architecture Workplan — Learning + Localisation

Status: Agent analysis task
Baseline: VoiceMemAgent v0.10.5

## Workstream A — VoiceMem ↔ MAXIM Learning

Treat `LEARNING_ENGINE_INTEGRATION_PLAN.md` as an architecture proposal to audit, not as permission to redesign MAXIM silently.

Agent tasks:

1. Audit the v0.10.5 implementation against the plan.
2. Map every existing VoiceMem memory type to:
   - Observation
   - Evidence
   - Candidate source
   - Canonical persistent knowledge
   - Not suitable for learning
3. Identify which existing VoiceMem fields already support the LearningEvent contract.
4. Identify missing fields and proposed adapters.
5. Audit existing `response_experience` and routine mechanisms as candidate learning inputs rather than blindly re-enabling them.
6. Map the existing MAXIM Goal Catalog, Missing Information Matrix, Knowledge Base and Learning Engine contracts onto the VoiceMem evidence model.
7. Produce a concrete V1 implementation plan for phrase → goal, phrase → alias/entity and correction learning.
8. Do not change runtime behaviour yet.
9. Do not create a second independent persistent learning database.
10. Preserve the Learning Engine as the sole writer of persistent knowledge.

Required outputs:

- architecture audit;
- VoiceMem → LearningEvent mapping matrix;
- missing capability matrix;
- V1 implementation plan;
- proposed tests;
- explicit decisions that require further architectural approval.

## Workstream B — British English / Asian-Script Audit

Treat `BRITISH_ENGLISH_AND_LOCALISATION.md` as an active product requirement.

Agent tasks:

1. Scan the entire project for Asian-script characters.
2. Categorise every occurrence according to that document.
3. Replace product-owned runtime/UI/log/prompt/documentation text with British English.
4. Preserve stable internal identifiers and historical data through compatibility mapping rather than silent breaking changes.
5. Do not modify third-party/vendor/model assets merely to make the repository visually English.
6. Add a deterministic regression scanner preventing new product-owned Asian-script occurrences.
7. Verify the canonical memory presentation labels:
   - likes and dislikes
   - expression style
   - thinking style
   - coping style
   - emotion
8. Produce a report of unavoidable remaining occurrences and why they remain.

## Release Rule

Do not bump the production version merely because these architecture documents and audits are created.

Do not merge a runtime learning implementation until the architecture audit and tests are complete.

Any production implementation must follow the project's existing Golden Rule: full tests, recovery evidence, SHA256, mirror sync and final verification.
