# VoiceMEM v0.10.2 recovery package — LLM PRIORITY + REPRODUCIBILITY (P0)

Identity
- Product: VoiceMemAgent v0.10.2 (releases/VoiceMemAgent_v0.10.2.zip)
- SHA256: F56E5155043B9900B2A45799F4FA1663ED8475584F9DBA1F1BBD80B13C525A54
- Gate: GREEN, 1386 tests, 0 regressions, 6 pinned sandbox env-gap, fingerprint 26e38b90… (record: releases/gate_record.json)
- Scope: user-priority for the single llama-server slot (PART 8/9), ASR language
  diagnostic mode (PART 3), dependency pinning (PART 11), release-metadata
  invariants (PART 12), VAD threshold-boundary diagnostics (PART 13).

## A. WHAT CHANGED (runtime)
1. vendor/voicemem/voicemem/utils/common/llm_bg_gate.py (NEW): the cooperative
   cancellation gate — BG_CANCEL thread-event, check_cancel() before every
   ingest-chain LLM leg, bg_chat_create() streaming transport (mid-request
   cancel closes the HTTP stream; llama-server b10717 frees the slot on
   client disconnect — measured: user TTFT behind background work 299.7 s
   → 3.2 s after disconnect). BackgroundCancelledError is a BaseException:
   the chain's `except Exception` fallbacks (e.g. voice_input.py's ADD-only
   fallback) cannot swallow it.
2. app/background_memory.py (gate v2): arm() cancels the in-flight chain and
   re-queues the turn pair (never dropped, exact duplicates coalesced);
   the gate opens only after a REAL idle window (speech frames + LLM deltas
   + turn activity + VOICEMEM_BG_IDLE_S quiet seconds; the old blind 2 s
   grace stays as the floor). GateStats now measures cancelled/requeued/
   idle_waits/last_start_wait_s.
3. vendor …/extract_facts_openai.py: both big legs (extraction, conflict
   resolution) run through bg_chat_create; the RESOLVE leg gets an explicit
   60 s timeout + max_retries=2 (it previously had NONE — SDK default
   600 s, the worst unbounded edge of the chain).
4. app/asr_parakeet.py + app/config.py + config/voicemem_config.yaml:
   asr_language is now read by the PRODUCTION engine (""/auto = native
   multilingual auto-detect; "hu" = diagnostic hint recorded + transcript
   script verified — ParakeetForTDT has no language parameter in its
   inference API). ASR_LANGUAGE env override; yaml default stays auto.
5. app/web_server.py: activity notes (VAD frames with speech energy, barge
   frames, LLM deltas) feed the idle policy.
6. Dependencies: openai==3.14.0 EXACT (vendor pyproject + install_m1.ps1
   step-16 OR-assert + requirements.lock.json machine-readable manifest
   with wheel SHA256s). transformers==5.17.0 (v0.10.1) unchanged.

## B. IF THE TARGET MISBEHAVES AFTER INSTALLING v0.10.2
1. Memory work never starts / starts too late: read the gate stats lines in
   logs/web-server.log ("background memory deferred…", "start delayed");
   tune VOICEMEM_BG_IDLE_S (default 6.0 s) and VOICEMEM_BG_GRACE_S (2.0 s
   floor). The start delay is MEASURED (last_start_wait_s) — tune with data.
2. Memory extraction cancelled too eagerly (re-queue loop in the log):
   the user is speaking continuously — this is correct behaviour (the pairs
   retry in the next idle window); if pathological, raise VOICEMEM_BG_IDLE_S.
3. A cancelled chain left no memory for a turn: check the log for
   "background memory cancelled mid-chain, re-queued" — the pair is retried,
   never silently dropped. If it NEVER completes, capture the log and report.
4. ASR language mode: to run the hu diagnostic, set `asr_language: "hu"` in
   config/voicemem_config.yaml (or ASR_LANGUAGE=hu). The engine logs the
   hint + verifies the transcript script (Cyrillic under a hu hint = the
   regression signature, logged loudly + waveform dumped per v0.10.1).
   Production stays AUTO (do not permanently force Hungarian).

## C. TARGET-SIDE FORENSIC (the P0 closer — ~10-15 minutes)
With the production llama-server RUNNING (the 35B model, parallel=1,
n_slots=1, ctx 32768):
    .venv\Scripts\python.exe scripts\llm_slot_forensic.py
The script (read-only wrt the product; writes only logs/) measures:
  S2 baseline TTFT | S3 user TTFT behind a background-shaped request
  (non-streaming) vs after a mid-stream client disconnect | S4 JSON+stream
  assembly | S5 LCP cache reuse with ACTUAL re-evaluted token counts from
  /metrics | S6 cache survival after cancel | S7 the production interleave
  pattern (user chat → extraction → user chat).
SEND BACK: logs/llm_slot_forensic_*/report.json.
Expected after the fix: user TTFT behind disconnected background work ≈
the baseline TTFT (the sandbox measured 299.7 s → 3.2 s on the same
server build with a stand-in model).
For the ASR leg (if the HU→RU regression reproduces on the target):
    .venv\Scripts\python.exe scripts\asr_regression_forensic.py   (v0.10.1)
and send back logs/asr_forensic_*/report.json + logs/asr_wrong_language_*.wav.

## D. ROLLBACK
Reinstall v0.10.1 (releases/VoiceMemAgent_v0.10.1.zip, SHA256
A9C781E0D4DE8F9843D196AB43FDD945DF686B772370FC9466E6ECD5B866B541) — the
v0.10.2 runtime changes are additive (no schema migration, no data format
change; the memory stores are untouched).
