# VoiceMEM v0.10.1 — ASR-regresszió forenzikai helyreállítási csomag (P0)

**Mit tartalmaz:** a v0.10.1 (P0 ASR forenzikai) kiadás identitása, újjáépítési
útjai és bizonyítékai.

## A) Helyreállítás a kiadott ZIP-ből (ajánlott)
1. `VoiceMemAgent_v0.10.1.zip` letöltése (SHA-ellenőrzés a sidecar-ral).
2. Kicsomagolás ÜRES könyvtárba; `START.bat`.
3. A telepítő MOST EXAKT `transformers==5.17.0`-t pin-el (reprodukálható ASR
   stack — a P0 forenzika egyetlen nem-reprodukálható komponensét szüntette meg).
4. Adatmigráció: NEM SZÜKSÉGES (a v0.10.1 diagnosztikai/telepítési javítás).

## B) Helyreállítás git-ből
```
git clone <tükör> && cd VoiceMEM/source && git checkout d9a80ac
```

## C) Visszagörgetés v0.10.0-ra / v0.9.2-re
A v0.10.1 nem változtat adatsémán és memória-szemantikán — a korábbi ZIP
visszatelepítése önmagában elegendő. A telepítő-pin (5.17.0) marad a javasolt
állapot; a v0.9.2-es telepítő floating pinnel telepít (a P0-ig visszavezető
drift-vektor).

## Célgepi forenzikai teendő (a P0 maradékának lezárására)
```
.venv\Scripts\python.exe scripts\asr_regression_forensic.py
```
A szkript: (1) lementi a tényleges env-et (torch/CUDA/eszköz, transformers,
tokenizers, onnxruntime); (2) SHA-256 ellenőrzi a Parakeet-fájlokat a pinned
revízió ellen; (3) a KONFIGURÁLT (cuda) ÉS a cpu eszközön is lefuttatja a
6 fájlos HU korpuszt a produkciós kódúton; (4) cirill/összefüggéstelen kimenetet
megjelöl. Kimenet: `logs/asr_forensic_<ts>/report.json`. Élő hiba esetén a
`logs/asr_wrong_language_*.wav` fájlokkal együtt küldd vissza — a WAV dönti el:
rossz hang megy be (mikrofon-lánc) vagy jó hang megy be és rossz szöveg jön ki
(CUDA-láb).

## Identitás és bizonyítékok
- `identity.json` — commitok, SHA-k, gate-számok
- `evidence/gate_record.json` — a ZÖLD kapurekord (fingerprint `a8411164…`)
- `evidence/matrix_tf5_17_0_cpu.json` / `matrix_tf5_16_1_cpu.json` — a
  verzió-mátrix teljes kimenetei (CER + hullóforma-statisztikák)
- `evidence/vad_asr_separation.json` — VAD-vágott vs direkt áiratok
- `evidence/model_sha256.txt` — a pinned revízió 6 fájljának SHA-256
- `evidence/REPORT.md` — a teljes P0 forenzikai jelentés (a 7 kérdésre
  adott végleges válaszokkal)
