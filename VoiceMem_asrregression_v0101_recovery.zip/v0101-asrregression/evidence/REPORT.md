# VoiceMEM v0.10.1 — P0 ASR REGRESSION FORENSIC REPORT

**Dátum:** 2026-09-15 · **Prioritás:** P0 (operator) · **Release:** VoiceMemAgent_v0.10.1 (`A9C781E0…`, gate GREEN 1358/0-reg, fingerprint `a8411164…`)
**Bejelentés:** a v0.10.0 élő rendszer magyar beszédet NÉHA oroszra („Я им работаю, валь.") vagy összefüggéstelen angolra („store school") ír át; ugyanaz a gép ugyanazzal a Parakeet v3 modellel v0.9.2 alatt helyes magyart adott („Szia,imre! Mi újság?").

---

## VÉGSŐ VÁLASZOK (a nyitott 7 kérdésre)

**1. VAD, audio-előfeldolgozás, Parakeet, tokenizer, nyelvválasztás, modellfájlok vagy környezeti függőségek — melyik a probléma?**

Ketté válaszva — ami **BIZONYÍTVA kizárva** (sandbox, pinned modell + produkciós kódút):
- **VAD**: NEM. A produkciós Silero szegmentáció a teljes korpuszon helyes (pmax=1.0, ésszerű határok; VAD-vágott és direkt átirat azonos magyar szöveg — `evidence/vad_asr_separation.json`).
- **Audio-előfeldolgozás (shipped kód)**: NEM. A v0.9.2→v0.10.0 **teljes fa-diff** szerint az ASR/VAD/audio/web útvonal **byte-azonos** — csak memória-szemantika fájlok változtak.
- **Modellfájlok**: NEM a pin szintjén. A MODELS.lock pinje változatlan (revision `541d1f99…`), a friss pinned letöltés SHA-ja rögzítve (`evidence/model_sha256.txt`). A CÉLGÉP lemezen lévő fájljait a mellékelt szkript ellenőrzi (a telepítő letöltéskor SHA-t igényel, de a célgepi állapotot mérni kell — lásd 7. pont).
- **transformers-könyvtár (CPU)**: NEM. 5.9.0–5.17.0 **minden** verzió a teljes HU korpuszon HELYES, **byte-azonos kiadásokkal** (5.6.x–5.8.x: a `ParakeetForTDT` osztály hiányzik → hangos import-hiba, NEM szemét kimenet).
- **Tokenizer/nyelvválasztás**: nincs önálló hibaforrás. A Parakeet v3-as transformers-útjában **nyelvparaméter NEM LÉTEZIK** (`asr_language: ""` → motor-alapértelmezés; a dekódolás multilingvális auto — a rossz-nyelv kimenet a bemenet/dekódolás romlottságának tünete, nem konfigurációs hiba).

Ami **MARAD** (bizonyíték-alapú gyanúsítottak, célgepi mérésre várva):
- **(a) A célgepi CUDA-láb**: torch 2.7.0+cu128 + RTX 5070 (sm_120 Blackwell) + a telepítéskor feloldott transformers-verzió — a sandboxban CUDA nem mérhető. Numerikusan degradált inferencia (pl. TF32/kernel-út) multilingvális modellnél pont ilyen **nyelvcsúszásos** kimenetet ad.
- **(b) Az élő mikrofon-lánc**: a célgepi ÉLŐ bemenet minősége (böngészó DSP, eszközváltás, meghajtó). A korpusz (tiszta Piper-HU + régi valós capture) NEM reprodukálja az élő feltételeket.
- A **lebego transformers-pin** mindkettőnél az egyetlen nem-reprodukálható komponens volt — a v0.10.1 EXAKTAN rögzíti (5.17.0).

**2. Miért működött v0.9.2 és miért hibás v0.10.0?**
A TERMÉK közöttük **nem változott** a hangútvonalon (bizonyított byte-azonosság). A különbség a **telepítési környezet újraépülésében** van: a „csak legfrissebb" floating `transformers>=5.6` minden fresh telepítéskor MÁS verziót oldhat fel, a célgepi venv állapota thus nem reprodukálható. A célgepi tényleges verziókat a mellékelt forensic-szkript méri (a távoli diagnózis ezt nem tudja helyettesíteni — őszintén dokumentálva).

**3. Hogy tud a Parakeet hirtelen oroszt adni?**
A Parakeet TDT v3 **25 nyelvű** multilingvális modell (orosz és magyar is benne van), **nyelv-azonosítás és nyelv-kényszer nélkül**. Ha a bemenet akusztikai jegyei degradálódnak (numerikus pontosságvesztés az inferenciában, vagy torzított/aliasolt bemenő hang), a greedy TDT dekódolás egy másik nyelv token-eloszlására „csúszhat át" — folyékony, de rossz nyelvű kimenetet adva. Ez a bejelentett hibajel aláírása. (A korábbi Qwen3-ASR ugyanezen korrupció-osztályon ISMÉTLŐDŐ szemétet adott — a hibajel modellfüggő.)

**4. Az explicit magyar nyelvválasztás változtat-e valamit?**
A Parakeet/transformers-útban **nem támogatott** — nincs nyelvparaméter a motorhívásban (`capabilities.language_detection=False`, a processor csak nyers mintákat + sampling_rate-et kap, a generate csak max_new_tokens-et). Ez a kísérlet vezérelhetően NEM elvégezhető ezen a motoron; a hibát nem is maszkolná (a rossz nyelv tünet, nem ok).

**5. A Parakeet-be érkező nyers WAV azonos-e a két verzióban?**
A **korpusz-útvonal** (fájl → AudioBuffer → engine): IGEN — byte-azonos kód, azonos bemenet. Az **élő útvonal** (böngésző mic → 24k PCM16 → szerver-resample → VAD → utterance): a kód byte-azonos, de az élő bemenetet a v0.10.0-ban SEM rögzítettük (csak az ÜRES áiratok dumpolódtak) — **a v0.10.1 ezt pótolja**: a cirillbetűs (rossz-nyelv) áiratok bemenő hullóformája MOST MINDIG elmentésre kerül (`logs/asr_wrong_language_<ts>.wav`), plusz opt-in teljes dump (`asr_dump_utterances`).

**6. Van függőség-drift?**
- **Bizonyított drift-VEKTOR**: `transformers` floating (a lock szándéka szerint is „a telepítő EZT a fájlt használja" — de a transformers-t a 16. lépes `>=`-gel oldotta fel). **Javítva: EXAKT pin 5.17.0** (installer + assert + requirements + pyproject).
- **Bizonyított padló-HIBA**: a dokumentált `>= 5.6` floor **téves** — a `ParakeetForTDT` a **5.9.0-ben** landolt (5.6.0/5.7.0/5.8.1: import-hiba — tesztelve). A bootstrap-probe padló 5.9-re javítva.
- torch 2.7.0+cu128: EXAKT pin — változatlan a két verzió közt. **Nincs telepítési-időbeli drift.**
- A célgepi TÉNYLEGES pip-állapotot a mellékelt szkript méri és a reportba írja (env-dump).

**7. Mi a legkisebb helyes javítás?**
Csak bizonyított hibákra (mind implementálva, gate-elve):
1. **A hazug diagnosztikai sor** („peak 0.97 < 0.25") — a riportblokk a `vsm.update` ELŐTT futott, ezért a beszédkezdeti keret maga zárhatta az ~5s-ablakot, és a szöveg feltétel nélkül állította a „peak < küszöb"-öt. Most: az update UTÁN fut + explicit feltétel — **a VAD döntési útja változatlan, tiszta logging-javítás.**
2. **Bizonyíték-megőrzés**: rossz-nyelvű (cirill) áirat → a bemenő hullóforma MINDIG dumpolva; opt-in teljes dump.
3. **transformers EXAKT pin** (5.17.0) + a valós 5.9-es padló javítása — az ASR-stack telepítési reprodukálhatósága helyreáll.
4. **A gate-rés zárása**: a kiadott gate SOSEM futtatott valódi Parakeet-inferenciát (csak contract-tesztek). Új: valodi-korpuszos regresszió-tesztek (CER-budget 0.25 a mért 0.000–0.099 fölött, cirill-tiltatás, env-neutral skip) — a gate mostantól AZONNAL elkapná a rossz-nyelvű inferenciát.
5. **scripts/asr_regression_forensic.py**: célgepi 10 perces matrix-cella (env-dump + modell-SHA-ellenőrzés + korpusz a KONFIGURÁLT (cuda) ÉS a cpu eszközön) — ez zárja le a maradék két gyanúsítottat az ACTUAL gépen.

## HATÁROK (őszintén)
A célgepi gyökérok **távollétből NEM bizonyítható** (nincs CUDA és élő mikrofon a sandboxban). A v0.10.1 mindent bizonyítottat javít, és a célgepi eldöntéshez MINDEN eszközt szállít. **Operátori teendő a célgepen**: (1) v0.10.1 telepítése (a pin miatt reprodukálható venv); (2) `scripts\asr_regression_forensic.py` futtatása a saját venvvel; (3) ha élő hiba lép fel: a `logs/asr_wrong_language_*.wav` + a report.json visszaküldése — a WAV dönti el véglegesen: rossz hang megy be (mikrofon-lánc) vagy jó hang megy be és rossz szöveg jön ki (CUDA-láb).

---

## FÁZIS-STATUSZOK

| Fázis | Eredmény |
| --- | --- |
| 1 Baseline-összehasonlítás | **KÉSZ** — teljes fa-diff: az audio-útvonal byte-azonos; YAML-diff: csak verziószám; BUILD_INFO: meta |
| 2 Modell-identitás | **KÉSZ** — pinned revision `541d1f99…`; 6 fájl SHA256 rögzítve; a célgepi ellenőrzés a szkriptben |
| 3 Nyers-audió forenzika | **KÉSZ (korpusz)** — 6 fájl teljes hullóforma-statisztikája (RMS/peak/clipping/első-utolsó beszéd-minta) + a MOTORBA LÉPŐ hullóformák elmentve; ÉLŐ rögzítés → a v0.10.1 dump-képesség |
| 4 VAD vs ASR szétválasztás | **KÉSZ** — VAD-vágott ≡ direkt áirat (magyar, azonos szöveg); Silero pmax 1.0 |
| 5 Direkt Parakeet-teszt | **KÉSZ** — ismert jó magyar WAV-okon: HELYES (6/6) |
| 6 Nyelv-konfiguráció | **KÉSZ** — futásidejű érték: `asr_language=""` → motor-alapértelmezés; a ParakeetForTDT-útban nyelvparaméter nem létezik |
| 7 Függőség-regresszió | **KÉSZ (sandbox-rész)** — CPU-matrix 5.9–5.17 byte-azonos; padló-hiba (5.6→5.9) bizonyítva; floating-pin drift-vektorként azonosítva és rögzítve; célgepi pip-állapot → szkript |
| 8 Regresszió-mátrix | **KÉSZ (CPU-cellák)** — verzió × fájl × CER; a CUDA-cellát a célgepi szkript adja |
| 9 VAD-diagnosztikai hiba | **GYÓGYÍTVA** — bizonyítottan csak logging (a blokk sorrendje + feltétel nélküli szöveg); a javítás a sorrend + explicit feltétel; **nulla döntési-változás** |
| 10 Stop-feltétel | **KÉSZ** — lásd a VÉGSŐ VÁLASZOKAT + HATÁROKAT |
| 11 Javítás | **KÉSZ** — 5 legkisebb determinisztikus javítás (fent); ASR-motor/modellcsalád/VoiceMem/LLM/memória/TTS: ÉRINTETLEN |
| 12 Validáció | **KÉSZ** — új tesztek (6 unit + 2 integration valodi inferenciával) + teljes gate GREEN 1358/0-reg |
| 13 Artefakt | **KÉSZ** — ez a report + dependency-mátrix + modell-hash-ek + előtte/utána áiratok + kód-diff + recovery csomag + SHA256SUMS; VERZIÓ-DÖNTÉS: **v0.10.1** (a runtime-kód érintettsége miatt nem lehetett v0.10.0-hotfix) |

## MÉRÉSI ÖSSZEFOGLALÓ (CPU, fp32, pinned modell)

| Fájl | Várt | 5.17.0 (kapu-verzió) | CER |
| --- | --- | --- | --- |
| hu_short | „Szia, hogy vagy ma?" | „Sziahogy vagy ma!" | 0.000 |
| hu_with_silence | „Ez egy mondat, amelyet csend követ." | azonos | 0.000 |
| hu_normal | „Jó napot kívánok…" | „…utaztam vonatal, és a találkozó…" | 0.020 |
| hu_names | „Kovács Anna és Nagy Béla…" | „…és meg Béla… szabó évával…" | 0.064 |
| hu_long | „Tegnap este sokáig…" | (helyes, kisebb szóhibákkal) | 0.023 |
| real_windows_capture | „Ez egy teszt…" | „Ez egy teszt, egy teszt. Most kipróbáljuk…" | 0.099 |

**Egyik sem cirill; egyiken sincs nyelvcsúszás; 5.16.1 kimenetei byte-azonosak.**

## KÖRNYEZETI MÁTRIX (sandbox, tényleges)

| Komponens | v0.10.0 gate- környezet | v0.10.1 gate-környezet | Megjegyzés |
| --- | --- | --- | --- |
| Python | 3.12 (CPython) | 3.12.14 | azonos |
| torch | 2.14.0+cpu | 2.14.0+cpu | célgep: 2.7.0+cu128 (EXAKT pin, változatlan) |
| transformers | 5.17.0 | 5.17.0 (**EXAKT PIN a célgepen**) | 5.9–5.17 CPU: byte-azonos kimenetek |
| tokenizers | 0.23.x | 0.23.2 | követi a transformersist |
| numpy | 2.x | 2.x | — |
| Parakeet modell | rev `541d1f99…` | azonos (SHA-rögzítve) | célgepi ellenőrzés: szkript |
