# VoiceMemAgent v0.10.7 — MirrorSync evidence package

**What this is:** the golden-rule deliverable of the 2026-09-20 GitHub
mirror sync that published the **v0.10.7** release (the N1/N2 TTS
deterministic fix: Hungarian vowel-harmony guard on budget absorption,
the "holnap" HU_PLAIN_WORDS entry, the host-context tie-break
refinement) to https://github.com/AGE-T/VoiceMEM.

**Pre-sync state:** mirror HEAD `ec253e6` (the v0.10.6 release
close-out). **Post-sync state:** mirror HEAD `48f34b7` —
`VoiceMemAgent_v0.10.7.zip` (SHA256
C5A6C4E30056B0EE3A636CD7CDC6315155AB1334F04406BA57ACBA3A7B684DC3),
`VoiceMemAgent_v0.10.7_recovery.zip` (SHA256
24CA6A303B466FF24C99AD7170A8B2DDDCD62267EFCF3902A12706B5BE56522D),
the regenerated README (v0.10.7 as the latest stable release) and the
`source/` tree at the 0.10.7 release state (the fix, the 16-test
matrix, the forensic report).

**Verification:** anonymous fresh clone at `48f34b7` — both new ZIPs
byte-identical (SHA-256 table in evidence/04), README metadata correct,
source tree carrying the release identity.

**Contents:** `evidence/01_token_check.txt`, `evidence/02_dryrun.txt`,
`evidence/03_push_log.txt`, `evidence/04_fresh_clone_verification.txt`,
`evidence/05_mirror_git_log.txt`, `evidence/06_notes.md`,
`identity.json`.
