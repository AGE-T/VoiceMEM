# v0.10.7 MirrorSync notes

- This is the release sync for the N1/N2 deterministic fix
  (mirror HEAD moved ec253e6 -> 48f34b7).
- The forensic deliverable (audit/VoiceMEM_tts_N1_N2_forensic/) ships
  in source/ so the audit is readable back from the mirror.
- Token hygiene: env-file-only PAT, zero occurrences in any artefact
  (grep-verified).
- Anonymous fresh-clone verification: PASS (see 04).
