# RECOVERY — LLM Configuration Centralisation (v0.7.2)

Task: CENTRALISE LLM CONFIGURATION (operator order)
Release: VoiceMemAgent_v0.7.2
Code commit: `57d07c5` (wiring) · release commits `edf7a29` + `6fd8d69` (corrected build)
Built: 2026-09-13
ZIP: `VoiceMemAgent_v0.7.2.zip` — 2 584 336 bytes
SHA256: `EC100A2DD6B9D04963CEFD0A36D5F5E72B684D810F913816F30A3D46EC196AEC`
(withdrawn intermediate build `EDCDEEA2…` carried a wrong test count in its
notes; superseded by this one.)

## What changed (16 code files + build)

THE ONE FILE: `config/llm_config.yaml` — the single operator-editable source
for every production LLM runtime value. THE ONE LOADER: `app/llm_config.py`.

| File | Change |
|---|---|
| `config/llm_config.yaml` | NEW (previous session): the canonical file |
| `app/llm_config.py` | NEW (previous session): the ONE loader |
| `app/config.py` | `from_yaml` → `materialise_llm_runtime()`; duplicate env parsing in `apply_env` RETIRED; stale defaults 8192/-1 → 32768/20; `llm_config_summary()` |
| `app/llm.py` | `_thinking_control_kwargs` delegates to the canonical runtime |
| `app/main.py` | `load_config` materialises; startup banner prints the LLM config summary |
| `app/web_server.py` | same on both branches; `[web]` startup block prints the summary |
| `scripts/start_llama_server.ps1` | bridge emits `reasoning` + `source`; `--reasoning` GENERATED from `$Cfg.reasoning`; direct fallback = explicit emergency path (loud warning) |
| `config/voicemem_config.yaml` | llm_* value keys REMOVED (pointer comment to the canonical file) |
| `config/env.local.ps1` | active LLAMA_*/LLM_* value assignments commented out (emergency overrides) |
| `tests/unit/test_llm_config.py` | 44 → 48 tests (T1-T8 extended with the wiring pins) |
| `tests/unit/test_config.py` | realigned (canonical beats voicemem-yaml duplicates) |
| `tests/unit/test_llm_reasoning.py` | realigned (env override through the loader) |
| `tests/validation/test_feature_thinking.py` | realigned (generated reasoning flag, canonical yaml pin) |
| `tests/unit/test_web_mic_probe.py` | version pin 0.7.1 → 0.7.2 |
| `VERSION` / `pyproject.toml` / yaml `project.version` / `PAGE_VERSION` | 0.7.1 → 0.7.2 |
| `scripts/build_release_sandbox.py` | v0.7.2 build + V072 markers + realigned historical pins |

## Migration (operator)

EQUIVALENT PRODUCTION VALUES — UNCHANGED:
`model qwen3.6-35b-a3b / gpu_layers 20 / context_size 32768 / parallel 1 /
cache q8_0+q8_0 / temperature 0.7 / max_tokens 512 / thinking OFF`.

To change any of them from now on: edit **`config/llm_config.yaml`** (ONE
file) and restart `START.bat`. The llama-server command line, the Python
client, the request-level thinking suppression and the startup log all pick
the values up from there. Optional emergency env overrides (documented in
the yaml header): `LLAMA_N_GPU_LAYERS`, `LLAMA_CONTEXT_SIZE`, `LLAMA_PARALLEL`,
`LLAMA_CACHE_TYPE_K/V`, `LLM_TEMPERATURE`, `LLM_MAX_TOKENS`,
`LLM_DISABLE_THINKING`, `OPENAI_MODEL` — every active override is REPORTED
at startup, never silent.

## Rollback

```powershell
# 1) code: return to the pre-centralisation wiring (v0.7.1)
git checkout 3bbd34b -- voicemem-agent/app voicemem-agent/config voicemem-agent/scripts voicemem-agent/tests
# 2) runtime values: the v0.7.1 voicemem_config.yaml app: section carries
#    the same values (llm_context_size: 32768, llm_n_gpu_layers: 20, ...)
# 3) release: re-extract the previous VoiceMemAgent_v0.7.1.zip
```

The v0.7.1 ZIP shipped `install_m1.ps1` already parse-clean (the v0.7.0
line-612 missing-brace defect was fixed in v0.7.1 + guarded by
`scripts/ps_lint.py` on both sides of the release gate).

## Verification (this session)

- Config battery: 48/48 green + 8 subtests (`tests/unit/test_llm_config.py`,
  T1-T8, incl. the real captured b10717 llama-server log cross-check:
  offloaded 20, n_ctx 32768, n_ctx_slot 32768, K/V q8_0, thinking 0)
- Full gate: `python -m unittest discover -s tests` → 1063 tests,
  ZERO new failures vs the stashed pre-change baseline
  (pre-existing sandbox-state failures: asr_modular ×6 missing model
  weights, release-index ×2 wiped zips, memory-safety fixtures ×5,
  vendor-state pollution ×3 — identical with and without these changes)
- ps_lint: all repo `*.ps1` clean
- REAL PowerShell 7.4.6 Parser API: `install_m1.ps1`,
  `start_llama_server.ps1` (before AND after the edits), and the SHIPPED
  ZIP's installer all parse OK
- Release self-check (inside the ZIP): V072 markers green

## Git sync status (separate issue, NOT part of this change)

The GitHub mirror (https://github.com/AGE-T/VoiceMEM) is STALLED at `8b7e6fb`
because the sandbox reset of 2026-09-13 19:45 wiped
`/home/z/.github_sync/AGE-T_VoiceMEM.token` (the fine-grained PAT; policy:
never stored anywhere else — searched: bash history, git config, project
files, upload/, audit zips, /tmp copies — all clean/not found).
Local `main` is now 6 commits ahead: `3f180c8`, `5579630`, `4cfc1a6`,
`3bbd34b`, `57d07c5`, `edf7a29`+`6fd8d69`. RESTORE: re-paste the PAT (expires
2026-11-09) into `/home/z/.github_sync/AGE-T_VoiceMEM.token` (chmod 600) or
export `GITHUB_TOKEN`, then run `scripts/sync_github_mirror.sh` — it will
push everything (the v0.7.2 zip + README regen) in one command.
