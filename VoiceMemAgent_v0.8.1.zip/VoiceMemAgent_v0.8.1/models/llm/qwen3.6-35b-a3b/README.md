# models/llm/qwen3.6-35b-a3b — the ONE AND ONLY runtime LLM (v0.4.16 / v0.4.17)

`Qwen3.6-35B-A3B-IQ4_XS.gguf` (operator-placed GGUF, ~19 GB) —
Qwen3.6 35B A3B (Mixture-of-Experts, ~3B active parameters),
IQ4_XS quantisation. Served by the llama.cpp `llama-server`
(OpenAI-compatible endpoint at 127.0.0.1:8080).

LLM POLICY (v0.4.16):
  - LLM MODEL COUNT at runtime: 1
  - THE ONLY LLM: Qwen3.6 35B A3B IQ4_XS (tested source:
    hf.co/bartowski/Qwen_Qwen3.6-35B-A3B-GGUF:IQ4_XS)
  - NO fallback profile, NO second model, NO cloud fallback, no Ollama
    runtime. A missing active GGUF is an LLM ERROR state; select the
    file with the web UI "LLM model" picker (any drive) or place it
    here and restart (START.bat).

The GGUF is OPERATOR-PLACED (tested in Ollama on the target hardware
before activation: natural Hungarian conversation, short turns,
HU<->EN switching). It is NOT part of the pinned download set.

v0.4.16 — PORTABLE MODEL PATH: the file does NOT need to live here.
Select it from ANY drive with the web UI "LLM model" → Browse…
(a native Windows file picker; the absolute path is persisted in
config/llm_model.json and the file is NEVER copied into the project).
Placing it here (project default) still works — with ANY file name:
    models\llm\qwen3.6-35b-a3b\<anything>.gguf
(v0.4.17: the directory is scanned for a file with a valid GGUF magic —
the NAME is irrelevant. Exactly one candidate = the default; zero or
multiple = the honest "no model configured" state, use the picker.)

v0.4.17 — OLLAMA BLOBS LOAD DIRECTLY (no copy, no rename): the tested
model was DOWNLOADED BY OLLAMA, so on this machine it is a
content-addressed blob like

    <OLLAMA_MODELS>\blobs\sha256-afc7238af403ed454b7846454091b5e38b07575bdbb64c3e86777414dde4193c

The blob NAME says nothing about the model. llama.cpp checks the GGUF
magic, NEVER the file name — a sha256-… blob (no .gguf extension) loads
exactly like a named .gguf, IN PLACE, on any drive. Identify the exact
blob for the tested model and configure it with ONE command:

    powershell -NoProfile -ExecutionPolicy Bypass -File scripts\identify_ollama_blob.ps1 -Select

It resolves the Ollama manifest (hf.co/bartowski/Qwen_Qwen3.6-35B-A3B-GGUF:IQ4_XS
→ tag → model-layer digest → blob), verifies the ACTUAL CONTENT via the
GGUF header (model identity + quantisation checked separately, IQ4_XS =
general.file_type 30) plus an independent sha256 digest check, and
decides whether llama-server can load the file DIRECTLY:
  - ONE model layer, complete single-file GGUF → YES (-Select persists
    the exact absolute blob path — the same selection the web UI picker
    writes; the blob is never copied/renamed/duplicated);
  - the manifest splits the model into MULTIPLE blobs (or one blob whose
    header carries general.split.no/count) → NO: llama.cpp finds sibling
    shards by the <prefix>-NNNNN-of-NNNNN.gguf file-name pattern, which
    a sha256-… blob never matches. The script STOPS and explains — it
    does NOT create a 20 GB duplicate (the remedy is downloading the
    complete single-file GGUF, or an operator-run llama-gguf-split
    --merge).
Ollama itself is NOT a runtime dependency — llama-server reads the blob
itself (production architecture: VoiceMemAgent → local llama-server →
Qwen3.6 35B A3B IQ4_XS).

v0.4.15/v0.4.16 — DO NOT GUESS THE FILENAME OR THE LOCATION: locate the
actual file with the exact-model locator before trusting the runtime config:

    powershell -NoProfile -ExecutionPolicy Bypass -File scripts\find_qwen_gguf.ps1

It searches the repo, the Ollama store (resolving the manifest of
hf.co/bartowski/Qwen_Qwen3.6-35B-A3B-GGUF:IQ4_XS — the blob IS the
GGUF llama-server can read directly), the HF cache, LM Studio and the
usual download folders; it validates every candidate's GGUF header
(model identity + quantisation — IQ4_XS is general.file_type 30) and
prints the exact absolute Windows path. With exactly one exact match
it can rewrite ONLY the LLAMA_MODEL_PATH line in config/env.local.ps1
(-SetEnv, .bak backup) or copy it here (-CopyToRepo).
If the file is missing it STOPS: no other model and no other
quantisation is substituted (a missing active GGUF stays an LLM ERROR
state; there is NO fallback profile to switch to).

After placing/pointing: start scripts\start_llama_server.ps1 — it runs
THREE independent load PROOFS and records them in
logs\llama-server.resolved-model.json (the web UI "LLM model" section
shows them): [1] the served model id from GET /v1/models, [2] the
server's own log line containing the exact --model path, [3] a real
/v1/chat/completions round-trip. Gate with scripts\verify_m1.ps1
("LLM GGUF (Qwen3.6 35B A3B IQ4_XS …)" PASS + "LLM model loaded
(GET /v1/models)" + the load-proof block).

Exact download source for the tested quantisation (only if missing):
    https://huggingface.co/bartowski/Qwen_Qwen3.6-35B-A3B-GGUF
    file Qwen_Qwen3.6-35B-A3B-IQ4_XS.gguf (tag IQ4_XS)

Target hardware the profile is tuned for:
  - RTX 5070 12 GB VRAM + 32 GB system RAM (Windows 11)
  - the model (~19 GB IQ4_XS) does NOT fit in VRAM: LLAMA_N_GPU_LAYERS=20
    (v0.6.0+ measured profile: 20/42 layers on GPU)
    keeps attention + KV cache (q8_0) + compute buffers on the GPU and
    streams the remaining expert layers from system RAM. If your
    llama.cpp build supports MoE-level split, `--n-cpu-moe` /
    `--override-tensor "exps=CPU"` is the finer-grained alternative.
  - context 32768 (v0.6.0+ measured profile: TTFT ~4,89 s vs ~4,90 s at
    8192 - the 32K window costs ~nothing measured, and production prompts
    above 8K already occurred; the prompt budget stays 14000 chars, deliberately NOT
    increased); thinking channel OFF (LLM_DISABLE_THINKING=1 — the
    llama-server runs with `--reasoning off` and every request also
    carries chat_template_kwargs.enable_thinking=false +
    reasoning_effort "none").

Access path from the app: `AgentConfig.llm_model_file`
(env override: `LLAMA_MODEL_PATH`).
