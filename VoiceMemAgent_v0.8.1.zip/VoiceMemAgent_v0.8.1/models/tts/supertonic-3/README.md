# models/tts/supertonic-3 — Supertonic 3 TTS (v0.7.0 production)

A Supertone **Supertonic 3** open-weight TTS modell asset-ei (~99M paraméter,
ONNX Runtime CPU futtatás, 31 nyelv — magyar és angol is, 44.1 kHz 16-bit
kimenet). A Piper-t 2026-ban kiváltotta (nincs fallback engine).

Elvárt tartalom (a `scripts/download_models.ps1` / MODELS.lock.json `tts`
bejegyzés tölti le, setup-time, EGYSZER — a futásidő teljesen offline):

```
onnx/tts.json                  onnx/text_encoder.onnx
onnx/unicode_indexer.json      onnx/vector_estimator.onnx
onnx/duration_predictor.onnx   onnx/vocoder.onnx
voice_styles/F1.json … voice_styles/M5.json   (10 preset hang)
LICENSE                        (OpenRAIL-M)
ASSET_MANIFEST.json            (SHA256 — a letöltő írja)
```

- Forrás: `supertone-oss-archive/supertonic-3` @
  `aafc6e32416a594460b32413efc49d7fe4ce6d46` (ARCHIVÁLT repo — fix külső
  függőség; az eredeti Supertone org és a 2026.07.23-i szolgáltatás
  megszűnt, l. LICENSES.md).
- Python csomag: `supertonic==1.3.1` (requirements.lock; MIT mintakód,
  modell OpenRAIL-M).
- A futtató az `app/tts_supertonic.py` (SupertonicTtsEngine): a modellt
  EGYSZER tölti be (lazy, első szintézis), életben tartja; SOHA nem tölt le
  semmit futásidőben (`auto_download=False`).
- A tartalom gitignore-olt (a `.gitkeep` és ez a README kivételével).
- Elérési út: `AgentConfig.supertonic_model_dir`
  (env-felülírás: `SUPERTONIC_MODEL_PATH`).
