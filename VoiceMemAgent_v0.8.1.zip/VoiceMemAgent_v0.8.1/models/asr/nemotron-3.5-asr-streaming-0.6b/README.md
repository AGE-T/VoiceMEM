# models/asr/nemotron-3.5-asr-streaming-0.6b — ASR modell (selectable)

Az **NVIDIA Nemotron 3.5 ASR streaming 0.6B** modellkönyvtára
(HF repo: `nvidia/nemotron-3.5-asr-streaming-0.6b`).

A v0.6.0 moduláris ASR-motorréteg SELECTABLE (nem alapértelmezett) motorja:
`ASR_ENGINE=nemotron` / yaml `asr.engine: nemotron` választja ki az
`app/asr_core.py` MOTORREGISZTERBŐL (adapter: `app/asr_nemotron.py`,
igazi cache-aware streaming). A termelési alapértelmezés a Parakeet TDT
(`models/asr/parakeet-tdt-0.6b-v3`) — mérési alapú döntés, l. CHANGELOG 0.6.0.

A súlyokat NEM a MODELS.lock.json automatikus letöltője telepíti (az asr
bejegyzés a production Parakeet-re mutat) — CUDA-célú, kézi/későbbi
bővítés. A tartalom gitignore-olt; a repóba csak ez a README és a
`.gitkeep` kerül. Az elérés útja az appból: a motorregiszter
`MODEL_REGISTRY["nemotron"].local_dir` (env: `ASR_ENGINE`).
