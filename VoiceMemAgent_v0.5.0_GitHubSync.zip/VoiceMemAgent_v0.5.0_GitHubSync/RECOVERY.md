# RECOVERY — VoiceMemAgent_v0.5.0_GitHubSync

**Artifact type:** GOLDEN RULE deliverable (first authenticated GitHub sync)
**Created:** 2026-09-10, session `web-7b05b5bc-1460-41f0-9ee3-aeaffd50714f`

## What happened

The owner granted write access to <https://github.com/AGE-T/VoiceMEM>
via a **repo-scoped fine-grained PAT** (Contents: Read and write,
expiring). The token was validated through the GitHub API
(`push: true`), used for exactly one `git push`, and never stored
anywhere (inline URL only — redacted in all evidence files).

**Push:** `5f4a075..5248c10  main -> main` — the mirror's first sync
commit, `5248c10` "sync: README + SHA-256 sidecars + mirror-check
evidence package".

## What was added to the mirror

- `README.md` — package table with SHA-256 hashes, download
  verification instructions, Windows install steps (START.bat), the
  v0.5.0 verification story (pin `e8384e0`, clean install, 921/24
  gate, 10-file patch ledger), Hungarian summary
- `VoiceMemAgent_v0.5.0.zip.sha256` — `45C1FEBA…CEB40`
- `VoiceMemAgent_v0.5.0_Verification.zip.sha256` — `AA880796…DB631`
- `VoiceMemAgent_v0.5.0_MirrorCheck.zip` + `.sha256` — the
  mirror-verification evidence package (PASS)

**Nothing existing was modified** — both original ZIPs byte-identical
after the sync (verified by fresh clone).

## Verification performed

1. Fresh **anonymous** clone after the push
2. All three ZIP hashes match the originals
3. `sha256sum -c` over all sidecars: `OK` ×3
4. Raw README served: HTTP 200 / 4405 bytes
5. `git ls-remote`: `main = 5248c10ba83b…`

Raw outputs: `evidence/` (7 files: API permission check, push output,
ls-remote before/after, clone hashes, sidecar check, README fetch,
commit stat).

## Recovery anchors

- **Mirror:** https://github.com/AGE-T/VoiceMEM @ `5248c10`
- **Lineage on GitHub:** `5f4a075` (user's "Mem ovnership") →
  `5248c10` (this sync)
- **Local lineage:** `1860014` (mirror verified + linked) →
  `ca732ef` (write-access diagnostic) → follow-up commit for this
  package
- **Token:** single-use in this session — **revoke it now** (GitHub →
  Settings → Developer settings → Fine-grained tokens → Delete), or
  keep it until 2026-11-09 if further syncs are wanted soon

## If the mirror is ever lost

The same content is rebuildable: ZIPs from the build environment
(`public/` + `voicemem-agent/releases/`), README from this package's
`evidence/commit_stat.txt` lineage, checksums recomputed via
`sha256sum`.
