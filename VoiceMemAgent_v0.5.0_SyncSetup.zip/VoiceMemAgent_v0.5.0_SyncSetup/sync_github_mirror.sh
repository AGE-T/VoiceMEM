#!/usr/bin/env bash
# =============================================================================
# sync_github_mirror.sh — VoiceMemAgent → GitHub tükör szinkronizáció
#
# ÁLLÓ SZABÁLYZAT (tulajdonos, 2026-09-10): "gitre is menjen majd minden
# frissítés" — minden jövőbeli frissítés (új kiadás + evidencia csomagok)
# automatikusan felkerül a https://github.com/AGE-T/VoiceMEM tükörre.
#
# SZINKRON SZABÁLY:
#   - Termék: CSAK a legfrissebb stabil kiadás ZIP + .sha256 sidecar
#     (a v0.4.x történet archívum marad a sandbox releases/ mappájában)
#   - Evidencia: minden VoiceMemAgent_v<verzió>_<Suffix>.zip + .sha256
#     (Verification, MirrorCheck, GitHubSync, SyncSetup, …)
#   - README.md minden futásnál újragenerálódik (táblázat + hash-ek)
#   - a tükörön lévő fájlokat NEM töröljük (additív szinkron)
#
# HASZNÁLAT:
#   scripts/sync_github_mirror.sh          # szinkron + push, ha van változás
#   scripts/sync_github_mirror.sh --check  # dry-run: csak jelentés
#
# TOKEN (soha nem kerül a repóba / public/-ba / kimenetbe):
#   alapértelmezés: /home/z/.github_sync/AGE-T_VoiceMEM.token (chmod 600)
#   felülírható:    GITHUB_SYNC_TOKEN_FILE vagy GITHUB_TOKEN
# =============================================================================
set -euo pipefail

REPO_SLUG="AGE-T/VoiceMEM"
REPO_URL="https://github.com/${REPO_SLUG}.git"
BRANCH="main"

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PUBLIC_DIR="${PROJECT_ROOT}/public"

TOKEN_FILE="${GITHUB_SYNC_TOKEN_FILE:-/home/z/.github_sync/AGE-T_VoiceMEM.token}"
DRY_RUN=0
[[ "${1:-}" == "--check" ]] && DRY_RUN=1

redact() { sed -E 's/github_pat_[A-Za-z0-9_]+/***TOKEN***/g'; }

# --- token betöltés -----------------------------------------------------------
if [[ -n "${GITHUB_TOKEN:-}" ]]; then
  TOKEN="${GITHUB_TOKEN}"
elif [[ -r "${TOKEN_FILE}" ]]; then
  TOKEN="$(tr -d '[:space:]' < "${TOKEN_FILE}")"
else
  echo "HIBA: nem található token (${TOKEN_FILE}) és GITHUB_TOKEN sincs beállítva." >&2
  exit 2
fi
if [[ -z "${TOKEN}" || "${TOKEN}" != github_pat_* ]]; then
  echo "HIBA: a token formátuma nem fine-grained PAT (github_pat_…)." >&2
  exit 2
fi

# --- szinkronkészlet összegyűjtése --------------------------------------------
cd "${PUBLIC_DIR}"

# Legfrissebb termékkiadás (verzió szerint rendezve)
product_zip="$(ls VoiceMemAgent_v[0-9]*.zip 2>/dev/null \
  | grep -E '_v[0-9]+\.[0-9]+\.[0-9]+\.zip$' | sort -V | tail -1 || true)"
if [[ -z "${product_zip}" ]]; then
  echo "HIBA: nem található termékkiadás (VoiceMemAgent_vX.Y.Z.zip) a public/ mappában." >&2
  exit 2
fi

# Evidencia csomagok: VoiceMemAgent_v<verzió>_<Suffix>.zip minta
evidence_zips="$(ls VoiceMemAgent_v[0-9]*_*.zip 2>/dev/null | sort -V || true)"

sync_files=()
add_with_sidecar() {
  local f="$1"
  [[ -f "${f}" ]] || return 0
  sync_files+=("${f}")
  [[ -f "${f}.sha256" ]] && sync_files+=("${f}.sha256")
  return 0
}
add_with_sidecar "${product_zip}"
while IFS= read -r ev; do
  [[ -n "${ev}" ]] && add_with_sidecar "${ev}"
done <<< "${evidence_zips}"

echo "Szinkronkészlet (${#sync_files[@]} fájl):"
for f in "${sync_files[@]}"; do echo "  - ${f}"; done

# --- leírások a README táblázathoz ---------------------------------------------
describe() {
  local f="$1"
  case "${f}" in
    "${product_zip}")
      echo "**The product.** Full agent source, machine-independent (no runtime state inside: no \`.venv\`, models, or memory). Install = unzip + \`START.bat\`." ;;
    *_Verification.zip)
      echo "**The verification record** (not a product release): independent verification report — phases + engineering decisions, evidence files (pin verification, clean-install manifest, retrieval baseline, trait assessment, test gate), \`identity.json\` and \`RECOVERY.md\`." ;;
    *_MirrorCheck.zip)
      echo "**The mirror check**: proof that this GitHub mirror is byte-identical to the locally produced artifacts (SHA-256 tables from both sides, git clone evidence). Verdict: \`PASS\`." ;;
    *_GitHubSync.zip)
      echo "**First authenticated sync evidence**: token permission check, push output, fresh-clone verification of the mirror state after the sync." ;;
    *_SyncSetup.zip)
      echo "**Standing sync policy + infrastructure**: the sync script, the procedure document, and the setup-run evidence (every future update goes to the GitHub mirror)." ;;
    *)
      echo "**Evidence package** for the \`${f##*_}\` work unit (GOLDEN RULE deliverable: RECOVERY.md + identity.json + evidence)." ;;
  esac
}

fmt_size() {
  local b="$1"
  if (( b >= 1024 * 1024 )); then echo "$(( b / 1024 / 1024 )).$(( (b / 1024 % 1024) * 10 / 1024 )) MB"
  elif (( b >= 1024 )); then echo "$(( (b + 512) / 1024 )) KB"
  else echo "${b} B"; fi
}

# --- tükör klón ----------------------------------------------------------------
TMP_DIR="$(mktemp -d /tmp/voicemem_sync.XXXXXX)"
trap 'rm -rf "${TMP_DIR}"' EXIT

echo "Tükör klónozása (névtelen)…"
git clone --quiet "${REPO_URL}" "${TMP_DIR}/mirror"
cd "${TMP_DIR}/mirror"

# --- összehasonlítás + másolás --------------------------------------------------
changed=()
for f in "${sync_files[@]}"; do
  if [[ ! -f "${f}" ]]; then
    cp "${PUBLIC_DIR}/${f}" .
    changed+=("${f}")
  else
    local_h="$(sha256sum "${PUBLIC_DIR}/${f}" | awk '{print $1}')"
    mirror_h="$(sha256sum "${f}" | awk '{print $1}')"
    if [[ "${local_h}" != "${mirror_h}" ]]; then
      cp "${PUBLIC_DIR}/${f}" .
      changed+=("${f}")
    fi
  fi
done

# --- README generálás ------------------------------------------------------------
gen_readme() {
  local ver="${product_zip#VoiceMemAgent_v}"; ver="${ver%.zip}"
  local zips=()
  for f in "${sync_files[@]}"; do
    case "${f}" in *.sha256) ;; *) zips+=("${f}") ;; esac
  done
  {
    echo "# VoiceMEM — VoiceMemAgent Releases"
    echo
    echo "Distribution mirror for **VoiceMemAgent**, the one-click, offline-capable"
    echo "voice memory agent. This repository hosts the versioned release packages"
    echo "and their verification artifacts — the canonical build source lives in"
    echo "the agent workspace."
    echo
    echo "**Latest stable release: \`v${ver}\`**"
    echo
    echo "---"
    echo
    echo "## Packages"
    echo
    echo "| File | What it is | Size |"
    echo "| --- | --- | --- |"
    for f in "${zips[@]}"; do
      local sz; sz="$(stat -c%s "${f}")"
      echo "| \`${f}\` | $(describe "${f}") | $(fmt_size "${sz}") |"
    done
    echo
    echo "## Verify your download"
    echo
    echo '```bash'
    echo "sha256sum ${zips[*]}"
    echo '```'
    echo
    echo "Expected:"
    echo
    echo '```text'
    for f in "${zips[@]}"; do
      local h; h="$(sha256sum "${f}" | awk '{print $1}')"
      echo "${h}  ${f}"
    done
    echo '```'
    echo
    echo "(\`.sha256\` sidecar files are included next to each ZIP.)"
    echo
    echo "## Install (Windows)"
    echo
    echo "1. Unzip \`${product_zip}\` into any folder (e.g. \`F:\\Voicemem\\VoiceMemAgent\`)."
    echo "2. Double-click **\`START.bat\`** — that is the single user entry point."
    echo "3. Wait for the bootstrap: Python check, \`.venv\`, dependencies, HF tooling,"
    echo "   model download (\`MODELS.lock.json\`), configuration, smoke tests."
    echo "4. If everything is green, the agent starts — you can talk to it."
    echo
    echo "Advanced modes: \`START.bat mock\` · \`check\` · \`benchmark\` · \`repair\` · \`build\`."
    echo "At a single end-to-end failure, re-run \`START.bat repair\`."
    echo
    echo "## The verification story (v${ver})"
    echo
    echo "- **Vendor identity:** \`vendor/voicemem\` pinned at"
    echo "  \`e8384e087bd2f44eb05fc7ae1a3c525ea8244179\` (= upstream tag \`v0.0.1\`;"
    echo "  the \`0.2.3\` package version is **not** the identity anchor)."
    echo "- **Pin verification:** 3-mode script (source / runtime / embedding), with"
    echo "  an instrumented fake OpenAI client proving the OpenAI client is never"
    echo "  constructed — all green."
    echo "- **Clean install:** fresh ZIP → new venv → editable install → import"
    echo "  identity → \`pin_verified: true\` in the manifest."
    echo "- **Test gate:** 921 passed / 24 skipped, reproduced in a downgraded"
    echo "  (no vendor PYTHONPATH) main-sandbox venv."
    echo "- **Local vendor patches:** exactly 10 files vs upstream, all mapped in a"
    echo "  documented ledger — permanently local, never upstreamed."
    echo "- Full details: open the \`*_Verification.zip\` → \`docs/\` report."
    echo
    echo "## Mirrors"
    echo
    echo "- This repository is the **external distribution mirror**, synced with"
    echo "  write access granted by the owner (token-scoped, revocable)."
    echo "- Standing sync policy: every future update (new release + evidence"
    echo "  packages) is pushed here automatically (\`scripts/sync_github_mirror.sh\`)."
    echo
    echo "---"
    echo
    echo "## Magyar összefoglaló"
    echo
    echo "Ez a repó a **VoiceMemAgent** kiadásainak külső tükre. A legfrissebb"
    echo "stabil verzió a **v${ver}**. Mit találhat itt:"
    echo
    echo "- **\`${product_zip}\`** — maga a termék. Gépfüggetlen forrás,"
    echo "  telepítés: kicsomagolás + \`START.bat\` dupla kattintás, minden mást a"
    echo "  bootstrap elintézi."
    echo "- **Verifikációs / evidencia ZIP-ek** — a kiadások független"
    echo "  ellenőrzésének dokumentumai és a tükör szinkron bizonyítékai."
    echo
    echo "Letöltés után ellenőrizd a SHA-256 összegeket (fenti táblázat). A vendor"
    echo "identitás a \`e8384e0…\` pin (nem a 0.2.3-as csomagverzió)."
  } > "${TMP_DIR}/README.generated.md"
}

gen_readme
if ! diff -q "${TMP_DIR}/README.generated.md" README.md >/dev/null 2>&1; then
  cp "${TMP_DIR}/README.generated.md" README.md
  changed+=("README.md")
fi

# --- eredmény ---------------------------------------------------------------------
if [[ ${#changed[@]} -eq 0 ]]; then
  echo
  echo "✔ A tükör NAPRAKÉSZ — nincs teendő (HEAD: $(git rev-parse --short HEAD))."
  exit 0
fi

echo
echo "Változott fájlok (${#changed[@]}):"
for f in "${changed[@]}"; do echo "  + ${f}"; done

if [[ ${DRY_RUN} -eq 1 ]]; then
  echo
  echo "[--check] Dry-run: nem történt push. Futtasd argumentum nélkül a szinkronhoz."
  exit 0
fi

# --- commit + push ------------------------------------------------------------------
git config user.name "Z.ai Code"
git config user.email "z@container"
git add -A
summary="$(printf '%s, ' "${changed[@]}")"; summary="${summary%, }"
git commit -q -m "sync: ${summary}

Auto-sync by scripts/sync_github_mirror.sh (standing policy: every
update goes to the GitHub mirror). Additive only — nothing deleted."

push_url="https://${TOKEN}@github.com/${REPO_SLUG}.git"
echo "Push…"
git push "${push_url}" "${BRANCH}" 2>&1 | redact

echo
echo "✔ SZINKRON KÉSZ. Új tükör HEAD: $(git rev-parse --short HEAD)"
git log --oneline -1
