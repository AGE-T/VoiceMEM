# Álló szinkron-szabályzat — GitHub tükör

**Tulajdonosi utasítás (2026-09-10):** „gitre is menjen majd minden frissítés"

**Jelentése:** minden jövőbeli frissítés — új kiadás (v0.5.1+) és minden
GOLDEN RULE evidencia-csomag — automatikusan felkerül a
https://github.com/AGE-T/VoiceMEM külső tükörre.

## Végrehajtó

`scripts/sync_github_mirror.sh` (a build sandboxban):

```bash
bash scripts/sync_github_mirror.sh          # szinkron + push, ha van változás
bash scripts/sync_github_mirror.sh --check  # dry-run: csak jelentés
```

A script:

1. Token betöltése: `/home/z/.github_sync/AGE-T_VoiceMEM.token`
   (felülírható `GITHUB_SYNC_TOKEN_FILE` / `GITHUB_TOKEN` környezeti
   változóval). A token **soha** nem kerül: a git repóba, a `public/`
   mappába (weben elérhetetlen), vagy bármilyen kimenetbe (redaktálva).
2. Szinkronkészlet felépítése a `public/` mappából:
   - **termék:** csak a legfrissebb stabil kiadás ZIP + `.sha256`
   - **evidencia:** minden `VoiceMemAgent_v<verzió>_<Suffix>.zip` +
     `.sha256` (Verification, MirrorCheck, GitHubSync, SyncSetup, …)
3. A tükör névtelen klónozása, fájlonkénti SHA-256 összehasonlítás.
4. `README.md` újragenerálása (csomagtáblázat + hash-ek a tényleges
   fájlokból) — így a tükör leírása mindig naprakész.
5. Ha van változás: commit + push (token a push URL-jében, kimenet
   redaktálva). Ha nincs: „A tükör NAPRAKÉSZ — nincs teendő."
6. **Additív:** a tükörön lévő fájlokat soha nem törli.

## Működés bizonyítékai (beállítási futtatás, 2026-09-10)

| Lépés | Eredmény |
| --- | --- |
| Token validáció (API) | HTTP 200, `push: true` |
| Dry-run a push előtt | 3 várható változás felismerve (GitHubSync + sidecar + README) |
| Valódi futtatás | push `5248c10..1d70dc1` ✔ |
| Újra-ellenőrzés a push után | „A tükör NAPRAKÉSZ" (idempotens) ✔ |

Nyers kimenetek: `evidence/` mappa.

## Karbantartás

- **Új kiadásnál (v0.5.1+):** a kiadási munkaegység végén futtasd a
  scriptet — az új ZIP + sidecar + README-táblázat automatikusan felkerül.
- **A token lejáratakor (2026-11-09) vagy gyanú esetén:** a tulajdonos
  új fine-grained PAT-t generál (repo: AGE-T/VoiceMEM, Contents: Read and
  write) és a token-fájlba írja:
  `printf '%s' '<új token>' > /home/z/.github_sync/AGE-T_VoiceMEM.token`
- **A régi token visszavonása:** GitHub → Settings → Developer settings →
  Fine-grained tokens → Delete.
- A script leírás-táblázata új suffixinél (pl. új evidencia-típus) bővíthető
  a `describe()` függvényben.

## Biztonsági megjegyzés

A tárolt token standing hitelesítő adat a sandboxban. Kockázatcsökkentés:
repo-scoped (csak ez az egy repó), Contents-only jogkör, lejárat 2026-11-09,
600-as fájljogosultság, repón kívüli tárolás, minden kimenetben redaktálva.
Ha a sandbox biztonsága kétséges, a token visszavonása a tükröt írásvédetté
teszi — olvasás (klón) továbbra is működik.
