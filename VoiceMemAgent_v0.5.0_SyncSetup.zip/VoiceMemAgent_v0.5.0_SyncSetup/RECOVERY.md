# RECOVERY — VoiceMemAgent_v0.5.0_SyncSetup

**Artifact type:** GOLDEN RULE deliverable (standing sync policy + infrastructure)
**Created:** 2026-09-10, session `web-7b05b5bc-1460-41f0-9ee3-aeaffd50714f`

## What this is

The owner instructed: **„gitre is menjen majd minden frissítés"** — every
future update must go to the GitHub mirror. This package contains the
implemented infrastructure and its proof of work:

- `PROCEDURE.md` — the standing policy (scope, executor, maintenance,
  security notes)
- `sync_github_mirror.sh` — the exact script now live at
  `scripts/sync_github_mirror.sh` in the build sandbox
- `identity.json` — machine-readable policy + run evidence
- `evidence/` — token status (redacted), dry-run output, real push
  output, ls-remote confirmation

## Result of the setup run

- Mirror advanced `5248c10 → 1d70dc1`
  („sync: VoiceMemAgent_v0.5.0_GitHubSync.zip, .sha256, README.md")
- Re-run after the push: **idempotent** — „A tükör NAPRAKÉSZ"
- Token: fine-grained PAT, repo-scoped, stored at
  `/home/z/.github_sync/AGE-T_VoiceMEM.token` (chmod 600, outside the
  repo and public/), expires 2026-11-09, never printed unredacted

## If the sync infrastructure is ever lost

1. The script is in this package — restore it to
   `<project>/scripts/sync_github_mirror.sh` (executable).
2. Token storage:
   `printf '%s' '<PAT>' > /home/z/.github_sync/AGE-T_VoiceMEM.token && chmod 600 /home/z/.github_sync/AGE-T_VoiceMEM.token`
3. Policy details: `PROCEDURE.md` in this package.
4. Verify: `bash scripts/sync_github_mirror.sh --check` → expected
   „NAPRAKÉSZ" when the mirror is current.

## Recovery anchors

- **Mirror:** https://github.com/AGE-T/VoiceMEM @ `1d70dc1` (after setup run)
- **Local lineage:** `e446f5a` (first authenticated sync) → this package's
  commit
- **Artifacts on the mirror:** v0.5.0 product + Verification + MirrorCheck +
  GitHubSync (each with `.sha256`)
- **Token expiry:** 2026-11-09 (revoke + re-grant if compromised or expired)
