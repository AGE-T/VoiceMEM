Notes — v0.10.2 mirror sync (2026-09-16)
============================================================================

1. WHY this sync was pending
   The v0.10.1 (ASR forensic) and v0.10.2 (LLM priority) releases were
   published to the download page + local public/ staging on 2026-09-15,
   but the standing mirror sync needs the operator's fine-grained PAT,
   which had been wiped by the sandbox state restore (the documented
   state-loss class). The operator re-supplied it on 2026-09-16.
   Finding during recon: v0.10.1 had ALREADY been mirrored (commit
   08352b9, 19:45 UTC — product zip + asrregression recovery package).
   What was missing was v0.10.2 — exactly what the operator noticed.

2. Failed launch attempts (before any push; mirror never partial)
   - Attempt 1 (plain `nohup … &`): the detached process was killed by
     the sandbox environment mid-clone (log ends at "Tükör klónozása",
     no git error, process gone).
   - Attempt 2 (setsid + nohup): the anonymous clone died with
     `fatal: early EOF` (flaky uplink) AND the process ended without
     reaching the (new) retry branch.
   - A manual foreground clone succeeded in 3.9 s — the network was fine
     a minute later; the failures were transient.

3. Script hardening (this sync) — semantics unchanged
   scripts/sync_github_mirror.sh gained:
   - 3-attempt retry for the anonymous clone (early-EOF tolerance);
   - 3-attempt retry for the authenticated push (git push is atomic,
     so a retry can never create partial remote state);
   - VOICEMEM_SYNC_WORKDIR: stable-workdir mode — the clone and the
     local commit survive a killed run, and the next run RESUMES by
     pushing the existing local commit (resume path: detected via
     origin/main..HEAD, commit step made conditional).
   One syntax error during the edit (a missing closing quote in the
     new resume check) was caught by `bash -n` before any run.

4. README metadata correction (found during pre-sync audit)
   The gen_readme "verification story" still carried the v0.9.2-era
   hardcoded numbers (1253 passed / 13 skipped, fingerprint a74af6c5…,
   "exactly 21 vendor files"). The regenerated README now carries the
   authoritative v0.10.2 release-gate record
   (releases/RELEASE_INDEX.json -> gate_record):
     1386 tests / 0 regressions / 28 skipped / 6 pinned sandbox env-gap,
     deep validation PASS, fingerprint 768cc7b5…c1ad
   and the MEASURED vendor-patch count: 24 files vs the pinned upstream
   (21 modified + 3 added), verified by content-diffing the local fork
   against the upstream pin checkout (tool-results/voicemem-src at
   e8384e08…, the pin itself verified intact).

5. Mode-only drift cleaned BEFORE the sync
   The sandbox restore had set +x on 43 tracked files (content
   identical to HEAD — verified by git diff --summary: mode-change
   lines only, 0 insertions/deletions). All 43 were restored to their
   index modes, so the mirror received no mode-flip noise. Remaining
   uncommitted: .zscripts/dev.pid (runtime PID, not part of any push)
   and the vendor reference submodule's "-dirty" flag (local mode noise
   in tool-results/voicemem-src, not mirrored).

6. Known/OPEN items (documented, NOT changed here)
   - v0.9.1 product zip remains the known mirror-policy gap (superseded
     between two syncs; its recovery package IS mirrored; the zip is
     SHA-verified in the sandbox archive).
   - VOICEMEM_PIN.json's local_patches ledger was last updated at
     v0.9.0 (VM-LOCAL-001…015 + EN, 16 entries). The v0.10.x vendor-tree
     changes (temporal.py NEW, llm_bg_gate.py NEW, extract_facts_openai.py
     transport/timeout changes, additive_extraction_prompt.txt) are NOT
     yet enumerated in the ledger — UPSTREAM_POLICY.md step 4 requires
     ledger updates with each vendor change. Flagged for the next
     release; the v0.10.2 release tree itself is frozen/immutably
     published, so this is metadata debt for v0.10.3+/v0.11, not a
     shipped-code defect.
   - The mirror README's older prose (pin-verification / clean-install
     sections) still describes the v0.5.0-era verification story;
     historically accurate, left as-is.

7. Token hygiene
   The PAT value appears nowhere in the pushed tree or history
   (grep-verified, evidence/04). The sync script redacts push output
   and the token file lives outside all repositories.
