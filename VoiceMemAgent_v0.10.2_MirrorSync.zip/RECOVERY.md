# VoiceMemAgent v0.10.2 — MirrorSync evidence package

**What this is:** the golden-rule deliverable of the 2026-09-16 GitHub
mirror sync that published the **v0.10.2** release (the P0 "LLM priority +
reproducibility" hotfix line) to https://github.com/AGE-T/VoiceMEM.
It documents that the mirror is a byte-identical, additive distribution
of the locally produced artifacts.

**Pre-sync state:** mirror HEAD `08352b9` — v0.10.1 already mirrored
(product zip + `VoiceMem_asrregression_v0101_recovery.zip`), **v0.10.2
missing** (what the operator reported).
**Post-sync state:** mirror HEAD `955f7b7` — `VoiceMemAgent_v0.10.2.zip`
(SHA-256 `f56e5155043b9900b2a45799f4fa1663ed8475584f9dba1f1bbd80b13c525a54`,
2,766,235 bytes), `VoiceMem_llmpriority_v0102_recovery.zip`
(`06b065abe83e42f01f162baa1711fa22b2fddbcb63ed79851ccae567630220bd`), regenerated README
("Latest stable release: v0.10.2" with the authoritative release-gate
numbers), and the full v0.10.2 first-party source tree under `source/`.

## Verify (independent, no trust needed)

```bash
git clone https://github.com/AGE-T/VoiceMEM.git vmirror
cd vmirror
sha256sum VoiceMemAgent_v0.10.2.zip VoiceMem_llmpriority_v0102_recovery.zip
# expected:
#   f56e5155043b9900b2a45799f4fa1663ed8475584f9dba1f1bbd80b13c525a54  VoiceMemAgent_v0.10.2.zip
#   06b065abe83e42f01f162baa1711fa22b2fddbcb63ed79851ccae567630220bd  (see .sha256 sidecars / README hash table)
grep -m1 "Latest stable release" README.md   # -> v0.10.2
git log --oneline -1                          # -> 955f7b7 sync: VoiceMemAgent_v0.10.2.zip, …
```

Package contents: `identity.json`, `evidence/01…06` (token-permission
check — redacted; pre-push dry-run; push log; fresh-anonymous-clone
verification with VERDICT: PASS; mirror git log; engineering notes),
`SHA256SUMS`.

## Re-syncing / recovery

The standing policy (owner, 2026-09-10): every update (new release +
evidence packages) goes to the GitHub mirror automatically via
`scripts/sync_github_mirror.sh`:

```bash
# token at /home/z/.github_sync/AGE-T_VoiceMEM.token (chmod 600)
scripts/sync_github_mirror.sh --check     # dry-run
VOICEMEM_SYNC_WORKDIR=/tmp/mirror_work scripts/sync_github_mirror.sh
```

The stable-workdir mode (new in this sync) lets a killed run resume by
pushing the already-built local commit; the sync is additive-only and
idempotent; `git push` is atomic, so the remote is never partial.

## Rollback / provenance

The mirror only ever moves FORWARD additively; there is nothing to roll
back (no file is ever deleted by the sync). The product rollback anchor
is `VoiceMem_llmpriority_v0102_recovery.zip` (this release's own
recovery package, mirrored in the same push).
